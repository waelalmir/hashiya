import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

/// خط ستيكرات الورق (Playpen Sans Arabic). إن تعذّر تنزيله وقت البناء يُستخدم خط احتياطي بنفس الاسم.
const kPaperFont = 'PlaypenSansArabic';
const kPaperInk = Color(0xFF3A3A3A);

TextStyle paperTextStyle(Color color) => TextStyle(
      fontFamily: kPaperFont,
      fontVariations: const [ui.FontVariation('wght', 600)],
      color: color,
      height: 1.25,
    );

/// نص يصغّر خطه تلقائياً حتى يبقى داخل المساحة المتاحة (يُعطى قيوداً ثابتة من الأب).
class AutoFitText extends StatelessWidget {
  const AutoFitText(this.text, {super.key, required this.style, this.maxSize = 40, this.minSize = 6});
  final String text;
  final TextStyle style;
  final double maxSize, minSize;

  @override
  Widget build(BuildContext context) {
    if (text.isEmpty) return const SizedBox.shrink();
    final dir = Directionality.of(context);
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth, h = box.maxHeight;
      if (!w.isFinite || !h.isFinite || w <= 0 || h <= 0) return const SizedBox.shrink();
      bool fits(double fs) {
        final tp = TextPainter(
          text: TextSpan(text: text, style: style.copyWith(fontSize: fs)),
          textDirection: dir,
          textAlign: TextAlign.center,
        )..layout(maxWidth: w);
        final ok = tp.height <= h;
        tp.dispose();
        return ok;
      }

      double best;
      if (fits(maxSize)) {
        best = maxSize;
      } else {
        var lo = minSize, hi = maxSize;
        for (var i = 0; i < 9; i++) {
          final mid = (lo + hi) / 2;
          if (fits(mid)) {
            lo = mid;
          } else {
            hi = mid;
          }
        }
        best = lo;
      }
      return SizedBox(
        width: w,
        height: h,
        child: Center(child: Text(text, textAlign: TextAlign.center, style: style.copyWith(fontSize: best))),
      );
    });
  }
}

class PaperStyle {
  const PaperStyle(this.paper, this.tape,
      {this.torn = false, this.curl = 0, this.grid = false, this.holes = false, this.tapeAngle = -.12, this.tapeX = .5});
  final Color paper, tape;
  final bool torn, grid, holes;
  final int curl; // 0 بدون، 1 طيّة أسفل اليمين، -1 طيّة أسفل اليسار
  final double tapeAngle, tapeX;

  /// نسخة بسيطة (بدون تمزيق/طيّة) لإطار الصورة.
  PaperStyle get frame => PaperStyle(Color.lerp(paper, Colors.white, .6)!, tape, tapeAngle: tapeAngle, tapeX: tapeX);
}

const kPaperStyles = <PaperStyle>[
  PaperStyle(Color(0xFFFFFFFF), Color(0xFFC9A6D6), torn: true, tapeAngle: -.35, tapeX: .22),
  PaperStyle(Color(0xFFEFEFEF), Color(0xFF8FB08C), curl: 1, tapeAngle: -.04, tapeX: .5),
  PaperStyle(Color(0xFFF2E9D4), Color(0xFFF0A898), torn: true, tapeAngle: -.25, tapeX: .75),
  PaperStyle(Color(0xFFF0EEE6), Color(0xFF8DBFCF), curl: -1, tapeAngle: -.3, tapeX: .25),
  PaperStyle(Color(0xFFF8F3D3), Color(0xFFB99AB8), torn: true, tapeAngle: .03, tapeX: .5),
  PaperStyle(Color(0xFFE8E0EE), Color(0xFF8FB5C9), curl: 1, tapeAngle: .3, tapeX: .75, torn: true),
  PaperStyle(Color(0xFFF5F1E8), Color(0xFFA87E5C), grid: true, tapeAngle: -.08, tapeX: .35),
  PaperStyle(Color(0xFFFFFFFF), Color(0xFFD4B66A), holes: true, tapeAngle: .1, tapeX: .8),
  PaperStyle(Color(0xFFEFE2D2), Color(0xFFD9A38F), torn: true, tapeAngle: -.2, tapeX: .5),
];

/// جمل جاهزة (المجموعة الأولى). الستايل يتوزّع بالتناوب على الأنماط التسعة.
const kPhrases = <String>[
  'هام جداً',
  'للمراجعة',
  'تذكير',
  'سؤال؟',
  'مثال',
  'تعريف',
  'قاعدة',
  'ملخص',
  'لا تنسَ!',
  'للحفظ',
  'خطأ شائع',
  'يأتي بالامتحان',
  'اسأل الدكتور',
  'ابحث أكثر',
  'فكرة',
  'نقطة مهمة',
  'ممتاز',
  'صعب',
  'سهل',
  'فهمتها ✓',
  'غير واضح',
  'تحقق منها',
  'للنقاش',
  'الخلاصة',
];

class PaperPainter extends CustomPainter {
  PaperPainter(this.s, this.seed);
  final PaperStyle s;
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final rnd = math.Random(seed * 7919 + 13);
    final c = s.curl == 0 ? 0.0 : w * .17;

    final path = Path()..moveTo(0, 0)..lineTo(w, 0);
    if (s.curl == 1) {
      path.lineTo(w, h - c);
      path.lineTo(w - c, h);
    } else {
      path.lineTo(w, h);
    }
    final x0 = s.curl == 1 ? w - c : w;
    final x1 = s.curl == -1 ? c : 0.0;
    if (s.torn) {
      const n = 46;
      for (var i = 1; i <= n; i++) {
        final x = x0 + (x1 - x0) * i / n;
        path.lineTo(x, h - rnd.nextDouble() * h * .025);
      }
    } else {
      path.lineTo(x1, h);
    }
    if (s.curl == -1) path.lineTo(0, h - c);
    path.close();

    // ظل
    canvas.drawPath(
      path.shift(Offset(w * .012, h * .02)),
      Paint()
        ..color = const Color(0x55000000)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * .02),
    );
    canvas.drawPath(path, Paint()..color = s.paper);

    canvas.save();
    canvas.clipPath(path);
    if (s.grid) {
      final g = Paint()
        ..color = const Color(0x2A5C7A99)
        ..strokeWidth = 1;
      final step = w / 12;
      for (var x = step; x < w; x += step) {
        canvas.drawLine(Offset(x, 0), Offset(x, h), g);
      }
      for (var y = step; y < h; y += step) {
        canvas.drawLine(Offset(0, y), Offset(w, y), g);
      }
    }
    if (s.holes) {
      final hp = Paint()..color = const Color(0x40000000);
      for (var x = w * .08; x < w; x += w * .09) {
        canvas.drawCircle(Offset(x, h * .05), w * .016, hp);
      }
    }
    canvas.restore();

    // طيّة الزاوية
    if (s.curl != 0) {
      final flap = Path();
      final Rect r;
      if (s.curl == 1) {
        flap..moveTo(w, h - c)..lineTo(w - c, h)..lineTo(w - c, h - c)..close();
        r = Rect.fromLTWH(w - c, h - c, c, c);
      } else {
        flap..moveTo(0, h - c)..lineTo(c, h)..lineTo(c, h - c)..close();
        r = Rect.fromLTWH(0, h - c, c, c);
      }
      canvas.drawPath(
        flap,
        Paint()
          ..shader = const LinearGradient(
            colors: [Color(0xFFFFFFFF), Color(0xFFCDCDCD)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(r),
      );
    }

    // لزيقة (شريط لاصق)
    canvas.save();
    canvas.translate(w * s.tapeX, h * .03);
    canvas.rotate(s.tapeAngle);
    final tw = w * .34, th = h * .1;
    const teeth = 4;
    final tooth = th / teeth;
    final tp = Path()..moveTo(-tw / 2, -th / 2)..lineTo(tw / 2, -th / 2);
    for (var i = 0; i < teeth; i++) {
      tp.lineTo(tw / 2 - tooth * .45, -th / 2 + tooth * (i + .5));
      tp.lineTo(tw / 2, -th / 2 + tooth * (i + 1));
    }
    tp.lineTo(-tw / 2, th / 2);
    for (var i = teeth - 1; i >= 0; i--) {
      tp.lineTo(-tw / 2 + tooth * .45, -th / 2 + tooth * (i + .5));
      tp.lineTo(-tw / 2, -th / 2 + tooth * i);
    }
    tp.close();
    canvas.drawPath(tp, Paint()..color = s.tape.withValues(alpha: .8));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant PaperPainter old) => old.s != s || old.seed != seed;
}

/// ورقة ملاحظة بلزيقة، النص داخلها يتصغّر تلقائياً ويبقى بعيداً عن الحواف.
class PaperNote extends StatelessWidget {
  const PaperNote({super.key, required this.styleIndex, required this.text, required this.width, this.hint = ''});
  final int styleIndex;
  final String text;
  final double width;
  final String hint;

  @override
  Widget build(BuildContext context) {
    final st = kPaperStyles[styleIndex % kPaperStyles.length];
    final h = width * .8;
    final shown = text.isEmpty ? hint : text;
    return SizedBox(
      width: width,
      height: h,
      child: Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(child: CustomPaint(painter: PaperPainter(st, styleIndex % kPaperStyles.length))),
        Positioned.fill(
          child: Padding(
            padding: EdgeInsets.fromLTRB(width * .1, h * .2, width * .1, h * .14),
            child: AutoFitText(
              shown,
              maxSize: width * .2,
              minSize: 6,
              style: paperTextStyle(text.isEmpty ? kPaperInk.withValues(alpha: .35) : kPaperInk),
            ),
          ),
        ),
      ]),
    );
  }
}

/// صورة داخل إطار مع لزيقة وتعليق اختياري تحتها.
class PhotoNote extends StatelessWidget {
  const PhotoNote({super.key, required this.styleIndex, required this.width, this.path, this.caption = ''});
  final int styleIndex;
  final double width;
  final String? path;
  final String caption;

  @override
  Widget build(BuildContext context) {
    final idx = styleIndex % kPaperStyles.length;
    final st = kPaperStyles[idx].frame;
    final h = width * 1.12;
    final hasCap = caption.isNotEmpty;
    Widget placeholder(IconData i) => Container(color: const Color(0x14000000), child: Icon(i, size: width * .25, color: const Color(0x44000000)));
    Widget photo;
    if (path == null) {
      photo = placeholder(Icons.image_rounded);
    } else {
      photo = Image.file(
        File(path!),
        fit: BoxFit.cover,
        cacheWidth: 700,
        errorBuilder: (_, __, ___) => placeholder(Icons.broken_image_rounded),
      );
    }
    return SizedBox(
      width: width,
      height: h,
      child: Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(child: CustomPaint(painter: PaperPainter(st, idx))),
        Positioned(
          left: width * .07,
          right: width * .07,
          top: h * .11,
          bottom: hasCap ? h * .25 : h * .07,
          child: ClipRRect(borderRadius: BorderRadius.circular(3), child: photo),
        ),
        if (hasCap)
          Positioned(
            left: width * .1,
            right: width * .1,
            bottom: h * .035,
            height: h * .18,
            child: AutoFitText(caption, maxSize: width * .12, minSize: 6, style: paperTextStyle(kPaperInk)),
          ),
      ]),
    );
  }
}


// ==================== 4 مجموعات ستيكرات جديدة مستوحاة من المراجع ====================

class PackStickerDef {
  const PackStickerDef(this.text, this.bg, this.fg, {this.border, this.shape = 'card', this.sub = ''});
  final String text;
  final Color bg;
  final Color fg;
  final Color? border;
  final String shape; // card | ayah | warn | pill | cloud | win
  final String sub;
}

const kStickerPacks = <String, (String, List<PackStickerDef>)>{
  'quran': (
    'آيات وأدعية',
    [
      PackStickerDef('يَأْتِ بِهَا اللَّهُ إِنَّ اللَّهَ لَطِيفٌ خَبِيرٌ', Color(0xFFEDE0CC), Color(0xFF2B2118), border: Color(0xFFCBB799), shape: 'ayah'),
      PackStickerDef('يُدَبِّرُ الْأَمْرَ', Color(0xFFC4A789), Color(0xFF23180F), border: Color(0xFF9C7D5E), shape: 'ayah'),
      PackStickerDef('لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا', Color(0xFFF3EFEA), Color(0xFF5A3722), border: Color(0xFFD9CFC4), shape: 'ayah'),
      PackStickerDef('وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَى', Color(0xFFD5C5B2), Color(0xFF2C2017), border: Color(0xFFB39E86), shape: 'ayah'),
      PackStickerDef('حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', Color(0xFFEAE5DC), Color(0xFF2E2924), border: Color(0xFFC8C0B2), shape: 'ayah'),
      PackStickerDef('فَإِنَّ مَعَ الْعُسْرِ يُسْرًا', Color(0xFFF7F2EA), Color(0xFF2B2520), border: Color(0xFFD9CBB8), shape: 'ayah'),
      PackStickerDef('فَصَبْرٌ جَمِيلٌ', Color(0xFFF6ECEF), Color(0xFF5E3342), border: Color(0xFFE0C3CC), shape: 'ayah'),
      PackStickerDef('وَبَشِّرِ الصَّابِرِينَ', Color(0xFFEDE6DA), Color(0xFF3A2D21), border: Color(0xFFCEC1AC), shape: 'ayah'),
      PackStickerDef('رَبِّ زِدْنِي عِلْمًا', Color(0xFFF3F0E6), Color(0xFF3E3529), border: Color(0xFFD4CBB5), shape: 'ayah'),
      PackStickerDef('لَا تَدْرِي لَعَلَّ اللَّهَ يُحْدِثُ بَعْدَ ذَلِكَ أَمْرًا', Color(0xFFF4F1EC), Color(0xFF231F1C), border: Color(0xFFD6CEC4), shape: 'ayah'),
      PackStickerDef('قَالَ كَلَّا إِنَّ مَعِيَ رَبِّي سَيَهْدِينِ', Color(0xFFDCD5C9), Color(0xFF2B251F), border: Color(0xFFB9AE9D), shape: 'ayah'),
      PackStickerDef('وَلَا تَيْأَسُوا مِن رَّوْحِ اللَّهِ', Color(0xFFE5CBB8), Color(0xFF472C1E), border: Color(0xFFC8A68E), shape: 'ayah'),
      PackStickerDef('رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ', Color(0xFFE8E4DC), Color(0xFF2E2A25), border: Color(0xFFC5BEB2), shape: 'ayah'),
      PackStickerDef('وَأَنَّ سَعْيَهُ سَوْفَ يُرَى', Color(0xFFD6CFC4), Color(0xFF383028), border: Color(0xFFB4AA9B), shape: 'ayah'),
      PackStickerDef('اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا', Color(0xFFF0EFEA), Color(0xFF2A2926), border: Color(0xFFCBC8BE), shape: 'ayah'),
      PackStickerDef('اللَّهُمَّ لَا سَهْلَ إِلَّا مَا جَعَلْتَهُ سَهْلًا', Color(0xFFF4EFE8), Color(0xFF3A3129), border: Color(0xFFD7CCC0), shape: 'ayah'),
    ],
  ),
  'student': (
    'تحفيز طلابي',
    [
      PackStickerDef('إحذر...
منطقة انهيارات!', Color(0xFFFFCA28), Color(0xFF1E1E1E), border: Color(0xFF1E1E1E), shape: 'warn'),
      PackStickerDef('فترة
وتعدّي', Color(0xFF8B1E2D), Color(0xFFFFFFFF), border: Color(0xFF63121E), shape: 'card'),
      PackStickerDef('معلش', Color(0xFF1E5AA8), Color(0xFFFFFFFF), border: Color(0xFFFFFFFF), shape: 'card'),
      PackStickerDef('قــــاوم', Color(0xFF8C3333), Color(0xFFF5EFE6), border: Color(0xFF692222), shape: 'card'),
      PackStickerDef('أنت مسؤول عن السعي
لا عن النتيجة', Color(0xFF8CCDF2), Color(0xFF1B2A38), border: Color(0xFF5DA9D6), shape: 'card'),
      PackStickerDef('أنت تستطيع
فقط ابدأ', Color(0xFFF2D6E8), Color(0xFF3A2434), border: Color(0xFFD4A7C4), shape: 'pill'),
      PackStickerDef('لا تستسلم', Color(0xFFFFFFFF), Color(0xFF262626), border: Color(0xFFD0D0D0), shape: 'card', sub: "don't give up"),
      PackStickerDef('سأصير يوماً ما أريد', Color(0xFFF7F4EE), Color(0xFF2C2621), border: Color(0xFFD5CCB8), shape: 'pill'),
      PackStickerDef('لَا أَبْرَحُ حَتَّى أَبْلُغَ', Color(0xFFFDFBF7), Color(0xFF1F1D1B), border: Color(0xFFCFC7BA), shape: 'ayah'),
      PackStickerDef('ولعل فرحتك
قد اقتربت', Color(0xFFDCC3AA), Color(0xFF3B2818), border: Color(0xFFBFA082), shape: 'card'),
      PackStickerDef('كُن قوياً لأجلك', Color(0xFFF5F3EF), Color(0xFF423C36), border: Color(0xFFD4CEC4), shape: 'pill'),
      PackStickerDef('لا تقلق', Color(0xFFFFCA28), Color(0xFF1E1E1E), border: Color(0xFF1E1E1E), shape: 'warn'),
      PackStickerDef('مش فاهم 😅', Color(0xFFE0E4EC), Color(0xFF1E2430), border: Color(0xFF4A5B7A), shape: 'win', sub: 'Error!!'),
      PackStickerDef('جاري الاستيعاب...', Color(0xFFECEFF4), Color(0xFF2E3440), border: Color(0xFF8899AE), shape: 'win', sub: 'LOADING'),
    ],
  ),
  'cozy': (
    'إيجابية ولطف',
    [
      PackStickerDef('كل شيء
سيكون بخير', Color(0xFFE8DFF5), Color(0xFF45365C), border: Color(0xFFCBB8E6), shape: 'cloud'),
      PackStickerDef('انمُ
بهدوء 🌿', Color(0xFFE0EFE5), Color(0xFF2E4D3B), border: Color(0xFFB7D6C2), shape: 'cloud'),
      PackStickerDef('استراحة
ثم نكمل ☕', Color(0xFFF7E2E2), Color(0xFF5C3333), border: Color(0xFFE2BDBD), shape: 'cloud'),
      PackStickerDef('أنت تستحق
كل الخير ✨', Color(0xFFFFF2C9), Color(0xFF5C481A), border: Color(0xFFE8D18E), shape: 'cloud'),
      PackStickerDef('فخور بك ♥', Color(0xFFDCEEF7), Color(0xFF28485C), border: Color(0xFFB0D4E6), shape: 'cloud'),
      PackStickerDef('تقدّم ولو
بخطوة صغيرة', Color(0xFFFCE8EE), Color(0xFF5E3140), border: Color(0xFFE8BDD0), shape: 'cloud'),
      PackStickerDef('أحلامك تستحق
المحاولة', Color(0xFFF5E6E0), Color(0xFF573B30), border: Color(0xFFDEC1B6), shape: 'cloud'),
      PackStickerDef('لا تقلق
كل شيء بوقته', Color(0xFFDFEEFA), Color(0xFF294661), border: Color(0xFFB5D3EB), shape: 'cloud'),
      PackStickerDef('ثق بنفسك
دائماً', Color(0xFFE9E0F7), Color(0xFF463461), border: Color(0xFFCAB8E8), shape: 'cloud'),
      PackStickerDef('اليوم
إنجاز جديد', Color(0xFFF7EFE1), Color(0xFF594426), border: Color(0xFFDECBA8), shape: 'cloud'),
      PackStickerDef('تفاءل دائماً
بالخير 🌈', Color(0xFFF5F1EB), Color(0xFF453E36), border: Color(0xFFD6CEC2), shape: 'cloud'),
      PackStickerDef('خطوة صغيرة كل يوم
تصنع فرقاً كبيراً', Color(0xFFE2F0DF), Color(0xFF2E4D29), border: Color(0xFFBCD9B6), shape: 'card'),
      PackStickerDef('تعلّم · تطوّر · تألّق', Color(0xFFFAEBD7), Color(0xFF5C4024), border: Color(0xFFE0C49E), shape: 'pill'),
      PackStickerDef('لا تنسَ أن تكون
لطيفاً مع نفسك', Color(0xFFFCE6E2), Color(0xFF5E342E), border: Color(0xFFE6BEB6), shape: 'cloud'),
    ],
  ),
  'plan': (
    'تخطيط ودراسة',
    [
      PackStickerDef('وقت الدراسة', Color(0xFFE3ECFA), Color(0xFF2A426B), border: Color(0xFFB6CBEB), shape: 'pill', sub: 'Study Time'),
      PackStickerDef('وضع التركيز', Color(0xFFEBE0FA), Color(0xFF472E6B), border: Color(0xFFCBB6EB), shape: 'pill', sub: 'Focus Mode'),
      PackStickerDef('أولوية قصوى', Color(0xFFFCE0E6), Color(0xFF6B2A38), border: Color(0xFFEBADBA), shape: 'pill', sub: 'Top Priority'),
      PackStickerDef('قائمة المهام', Color(0xFFE0F2E9), Color(0xFF26543D), border: Color(0xFFAED9C4), shape: 'pill', sub: 'To Do'),
      PackStickerDef('مراجعة', Color(0xFFFFF0D4), Color(0xFF6B4C1A), border: Color(0xFFEBD09E), shape: 'pill', sub: 'Revision'),
      PackStickerDef('يوم الامتحان', Color(0xFFFCE2D4), Color(0xFF6B351A), border: Color(0xFFEBB89E), shape: 'pill', sub: 'Exam Day'),
      PackStickerDef('تذكير مهم', Color(0xFFDDF0F5), Color(0xFF234D59), border: Color(0xFFAAD3DE), shape: 'pill', sub: 'Reminder'),
      PackStickerDef('أهداف اليوم', Color(0xFFECF2DD), Color(0xFF3E4F22), border: Color(0xFFC9D9A7), shape: 'pill', sub: 'Goals'),
      PackStickerDef('استراحة', Color(0xFFF5E6F0), Color(0xFF5C2F4C), border: Color(0xFFDEC0D4), shape: 'pill', sub: 'Break Time'),
      PackStickerDef('استمر ولا تتوقف', Color(0xFFFFECC9), Color(0xFF5E4315), border: Color(0xFFE6C88E), shape: 'cloud', sub: 'Keep Going'),
      PackStickerDef('أنت قدّها!', Color(0xFFDFF2E4), Color(0xFF255433), border: Color(0xFFB0DBBC), shape: 'cloud', sub: 'You Got This'),
      PackStickerDef('ملخص وملاحظات', Color(0xFFF5EFE4), Color(0xFF4D3F2A), border: Color(0xFFD9CCB6), shape: 'card', sub: 'Notes'),
    ],
  ),
};

PackStickerDef? findPackSticker(String packId, int idx) {
  final p = kStickerPacks[packId];
  if (p == null || idx < 0 || idx >= p.$2.length) return null;
  return p.$2[idx];
}

/// عرض ستيكر من المجموعات الجديدة بدقة متجهية عالية وخط يدوي عربي.
class StyledPackSticker extends StatelessWidget {
  const StyledPackSticker({super.key, required this.def, required this.width, this.customText = ''});
  final PackStickerDef def;
  final double width;
  final String customText;

  @override
  Widget build(BuildContext context) {
    final txt = customText.isEmpty ? def.text : customText;
    final h = def.shape == 'ayah' ? width * .42 : (def.shape == 'pill' ? width * .44 : width * .74);
    final rad = def.shape == 'pill' ? h / 2 : (def.shape == 'cloud' ? width * .16 : (def.shape == 'win' ? 6.0 : 12.0));
    final bColor = def.border ?? def.fg.withValues(alpha: .3);

    return Container(
      width: width,
      height: h,
      decoration: BoxDecoration(
        color: def.bg,
        borderRadius: BorderRadius.circular(rad),
        border: Border.all(color: bColor, width: def.shape == 'warn' ? 2.4 : 1.5),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 5, offset: Offset(0, 2))],
      ),
      child: Column(children: [
        if (def.shape == 'win')
          Container(
            height: h * .24,
            padding: const EdgeInsets.symmetric(horizontal: 6),
            decoration: BoxDecoration(color: bColor, borderRadius: const BorderRadius.vertical(top: Radius.circular(4))),
            child: Row(children: [
              const Icon(Icons.close_rounded, size: 10, color: Colors.white),
              const Spacer(),
              Text(def.sub, style: const TextStyle(color: Colors.white, fontSize: 8.5, fontWeight: FontWeight.w700)),
            ]),
          ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: width * .08, vertical: h * .10),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Expanded(
                child: AutoFitText(
                  def.shape == 'ayah' ? '﴿ $txt ﴾' : txt,
                  style: paperTextStyle(def.fg),
                  maxSize: width * .17,
                  minSize: 7,
                ),
              ),
              if (def.sub.isNotEmpty && def.shape != 'win')
                Text(
                  def.sub,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: math.max(7, width * .075), color: def.fg.withValues(alpha: .72), fontWeight: FontWeight.w600),
                ),
            ]),
          ),
        ),
      ]),
    );
  }
}
