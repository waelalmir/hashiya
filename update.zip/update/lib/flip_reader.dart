import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'annotations.dart';
import 'page_overlay.dart';
import 'reading_mode.dart';
import 'theme.dart';

/// تخطيط صفحتين متجاورتين لوضع التمرير (pdfrx). rtl = الصفحة الأولى يمين (كتاب عربي).
PdfPageLayout spreadLayout(List<PdfPage> pages, PdfViewerParams params, {required bool rtl, required bool coverAlone}) {
  final m = params.margin;
  final groups = <List<int>>[];
  var i = 0;
  if (coverAlone && pages.isNotEmpty) {
    groups.add([0]);
    i = 1;
  }
  while (i < pages.length) {
    groups.add(i + 1 < pages.length ? [i, i + 1] : [i]);
    i += 2;
  }
  var maxW = 0.0;
  for (final g in groups) {
    var w = m * (g.length + 1);
    for (final k in g) {
      w += pages[k].width;
    }
    maxW = math.max(maxW, w);
  }
  final rects = List<Rect>.filled(pages.length, Rect.zero);
  var y = m;
  for (final g in groups) {
    var rowH = 0.0, rowW = m * (g.length - 1);
    for (final k in g) {
      rowH = math.max(rowH, pages[k].height);
      rowW += pages[k].width;
    }
    var x = (maxW - rowW) / 2;
    final order = rtl ? g.reversed.toList() : g;
    for (final k in order) {
      rects[k] = Rect.fromLTWH(x, y + (rowH - pages[k].height) / 2, pages[k].width, pages[k].height);
      x += pages[k].width + m;
    }
    y += rowH + m;
  }
  return PdfPageLayout(pageLayouts: rects, documentSize: Size(maxW, y));
}

class FlipController {
  _FlipReaderState? _s;
  void jump(int page, {bool animate = true}) => _s?._jumpTo(page, animate);
}

/// قارئ بالتقليب: صفحة (أو صفحتان) بالشاشة، سحب أو أسهم للتقليب، تكبير بالقرصة/النقر المزدوج.
class FlipReader extends StatefulWidget {
  const FlipReader({
    super.key,
    required this.path,
    required this.ann,
    required this.controller,
    required this.initialPage,
    required this.onTotal,
    required this.onPageChanged,
    required this.onPin,
    required this.onSticker,
  });
  final String path;
  final Annotations ann;
  final FlipController controller;
  final int initialPage;
  final void Function(int total) onTotal;
  final void Function(int page) onPageChanged;
  final PinTap onPin;
  final StickerAction onSticker;
  @override
  State<FlipReader> createState() => _FlipReaderState();
}

class _FlipReaderState extends State<FlipReader> {
  PdfDocument? doc;
  String? error;
  PageController? pc;
  List<List<int>> groups = [];
  int current = 0;
  bool zoomed = false;
  final _futures = <String, Future<ui.Image?>>{};
  final _images = <String, ui.Image>{}; // لتنظيف الذاكرة ومنع التعليق بوضع الصفحتين
  Future<void> _queue = Future.value();
  bool _disposed = false;

  @override
  void initState() {
    super.initState();
    widget.controller._s = this;
    _open();
  }

  Future<void> _open() async {
    try {
      final d = await PdfDocument.openFile(widget.path);
      final total = d.pages.length;
      final a = widget.ann;
      final g = <List<int>>[];
      var i = 1;
      if (a.spread) {
        if (a.coverAlone && total >= 1) {
          g.add([1]);
          i = 2;
        }
        while (i <= total) {
          g.add(i + 1 <= total ? [i, i + 1] : [i]);
          i += 2;
        }
      } else {
        for (var p = 1; p <= total; p++) {
          g.add([p]);
        }
      }
      if (!mounted) {
        await Future.sync(() => d.dispose());
        return;
      }
      final start = _groupOf(g, widget.initialPage);
      setState(() {
        doc = d;
        groups = g;
        current = start;
        pc = PageController(initialPage: start);
      });
      widget.onTotal(total);
    } catch (e) {
      if (mounted) setState(() => error = 'تعذّر فتح الملف');
    }
  }

  int _groupOf(List<List<int>> g, int page) {
    for (var i = 0; i < g.length; i++) {
      if (g[i].contains(page)) return i;
    }
    return 0;
  }

  void _jumpTo(int page, bool animate) {
    final c = pc;
    if (c == null || groups.isEmpty || !c.hasClients) return;
    final gi = _groupOf(groups, page);
    if (animate) {
      c.animateToPage(gi, duration: const Duration(milliseconds: 340), curve: Curves.easeInOutCubic);
    } else {
      c.jumpToPage(gi);
    }
  }

  void _step(int dir) {
    final c = pc;
    if (c == null || !c.hasClients) return;
    final t = (current + dir).clamp(0, groups.length - 1).toInt();
    c.animateToPage(t, duration: const Duration(milliseconds: 340), curve: Curves.easeInOutCubic);
  }

  void _evictFar() {
    final cur = groups.isEmpty ? 1 : groups[current].first;
    final maxDist = widget.ann.spread ? 4 : 3;
    final drop = <String>[];
    for (final k in _futures.keys) {
      final pg = int.tryParse(k.split('@').first) ?? 0;
      if ((pg - cur).abs() > maxDist) drop.add(k);
    }
    for (final k in drop) {
      _futures.remove(k);
      final im = _images.remove(k);
      im?.dispose();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    if (widget.controller._s == this) widget.controller._s = null;
    pc?.dispose();
    for (final im in _images.values) {
      try {
        im.dispose();
      } catch (_) {}
    }
    _images.clear();
    _futures.clear();
    final d = doc;
    if (d != null) Future.sync(() => d.dispose());
    super.dispose();
  }

  // ---------- رسم الصفحات إلى صور (مع إدارة ذاكرة ومنع التزاحم) ----------
  Future<ui.Image?> _image(int p, int wpx, bool protect) {
    final a = widget.ann;
    final t = a.tone[a.mode];
    final bgVal = t == null ? 0 : t[0];
    final txVal = t == null ? 0 : t[1];
    final key = '$p@$wpx@${protect ? '$bgVal:$txVal' : '0'}';
    final cached = _futures[key];
    if (cached != null) return cached;
    _evictFar();
    final c = Completer<ui.Image?>();
    _queue = _queue.then((_) async {
      if (_disposed || !mounted) {
        c.complete(null);
        return;
      }
      // تجاهل الصفحات التي ابتعد عنها المستخدم أثناء التقليب السريع
      final cur = groups.isEmpty ? 1 : groups[current].first;
      if ((p - cur).abs() > (a.spread ? 5 : 4)) {
        _futures.remove(key);
        c.complete(null);
        return;
      }
      final im = await _render(p, wpx, protect, bgVal, txVal);
      if (_disposed || !mounted) {
        im?.dispose();
        c.complete(null);
        return;
      }
      if (im != null) _images[key] = im;
      c.complete(im);
    });
    return _futures[key] = c.future;
  }

  Future<ui.Image?> _render(int p, int wpx, bool protect, int bgVal, int txVal) async {
    try {
      final d = doc;
      if (d == null || p < 1 || p > d.pages.length) return null;
      final page = d.pages[p - 1];
      final h = math.max(1, (wpx * page.height / page.width).round());
      final img = await page.render(width: wpx, height: h);
      if (img == null) return null;
      ui.Image im = await img.createImage();
      img.dispose();
      if (protect) {
        final out = await _protectPhotos(im, Color(bgVal), Color(txVal));
        if (out != null) {
          im.dispose();
          im = out;
        }
      }
      return im;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.ann;
    if (error != null) return Center(child: Text(error!));
    if (doc == null || pc == null) return const Center(child: CircularProgressIndicator());
    final inv = toneInverts(a);
    final drawing = a.tool != 'none';
    final rtl = a.rtl;
    Widget pv = PageView.builder(
      controller: pc,
      physics: (drawing || zoomed) ? const NeverScrollableScrollPhysics() : const PageScrollPhysics(),
      itemCount: groups.length,
      onPageChanged: (i) {
        current = i;
        zoomed = false;
        _evictFar();
        widget.onPageChanged(groups[i].first);
        setState(() {});
      },
      itemBuilder: (c, i) => _item(i),
    );
    pv = Directionality(textDirection: rtl ? TextDirection.rtl : TextDirection.ltr, child: pv);
    Widget body = Container(color: inv ? invertColor(HC.deep) : HC.deep, child: pv);
    if (inv) body = ColorFiltered(colorFilter: kInvert, child: body);
    return Stack(children: [
      Positioned.fill(child: body),
      if (!drawing && !zoomed) ...[
        Positioned(
          left: 6,
          top: 0,
          bottom: 0,
          child: Center(child: _navBtn(Icons.chevron_left_rounded, () => _step(rtl ? 1 : -1))),
        ),
        Positioned(
          right: 6,
          top: 0,
          bottom: 0,
          child: Center(child: _navBtn(Icons.chevron_right_rounded, () => _step(rtl ? -1 : 1))),
        ),
      ],
    ]);
  }

  Widget _navBtn(IconData ic, VoidCallback onTap) => Material(
        color: HC.deep.withValues(alpha: .45),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(padding: const EdgeInsets.all(6), child: Icon(ic, color: HC.cream, size: 28)),
        ),
      );

  Widget _item(int gi) {
    final a = widget.ann;
    final pages = groups[gi];
    return AnimatedBuilder(
      animation: pc!,
      builder: (context, child) {
        var delta = 0.0;
        if (pc!.hasClients && pc!.position.haveDimensions) delta = (pc!.page ?? gi.toDouble()) - gi;
        final d = delta.clamp(-1.0, 1.0).toDouble();
        final angle = d * (a.rtl ? -.45 : .45);
        return Transform(
          alignment: d > 0 ? Alignment.centerLeft : Alignment.centerRight,
          transform: Matrix4.identity()
            ..setEntry(3, 2, .0012)
            ..rotateY(angle),
          child: Opacity(opacity: (1 - d.abs() * .3).clamp(0.0, 1.0).toDouble(), child: child),
        );
      },
      child: _SpreadView(
        key: ValueKey('sp_${pages.join('_')}'),
        doc: doc!,
        pages: pages,
        ann: a,
        imageFor: _image,
        onZoom: (z) {
          if (z != zoomed) setState(() => zoomed = z);
        },
        onPin: widget.onPin,
        onSticker: widget.onSticker,
      ),
    );
  }
}

class _SpreadView extends StatefulWidget {
  const _SpreadView({super.key, required this.doc, required this.pages, required this.ann, required this.imageFor, required this.onZoom, required this.onPin, required this.onSticker});
  final PdfDocument doc;
  final List<int> pages;
  final Annotations ann;
  final Future<ui.Image?> Function(int page, int wpx, bool protect) imageFor;
  final void Function(bool zoomed) onZoom;
  final PinTap onPin;
  final StickerAction onSticker;
  @override
  State<_SpreadView> createState() => _SpreadViewState();
}

class _SpreadViewState extends State<_SpreadView> {
  final tc = TransformationController();
  Offset _dt = Offset.zero;

  @override
  void initState() {
    super.initState();
    tc.addListener(_onMatrix);
  }

  void _onMatrix() {
    widget.onZoom(tc.value.getMaxScaleOnAxis() > 1.05);
  }

  void _toggleZoom() {
    if (tc.value.getMaxScaleOnAxis() > 1.05) {
      tc.value = Matrix4.identity();
    } else {
      const s = 2.2;
      tc.value = Matrix4.identity()
        ..translateByDouble(-_dt.dx * (s - 1), -_dt.dy * (s - 1), 0, 1)
        ..scaleByDouble(s, s, 1, 1);
    }
  }

  @override
  void dispose() {
    tc.removeListener(_onMatrix);
    tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.ann;
    final drawing = a.tool != 'none';
    final dpr = MediaQuery.devicePixelRatioOf(context).clamp(1.0, 2.5);
    return LayoutBuilder(builder: (context, box) {
      final aspects = [for (final p in widget.pages) widget.doc.pages[p - 1].width / widget.doc.pages[p - 1].height];
      final totalAsp = aspects.fold<double>(0, (s, v) => s + v);
      const pad = 12.0;
      final gap = widget.pages.length > 1 ? 6.0 : 0.0;
      final availW = math.max(1.0, box.maxWidth - pad * 2 - gap);
      final availH = math.max(1.0, box.maxHeight - pad * 2);
      final h = math.min(availH, availW / totalAsp);
      final protect = toneInverts(a) && a.protectPhotos;
      // دقة متوازنة تمنع تعليق الرام بوضع الصفحتين مع الحفاظ على وضوح النص
      final maxPx = widget.pages.length > 1 ? 1350 : 2000;
      final mult = widget.pages.length > 1 ? 1.3 : 1.5;

      Widget one(int k) {
        final w = aspects[k] * h;
        final wpx = (w * dpr * mult).clamp(500, maxPx).round();
        return Container(
          width: w,
          height: h,
          decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black38, blurRadius: 12, offset: Offset(0, 4))]),
          child: Stack(children: [
            Positioned.fill(child: _PageImage(future: widget.imageFor(widget.pages[k], wpx, protect), ann: a)),
            Positioned.fill(child: RepaintBoundary(child: PageOverlay(page: widget.pages[k], ann: a, onPin: widget.onPin, onSticker: widget.onSticker))),
          ]),
        );
      }

      final row = Row(mainAxisSize: MainAxisSize.min, children: [
        for (var k = 0; k < widget.pages.length; k++) ...[if (k > 0) SizedBox(width: gap), one(k)],
      ]);

      return Directionality(
        textDirection: a.rtl ? TextDirection.rtl : TextDirection.ltr,
        child: GestureDetector(
          onDoubleTapDown: (d) => _dt = d.localPosition,
          onDoubleTap: drawing ? null : _toggleZoom,
          child: InteractiveViewer(
            transformationController: tc,
            panEnabled: !drawing,
            scaleEnabled: !drawing,
            minScale: 1,
            maxScale: 4,
            child: SizedBox(width: box.maxWidth, height: box.maxHeight, child: Center(child: row)),
          ),
        ),
      );
    });
  }
}

class _PageImage extends StatelessWidget {
  const _PageImage({required this.future, required this.ann});
  final Future<ui.Image?> future;
  final Annotations ann;

  @override
  Widget build(BuildContext context) => FutureBuilder<ui.Image?>(
        future: future,
        builder: (context, snap) {
          final im = snap.data;
          if (im == null) {
            return Container(color: Colors.white, child: Center(child: snap.connectionState == ConnectionState.done ? const Icon(Icons.broken_image_rounded, color: Colors.black26) : const CircularProgressIndicator(strokeWidth: 2)));
          }
          return CustomPaint(foregroundPainter: _ToneP(ann), child: RawImage(image: im, fit: BoxFit.fill));
        },
      );
}

class _ToneP extends CustomPainter {
  _ToneP(this.ann);
  final Annotations ann;
  @override
  void paint(Canvas canvas, Size size) => paintTone(canvas, Offset.zero & size, ann);
  @override
  bool shouldRepaint(_ToneP o) => o.ann.toneSig != ann.toneSig;
}

// ---------- حماية الصور بالوضع الليلي (نسخة محسّنة بدقة ألوان حقيقية) ----------
// في الوضع الليلي: يمر كل بكسل x بـ paintTone ثم kInvert لينتج: final = tx - x*(tx - bg).
// لذلك للحفاظ على اللون الأصلي p للصورة بدون تشويه أو تلوين بالثيم، نحسب العكس الدقيق:
// x = (tx - p) / (tx - bg) داخل مناطق الصور المكتشفة!
Future<ui.Image?> _protectPhotos(ui.Image im, Color bg, Color tx) async {
  try {
    final w = im.width, h = im.height;
    final bd = await im.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (bd == null) return null;
    final out = await compute(_protectIsolate, <Object>[
      Uint8List.fromList(bd.buffer.asUint8List()),
      w,
      h,
      (bg.r * 255).round(),
      (bg.g * 255).round(),
      (bg.b * 255).round(),
      (tx.r * 255).round(),
      (tx.g * 255).round(),
      (tx.b * 255).round(),
    ]);
    if (out == null) return null;
    final c = Completer<ui.Image>();
    ui.decodeImageFromPixels(out, w, h, ui.PixelFormat.rgba8888, c.complete);
    return await c.future;
  } catch (_) {
    return null;
  }
}

Uint8List? _protectIsolate(List<Object> a) {
  final px = a[0] as Uint8List;
  final w = a[1] as int, h = a[2] as int;
  final bgR = (a[3] as int) / 255.0, bgG = (a[4] as int) / 255.0, bgB = (a[5] as int) / 255.0;
  final txR = (a[6] as int) / 255.0, txG = (a[7] as int) / 255.0, txB = (a[8] as int) / 255.0;
  final dR = math.max(0.05, txR - bgR);
  final dG = math.max(0.05, txG - bgG);
  final dB = math.max(0.05, txB - bgB);

  const blk = 16;
  final bw = (w + blk - 1) ~/ blk, bh = (h + blk - 1) ~/ blk;
  final photo = List<bool>.filled(bw * bh, false);

  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      var mid = 0, col = 0, dark = 0, light = 0, n = 0;
      final y1 = math.min(h, (by + 1) * blk), x1 = math.min(w, (bx + 1) * blk);
      for (var y = by * blk; y < y1; y += 2) {
        for (var x = bx * blk; x < x1; x += 2) {
          final i = (y * w + x) * 4;
          final r = px[i], g = px[i + 1], b = px[i + 2];
          final mx = math.max(r, math.max(g, b)), mn = math.min(r, math.min(g, b));
          final lum = (r * 299 + g * 587 + b * 114) ~/ 1000;
          if (mx - mn > 26) col++;
          if (lum > 35 && lum < 220) mid++;
          if (lum <= 35) dark++;
          if (lum >= 220) light++;
          n++;
        }
      }
      if (n > 0) {
        // كشف الصور الملونة أو ذات التدرجات المستمرة (بدون الخلط مع النص الأسود على خلفية بيضاء)
        final isColorBlock = col * 100 / n > 30;
        final isContinuousTone = mid * 100 / n > 50 && (dark + light) * 100 / n < 45;
        if (isColorBlock || isContinuousTone) photo[by * bw + bx] = true;
      }
    }
  }

  // تنقية الضوضاء (إبقاء الكتل المتجاورة فقط)
  final keep = List<bool>.filled(bw * bh, false);
  var total = 0;
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (!photo[by * bw + bx]) continue;
      var c = 0;
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          final yy = by + dy, xx = bx + dx;
          if (yy >= 0 && yy < bh && xx >= 0 && xx < bw && photo[yy * bw + xx]) c++;
        }
      }
      if (c >= 4) {
        keep[by * bw + bx] = true;
        total++;
      }
    }
  }
  if (total == 0) return null;
  // إذا كانت الصفحة ممسوحة ضوئياً بالكامل (أكتر من 90% خلفية رمادية/صفراء) نتركها للقلب العادي
  if (total * 100 / (bw * bh) > 90) return null;

  // سد الفجوات الداخلية في الصور (تمديد بسيط لتغطية الحواف الفاتحة داخل الصورة)
  final fin = List<bool>.filled(bw * bh, false);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (keep[by * bw + bx]) {
        fin[by * bw + bx] = true;
        continue;
      }
      var around = 0;
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          final yy = by + dy, xx = bx + dx;
          if (yy >= 0 && yy < bh && xx >= 0 && xx < bw && keep[yy * bw + xx]) around++;
        }
      }
      if (around >= 4) fin[by * bw + bx] = true;
    }
  }

  final res = Uint8List.fromList(px);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (!fin[by * bw + bx]) continue;
      final y1 = math.min(h, (by + 1) * blk), x1 = math.min(w, (bx + 1) * blk);
      for (var y = by * blk; y < y1; y++) {
        for (var x = bx * blk; x < x1; x++) {
          final i = (y * w + x) * 4;
          final pr = res[i] / 255.0;
          final pg = res[i + 1] / 255.0;
          final pb = res[i + 2] / 255.0;
          res[i] = (((txR - pr) / dR).clamp(0.0, 1.0) * 255).round();
          res[i + 1] = (((txG - pg) / dG).clamp(0.0, 1.0) * 255).round();
          res[i + 2] = (((txB - pb) / dB).clamp(0.0, 1.0) * 255).round();
        }
      }
    }
  }
  return res;
}
