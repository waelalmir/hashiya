import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'annotations.dart';
import 'store.dart';

/// حزمة .hashiya: ملف واحد فيه الملاحظات (+ ملفات مرفقة + اختيارياً ملف الكتاب نفسه).
/// الصيغة الجديدة HSH2: ترويسة ثم مقاطع [اسم، حجم، بيانات] تُكتب وتُقرأ بالتدفق (بدون تحميل الملف كله بالذاكرة).
/// الصيغة القديمة (gzip + JSON) ما زالت مدعومة عند الاستيراد.
abstract class _Pack {
  _Pack(this.meta, this.ann);
  final Map<String, dynamic> meta, ann;
  bool get hasBook => meta['hasBook'] == true;
  Future<bool> extract(String name, String dest);
  Future<void> close();
}

class _PackV2 extends _Pack {
  _PackV2(super.meta, super.ann, this.raf, this.idx);
  final RandomAccessFile raf;
  final Map<String, List<int>> idx; // name -> [offset, size]

  @override
  Future<bool> extract(String name, String dest) async {
    final e = idx[name];
    if (e == null) return false;
    await raf.setPosition(e[0]);
    var left = e[1];
    final out = File(dest).openWrite();
    while (left > 0) {
      final chunk = await raf.read(math.min(left, 1 << 20));
      if (chunk.isEmpty) break;
      out.add(chunk);
      left -= chunk.length;
    }
    await out.close();
    return true;
  }

  @override
  Future<void> close() => raf.close();
}

class _PackLegacy extends _Pack {
  _PackLegacy(super.meta, super.ann, this.files);
  final Map<String, dynamic> files;

  @override
  Future<bool> extract(String name, String dest) async {
    final b64 = files[name];
    if (b64 is! String) return false;
    await File(dest).writeAsBytes(base64Decode(b64));
    return true;
  }

  @override
  Future<void> close() async {}
}

class Backup {
  static String _safe(String s) => s.replaceAll(RegExp(r'[^\w\u0600-\u06FF\- ]'), '_').trim();
  static String _mb(int bytes) => '${(bytes / 1048576).toStringAsFixed(1)} ميغا';

  static List<int> _u64(int v) => [for (var i = 7; i >= 0; i--) (v >> (i * 8)) & 255];

  static Future<void> _header(RandomAccessFile raf, String name, int size) async {
    final nb = utf8.encode(name);
    await raf.writeFrom([nb.length >> 8, nb.length & 255]);
    await raf.writeFrom(nb);
    await raf.writeFrom(_u64(size));
  }

  static Future<void> _bytesEntry(RandomAccessFile raf, String name, List<int> data) async {
    await _header(raf, name, data.length);
    await raf.writeFrom(data);
  }

  static Future<void> _fileEntry(RandomAccessFile raf, String name, File f) async {
    await _header(raf, name, await f.length());
    await for (final chunk in f.openRead()) {
      await raf.writeFrom(chunk);
    }
  }

  // ===================== التصدير =====================
  static Future<void> exportBook(BuildContext context, Book book, Annotations ann) async {
    final bookSize = await File(book.path).length();
    var incBook = true, incMedia = false;
    final go = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: const Text('تصدير الملاحظات'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('بيُنشأ ملف .hashiya فيه الرسم والستيكرات والتعليقات والتسجيلات، وبيفتح مباشرة بتطبيق حاشية.'),
            const SizedBox(height: 8),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: incBook,
              onChanged: (v) => set(() => incBook = v ?? false),
              title: const Text('تضمين ملف الكتاب (PDF)'),
              subtitle: Text('الصديق ما بيحتاج يكون عنده الكتاب (${_mb(bookSize)})'),
            ),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: incMedia,
              onChanged: (v) => set(() => incMedia = v ?? false),
              title: const Text('تضمين الصوت والفيديو المرفقين'),
              subtitle: const Text('بيكبّر الملف'),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('تصدير ومشاركة')),
          ],
        ),
      ),
    );
    if (go != true || !context.mounted) return;
    RandomAccessFile? raf;
    try {
      await ann.flush();
      final j = ann.exportJson();
      final attach = <String, File>{};
      var n = 0;
      String? pack(String? path, {bool media = false}) {
        if (path == null) return null;
        final f = File(path);
        if (!f.existsSync() || (media && !incMedia)) return null;
        final name = 'files/${n++}_${path.split('/').last}';
        attach[name] = f;
        return name;
      }

      for (final p in (j['pins'] as List)) {
        final m = p as Map<String, dynamic>;
        m['au'] = pack(m['au'] as String?);
        m['md'] = pack(m['md'] as String?, media: true);
      }
      for (final s in (j['stickers'] as List)) {
        final m = s as Map<String, dynamic>;
        m['im'] = pack(m['im'] as String?);
      }
      final meta = {'v': 2, 'title': book.title, 'pages': book.total, 'fp': await Store.fingerprint(book.path), 'hasBook': incBook};
      final dir = Directory('${Store.dir.path}/export');
      await dir.create(recursive: true);
      final file = File('${dir.path}/${_safe(book.title)}.hashiya');
      raf = await file.open(mode: FileMode.write);
      await raf.writeFrom(const [0x48, 0x53, 0x48, 0x32]); // HSH2
      await _bytesEntry(raf, 'meta', utf8.encode(jsonEncode(meta)));
      await _bytesEntry(raf, 'ann', utf8.encode(jsonEncode(j)));
      for (final e in attach.entries) {
        await _fileEntry(raf, e.key, e.value);
      }
      if (incBook) await _fileEntry(raf, 'book.pdf', File(book.path));
      await raf.close();
      raf = null;
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/octet-stream', name: '${_safe(book.title)}.hashiya')],
        text: 'ملاحظاتي على: ${book.title}\nافتح الملف بتطبيق حاشية${incBook ? ' (الكتاب مضمّن داخله)' : ' (لازم يكون عندك نفس الكتاب بالمكتبة)'}.',
      );
    } catch (e) {
      await raf?.close();
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل التصدير: $e')));
    }
  }

  // ===================== الاستيراد =====================
  static Future<_Pack> _open(String path) async {
    final raf = await File(path).open();
    final head = await raf.read(4);
    if (head.length == 4 && head[0] == 0x48 && head[1] == 0x53 && head[2] == 0x48 && head[3] == 0x32) {
      final idx = <String, List<int>>{};
      final len = await raf.length();
      var pos = 4;
      while (pos + 2 <= len) {
        await raf.setPosition(pos);
        final h = await raf.read(2);
        if (h.length < 2) break;
        final nl = (h[0] << 8) | h[1];
        final name = utf8.decode(await raf.read(nl));
        final sz = await raf.read(8);
        var size = 0;
        for (final b in sz) {
          size = size * 256 + b;
        }
        final off = pos + 2 + nl + 8;
        idx[name] = [off, size];
        pos = off + size;
      }
      Future<Map<String, dynamic>> readJson(String name) async {
        final e = idx[name];
        if (e == null) throw 'ملف غير صالح';
        await raf.setPosition(e[0]);
        return jsonDecode(utf8.decode(await raf.read(e[1]))) as Map<String, dynamic>;
      }

      return _PackV2(await readJson('meta'), await readJson('ann'), raf, idx);
    }
    await raf.close();
    final box = jsonDecode(utf8.decode(gzip.decode(await File(path).readAsBytes()))) as Map<String, dynamic>;
    final meta = box['meta'] as Map<String, dynamic>?;
    final ann = box['ann'] as Map<String, dynamic>?;
    if (meta == null || ann == null) throw 'ملف غير صالح';
    return _PackLegacy(meta, ann, (box['files'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{});
  }

  static Future<void> importFile(BuildContext context, {String? path}) async {
    void snack(String m) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }

    _Pack? opened;
    try {
      var src = path;
      if (src == null) {
        final r = await FilePicker.platform.pickFiles(type: FileType.any);
        if (r == null || r.files.isEmpty || r.files.single.path == null) return;
        src = r.files.single.path!;
      }
      try {
        opened = await _open(src);
      } catch (_) {
        snack('هذا ليس ملف .hashiya صالح');
        return;
      }
      if (opened == null) return;
      final pk = opened;
      final meta = pk.meta;
      final j = pk.ann;
      final books = Store.books.value;
      final fps = <String, String>{};
      for (final b in books) {
        fps[b.id] = await Store.fingerprint(b.path);
      }
      final matched = books.where((b) => fps[b.id] == meta['fp']).toList();
      if (books.isEmpty && !pk.hasBook) {
        snack('أضف الكتاب إلى مكتبتك أولاً ثم استورد الملاحظات');
        return;
      }
      final sorted = [...books]..sort((a, b) {
          int score(Book x) => fps[x.id] == meta['fp'] ? 0 : (x.title == meta['title'] ? 1 : 2);
          return score(a).compareTo(score(b));
        });
      if (!context.mounted) return;
      final choice = await showDialog<Object>(
        context: context,
        builder: (c) => SimpleDialog(
          title: Text('طبّق ملاحظات "${meta['title']}"'),
          children: [
            if (pk.hasBook)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(c, 'new'),
                child: Text(matched.isEmpty ? '➕ إضافة الكتاب إلى مكتبتي (من الملف)' : '➕ إضافته ككتاب جديد (نسخة ثانية)', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            for (final b in sorted)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(c, b),
                child: Text('${b.title}${fps[b.id] == meta['fp'] ? '  ✓ نفس الملف' : ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
          ],
        ),
      );
      if (choice == null || !context.mounted) return;
      Book target;
      var replace = false;
      if (choice == 'new') {
        final tmp = '${Store.dir.path}/imported/tmp_${DateTime.now().millisecondsSinceEpoch}.pdf';
        await Directory('${Store.dir.path}/imported').create(recursive: true);
        if (!await pk.extract('book.pdf', tmp)) {
          snack('الملف ما فيه نسخة الكتاب');
          return;
        }
        target = await Store.addFromFile(tmp, (meta['title'] as String?) ?? 'كتاب');
        try {
          await File(tmp).delete();
        } catch (_) {}
      } else {
        target = choice as Book;
        final r = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('كيف نطبّقها؟'),
            content: const Text('دمج: بتنضاف للملاحظات الحالية.\nاستبدال: بتنمسح ملاحظات هذا الكتاب وتحل مكانها المستوردة.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
              OutlinedButton(onPressed: () => Navigator.pop(c, false), child: const Text('دمج')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('استبدال')),
            ],
          ),
        );
        if (r == null) return;
        replace = r;
      }
      final dir = Directory('${Store.dir.path}/imported/${target.id}');
      await dir.create(recursive: true);
      final stamp = DateTime.now().millisecondsSinceEpoch;
      Future<String?> unpack(String? rel) async {
        if (rel == null) return null;
        final dest = '${dir.path}/${stamp}_${rel.split('/').last}';
        return await pk.extract(rel, dest) ? dest : null;
      }

      for (final p in (j['pins'] as List? ?? [])) {
        final m = p as Map<String, dynamic>;
        m['au'] = await unpack(m['au'] as String?);
        m['md'] = await unpack(m['md'] as String?);
      }
      for (final s in (j['stickers'] as List? ?? [])) {
        final m = s as Map<String, dynamic>;
        m['im'] = await unpack(m['im'] as String?);
      }
      final a = await Annotations.open(target.id);
      a.importJson(j, replace: replace);
      await a.flush();
      a.dispose();
      snack('تم استيراد الملاحظات إلى "${target.title}"');
    } catch (e) {
      snack('تعذّر قراءة الملف: $e');
    } finally {
      await opened?.close();
    }
  }
}
