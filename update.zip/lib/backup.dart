import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'annotations.dart';
import 'store.dart';

/// تصدير/استيراد ملاحظات كتاب بصيغة .hashiya (ملف مضغوط قابل للتعديل بعد الاستيراد).
class Backup {
  static String _safe(String s) => s.replaceAll(RegExp(r'[^\w\u0600-\u06FF\- ]'), '_').trim();

  /// تصدير ملاحظات كتاب مفتوح ومشاركتها.
  static Future<void> exportBook(BuildContext context, Book book, Annotations ann) async {
    final withMedia = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تصدير الملاحظات'),
        content: const Text('بيُنشأ ملف .hashiya فيه الرسم والستيكرات والتعليقات والتسجيلات. صديقك بيستورده بعد ما يضيف نفس الكتاب عنده.\n\nتضمين ملفات الصوت والفيديو المرفقة؟ (قد تكبّر الملف كتير)'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
          OutlinedButton(onPressed: () => Navigator.pop(c, false), child: const Text('بدون المرفقات')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('مع المرفقات')),
        ],
      ),
    );
    if (withMedia == null || !context.mounted) return;
    try {
      await ann.flush();
      final files = <String, String>{};
      final j = ann.exportJson();
      var n = 0;
      Future<String?> pack(String? path, {bool media = false}) async {
        if (path == null) return null;
        final f = File(path);
        if (!await f.exists() || (media && !withMedia)) return null;
        final name = 'files/${n++}_${path.split('/').last}';
        files[name] = base64Encode(await f.readAsBytes());
        return name;
      }

      for (final p in (j['pins'] as List)) {
        final m = p as Map<String, dynamic>;
        m['au'] = await pack(m['au'] as String?);
        m['md'] = await pack(m['md'] as String?, media: true);
      }
      for (final s in (j['stickers'] as List)) {
        final m = s as Map<String, dynamic>;
        m['im'] = await pack(m['im'] as String?);
      }
      final meta = {'v': 1, 'title': book.title, 'pages': book.total, 'fp': await Store.fingerprint(book.path)};
      final out = gzip.encode(utf8.encode(jsonEncode({'meta': meta, 'ann': j, 'files': files})));
      final dir = Directory('${Store.dir.path}/export');
      await dir.create(recursive: true);
      final file = File('${dir.path}/${_safe(book.title)}.hashiya');
      await file.writeAsBytes(out);
      await Share.shareXFiles([XFile(file.path)], text: 'ملاحظاتي على: ${book.title}');
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل التصدير: $e')));
    }
  }

  /// استيراد ملف .hashiya وتطبيقه على كتاب من المكتبة.
  static Future<void> importFile(BuildContext context) async {
    void snack(String m) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }

    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      if (r == null || r.files.isEmpty || r.files.single.path == null) return;
      final box = jsonDecode(utf8.decode(gzip.decode(await File(r.files.single.path!).readAsBytes()))) as Map<String, dynamic>;
      final meta = box['meta'] as Map<String, dynamic>?;
      final j = box['ann'] as Map<String, dynamic>?;
      final fileMap = (box['files'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
      if (meta == null || j == null) {
        snack('هذا ليس ملف .hashiya صالح');
        return;
      }
      final books = Store.books.value;
      if (books.isEmpty) {
        snack('أضف الكتاب إلى مكتبتك أولاً ثم استورد الملاحظات');
        return;
      }
      // مطابقة الكتاب: بالبصمة أولاً ثم بالعنوان
      final fps = <String, String>{};
      for (final b in books) {
        fps[b.id] = await Store.fingerprint(b.path);
      }
      final sorted = [...books]..sort((a, b) {
          int score(Book x) => fps[x.id] == meta['fp'] ? 0 : (x.title == meta['title'] ? 1 : 2);
          return score(a).compareTo(score(b));
        });
      if (!context.mounted) return;
      final target = await showDialog<Book>(
        context: context,
        builder: (c) => SimpleDialog(
          title: Text('طبّق ملاحظات "${meta['title']}" على أي كتاب؟'),
          children: [
            for (final b in sorted)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(c, b),
                child: Text('${b.title}${fps[b.id] == meta['fp'] ? '  ✓ نفس الملف' : ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
          ],
        ),
      );
      if (target == null || !context.mounted) return;
      final replace = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('كيف نطبّقها؟'),
          content: const Text('دمج: بتنضاف للملاحظات الحالية.\nاستبدال: بتنمسح ملاحظات هذا الكتاب وتحل مكانها المستوردة.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
            OutlinedButton(onPressed: () => Navigator.pop(c, false), child: const Text('دمج')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('استبدال')),
          ],
        ),
      );
      if (replace == null) return;
      // استخراج الملفات المرفقة وتعديل المسارات
      final dir = Directory('${Store.dir.path}/imported/${target.id}');
      await dir.create(recursive: true);
      final stamp = DateTime.now().millisecondsSinceEpoch;
      Future<String?> unpack(String? rel) async {
        if (rel == null) return null;
        final b64 = fileMap[rel];
        if (b64 is! String) return null;
        final f = File('${dir.path}/${stamp}_${rel.split('/').last}');
        await f.writeAsBytes(base64Decode(b64));
        return f.path;
      }

      for (final p in (j['pins'] as List? ?? [])) {
        final m = p as Map<String, dynamic>;
        m['au'] = await unpack(m['au'] as String?);
        m['md'] = await unpack(m['md'] as String?);
      }
      for (final s in (j['stickers'] as List? ?? [])) {
        final m = s as Map<String, dynamic>;
        m['im'] = await unpack(m['im'] as String?);
      }
      final a = await Annotations.open(target.id);
      a.importJson(j, replace: replace);
      await a.flush();
      a.dispose();
      snack('تم استيراد الملاحظات إلى "${target.title}"');
    } catch (e) {
      snack('تعذّر قراءة الملف: $e');
    }
  }
}
