import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'data.dart';

class AiException implements Exception {
  AiException(this.message, {this.rateLimited = false, this.retryable = false, this.skipModel = false});
  final String message;
  final bool rateLimited;
  final bool retryable; // ضغط/عطل مؤقت عند الخادم: يستحق إعادة المحاولة
  final bool skipModel; // النموذج غير متاح: جرّب نموذجاً آخر
  @override
  String toString() => message;
}

/// عميل بسيط لـ Gemini عبر REST (مفتاح مجاني من Google AI Studio).
class Gemini {
  static const defaultModel = 'gemini-3.8-flash';
  static const fallbackModel = 'gemini-3.5-flash-lite';

  static Future<String> ask(String prompt, {List<int>? imagePng, List<List<int>>? images, String? system, bool json = false}) async {
    final key = AppData.aiKey.value.trim();
    if (key.isEmpty) throw AiException('أدخل مفتاح Gemini أولاً (المساعد الذكي أو الإعدادات)');
    final m = AppData.aiModel.value.trim();
    final model = m.isEmpty ? defaultModel : m;
    final parts = <Map<String, dynamic>>[
      {'text': prompt},
      if (imagePng != null) {'inline_data': {'mime_type': 'image/png', 'data': base64Encode(imagePng)}},
      for (final im in images ?? const <List<int>>[]) {'inline_data': {'mime_type': 'image/png', 'data': base64Encode(im)}},
    ];
    final body = <String, dynamic>{
      'contents': [
        {'role': 'user', 'parts': parts}
      ],
      if (json) 'generationConfig': {'responseMimeType': 'application/json'},
      if (system != null)
        'system_instruction': {
          'parts': [
            {'text': system}
          ]
        },
    };
    // عند ضغط الخادم: نعيد المحاولة بتأخير متزايد، ثم نجرب نموذجاً أخف.
    final models = <String>{model, defaultModel, fallbackModel}.toList();
    AiException? last;
    for (final mdl in models) {
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          return await _once(mdl, key, body);
        } on AiException catch (e) {
          last = e;
          if (e.skipModel) break;
          if (!e.retryable) rethrow;
          if (attempt < 2) await Future.delayed(Duration(seconds: 3 + attempt * 5));
        }
      }
    }
    if (last != null && last.skipModel) {
      throw AiException('ما في نموذج متاح بحسابك. اكتب اسم نموذج صالح من aistudio.google.com بخانة النموذج (مثلاً $defaultModel).');
    }
    throw AiException('خوادم Gemini مضغوطة حالياً (${last?.message ?? ''}). جرّب بعد دقائق.');
  }

  static Future<String> _once(String model, String key, Map<String, dynamic> body) async {
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.postUrl(uri);
      req.headers.set('content-type', 'application/json; charset=utf-8');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 120));
      final txt = await res.transform(utf8.decoder).join();
      Map<String, dynamic> j;
      try {
        j = jsonDecode(txt) as Map<String, dynamic>;
      } catch (_) {
        throw AiException('رد غير مفهوم من الخادم (${res.statusCode})', retryable: res.statusCode >= 500);
      }
      if (res.statusCode != 200) {
        final msg = ((j['error'] as Map?)?['message'] as String?) ?? 'خطأ ${res.statusCode}';
        if (res.statusCode == 404 || msg.toLowerCase().contains('no longer available')) throw AiException('النموذج $model غير متاح لحسابك', skipModel: true);
        if (res.statusCode == 429) throw AiException('تجاوزت حد الاستخدام المجاني. جرّب بعد قليل.', rateLimited: true);
        if (res.statusCode >= 500) throw AiException('الخادم مشغول (${res.statusCode})', retryable: true);
        if (res.statusCode == 400 || res.statusCode == 403) throw AiException('رفض الخادم الطلب: $msg');
        throw AiException(msg);
      }
      final cands = j['candidates'] as List?;
      final out = StringBuffer();
      if (cands != null && cands.isNotEmpty) {
        final ps = ((cands.first as Map)['content'] as Map?)?['parts'] as List?;
        for (final p in ps ?? const []) {
          final t = (p as Map)['text'];
          if (t is String) out.write(t);
        }
      }
      final r = out.toString().trim();
      if (r.isEmpty) throw AiException('لم يرجع الذكاء الاصطناعي نصاً (ربما حجب المحتوى).');
      return r;
    } on SocketException {
      throw AiException('لا يوجد اتصال بالإنترنت');
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال', retryable: true);
    } finally {
      client.close();
    }
  }

  static const ocrPrompt = 'استخرج النص الموجود في هذه الصورة كما هو تماماً دون أي شرح أو إضافة، وحافظ على ترتيب الأسطر والفقرات. النص عربي غالباً وقد يحوي كلمات إنجليزية.';
  static const studySystem = 'أنت مساعد دراسة. أجب بالعربية الفصحى المبسطة وبإيجاز ودقة، اعتماداً على النص المرفق فقط. إن لم تجد الجواب في النص فقل ذلك صراحة.';
}
