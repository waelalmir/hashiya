import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'data.dart';

class AiException implements Exception {
  AiException(this.message, {this.rateLimited = false, this.retryable = false, this.skipModel = false});
  final String message;
  final bool rateLimited;
  final bool retryable; // ضغط/عطل مؤقت عند الخادم: يستحق إعادة المحاولة
  final bool skipModel; // النموذج غير متاح: جرّب نموذجاً آخر
  @override
  String toString() => message;
}

/// عميل لـ Gemini عبر REST مع دعم البث المباشر (Streaming) لتسريع ظهور الإجابة.
class Gemini {
  static const fastModel = 'gemini-3.5-flash-lite';
  static const smartModel = 'gemini-3.8-flash';
  static const defaultModel = fastModel;
  static const fallbackModel = smartModel;

  static String _resolvedModel() {
    final m = AppData.aiModel.value.trim();
    if (m.isNotEmpty) return m;
    return AppData.aiFast.value ? fastModel : smartModel;
  }

  static List<String> _modelOrder() {
    final primary = _resolvedModel();
    return <String>{primary, fastModel, smartModel}.toList();
  }

  static Map<String, dynamic> _buildBody(String prompt, {List<int>? imagePng, List<List<int>>? images, String? system, bool json = false}) {
    final parts = <Map<String, dynamic>>[
      {'text': prompt},
      if (imagePng != null) {'inline_data': {'mime_type': 'image/png', 'data': base64Encode(imagePng)}},
      for (final im in images ?? const <List<int>>[]) {'inline_data': {'mime_type': 'image/png', 'data': base64Encode(im)}},
    ];
    return <String, dynamic>{
      'contents': [
        {'role': 'user', 'parts': parts}
      ],
      if (json) 'generationConfig': {'responseMimeType': 'application/json'},
      if (system != null)
        'system_instruction': {
          'parts': [
            {'text': system}
          ]
        },
    };
  }

  static Future<String> ask(String prompt, {List<int>? imagePng, List<List<int>>? images, String? system, bool json = false}) async {
    final key = AppData.aiKey.value.trim();
    if (key.isEmpty) throw AiException('أدخل مفتاح Gemini أولاً (المساعد الذكي أو الإعدادات)');
    final body = _buildBody(prompt, imagePng: imagePng, images: images, system: system, json: json);
    final models = _modelOrder();
    AiException? last;
    for (final mdl in models) {
      for (var attempt = 0; attempt < 2; attempt++) {
        try {
          return await _once(mdl, key, body);
        } on AiException catch (e) {
          last = e;
          if (e.skipModel || e.rateLimited) break; // انتقل فوراً للنموذج البديل عند تجاوز الحد
          if (!e.retryable) rethrow;
          if (attempt < 1) await Future.delayed(Duration(seconds: 1 + attempt * 2));
        }
      }
    }
    if (last != null && last.skipModel) {
      throw AiException('ما في نموذج متاح بحسابك. اكتب اسم نموذج صالح من aistudio.google.com بخانة النموذج (مثلاً $fastModel).');
    }
    if (last != null && last.rateLimited) {
      throw AiException('تجاوزت حد الاستخدام المجاني مؤقتاً. انتظر دقيقة وجرّب مجدداً، أو فعّل الوضع السريع.');
    }
    throw AiException('خوادم Gemini مضغوطة حالياً (${last?.message ?? ''}). جرّب بعد قليل.');
  }

  /// بث مباشر للإجابة كلمة بكلمة (SSE) حتى تظهر النتيجة فوراً بدون انتظار اكتمال النص.
  static Stream<String> askStream(String prompt, {List<int>? imagePng, List<List<int>>? images, String? system}) async* {
    final key = AppData.aiKey.value.trim();
    if (key.isEmpty) throw AiException('أدخل مفتاح Gemini أولاً (المساعد الذكي أو الإعدادات)');
    final body = _buildBody(prompt, imagePng: imagePng, images: images, system: system);
    final models = _modelOrder();
    AiException? last;
    for (final mdl in models) {
      var yieldedAny = false;
      try {
        await for (final chunk in _streamOnce(mdl, key, body)) {
          yieldedAny = true;
          yield chunk;
        }
        if (yieldedAny) return;
      } on AiException catch (e) {
        last = e;
        if (yieldedAny) rethrow;
        if (e.skipModel || e.rateLimited || e.retryable) continue;
        rethrow;
      }
    }
    if (last != null) throw last;
    throw AiException('لم يرجع الذكاء الاصطناعي نصاً.');
  }

  static Stream<String> _streamOnce(String model, String key, Map<String, dynamic> body) async* {
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await client.postUrl(uri);
      req.headers.set('content-type', 'application/json; charset=utf-8');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 45));
      if (res.statusCode != 200) {
        final txt = await res.transform(utf8.decoder).join();
        _throwHttpError(res.statusCode, model, txt);
      }
      final lines = res.transform(utf8.decoder).transform(const LineSplitter());
      await for (final line in lines) {
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload.isEmpty || payload == '[DONE]') continue;
        try {
          final j = jsonDecode(payload) as Map<String, dynamic>;
          final cands = j['candidates'] as List?;
          if (cands != null && cands.isNotEmpty) {
            final ps = ((cands.first as Map)['content'] as Map?)?['parts'] as List?;
            for (final p in ps ?? const []) {
              final t = (p as Map)['text'];
              if (t is String && t.isNotEmpty) yield t;
            }
          }
        } catch (_) {}
      }
    } on SocketException {
      throw AiException('لا يوجد اتصال بالإنترنت');
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال', retryable: true);
    } finally {
      client.close();
    }
  }

  static Never _throwHttpError(int statusCode, String model, String txt) {
    String msg = 'خطأ $statusCode';
    try {
      final j = jsonDecode(txt) as Map<String, dynamic>;
      msg = ((j['error'] as Map?)?['message'] as String?) ?? msg;
    } catch (_) {}
    if (statusCode == 404 || msg.toLowerCase().contains('no longer available')) {
      throw AiException('النموذج $model غير متاح لحسابك', skipModel: true);
    }
    if (statusCode == 429) {
      throw AiException('تجاوزت حد الاستخدام المجاني. جرّب بعد قليل.', rateLimited: true);
    }
    if (statusCode >= 500) {
      throw AiException('الخادم مشغول ($statusCode)', retryable: true);
    }
    if (statusCode == 400 || statusCode == 403) {
      throw AiException('رفض الخادم الطلب: $msg');
    }
    throw AiException(msg);
  }

  static Future<String> _once(String model, String key, Map<String, dynamic> body) async {
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await client.postUrl(uri);
      req.headers.set('content-type', 'application/json; charset=utf-8');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 90));
      final txt = await res.transform(utf8.decoder).join();
      if (res.statusCode != 200) _throwHttpError(res.statusCode, model, txt);
      Map<String, dynamic> j;
      try {
        j = jsonDecode(txt) as Map<String, dynamic>;
      } catch (_) {
        throw AiException('رد غير مفهوم من الخادم (${res.statusCode})', retryable: res.statusCode >= 500);
      }
      final cands = j['candidates'] as List?;
      final out = StringBuffer();
      if (cands != null && cands.isNotEmpty) {
        final ps = ((cands.first as Map)['content'] as Map?)?['parts'] as List?;
        for (final p in ps ?? const []) {
          final t = (p as Map)['text'];
          if (t is String) out.write(t);
        }
      }
      final r = out.toString().trim();
      if (r.isEmpty) throw AiException('لم يرجع الذكاء الاصطناعي نصاً (ربما حجب المحتوى).');
      return r;
    } on SocketException {
      throw AiException('لا يوجد اتصال بالإنترنت');
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال', retryable: true);
    } finally {
      client.close();
    }
  }

  static const ocrPrompt = 'استخرج النص الموجود في هذه الصورة كما هو تماماً دون أي شرح أو إضافة، وحافظ على ترتيب الأسطر والفقرات. النص عربي غالباً وقد يحوي كلمات إنجليزية.';
  static const studySystem = 'أنت مساعد دراسة. أجب بالعربية الفصحى المبسطة وبإيجاز ودقة، اعتماداً على النص المرفق فقط. إن لم تجد الجواب في النص فقل ذلك صراحة.';
}
