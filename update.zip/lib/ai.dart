import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'data.dart';

class AiException implements Exception {
  AiException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// عميل بسيط لـ Gemini عبر REST (مفتاح مجاني من Google AI Studio).
class Gemini {
  static const defaultModel = 'gemini-2.5-flash';

  static Future<String> ask(String prompt, {List<int>? imagePng, String? system}) async {
    final key = AppData.aiKey.value.trim();
    if (key.isEmpty) throw AiException('أدخل مفتاح Gemini أولاً (المساعد الذكي أو الإعدادات)');
    final m = AppData.aiModel.value.trim();
    final model = m.isEmpty ? defaultModel : m;
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent');
    final parts = <Map<String, dynamic>>[
      {'text': prompt},
      if (imagePng != null) {'inline_data': {'mime_type': 'image/png', 'data': base64Encode(imagePng)}},
    ];
    final body = <String, dynamic>{
      'contents': [
        {'role': 'user', 'parts': parts}
      ],
      if (system != null)
        'system_instruction': {
          'parts': [
            {'text': system}
          ]
        },
    };
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.postUrl(uri);
      req.headers.set('content-type', 'application/json; charset=utf-8');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 120));
      final txt = await res.transform(utf8.decoder).join();
      Map<String, dynamic> j;
      try {
        j = jsonDecode(txt) as Map<String, dynamic>;
      } catch (_) {
        throw AiException('رد غير مفهوم من الخادم (${res.statusCode})');
      }
      if (res.statusCode != 200) {
        final msg = ((j['error'] as Map?)?['message'] as String?) ?? 'خطأ ${res.statusCode}';
        if (res.statusCode == 429) throw AiException('تجاوزت حد الاستخدام المجاني. جرّب بعد قليل.');
        if (res.statusCode == 400 || res.statusCode == 403) throw AiException('رفض الخادم الطلب: $msg');
        throw AiException(msg);
      }
      final cands = j['candidates'] as List?;
      final out = StringBuffer();
      if (cands != null && cands.isNotEmpty) {
        final ps = ((cands.first as Map)['content'] as Map?)?['parts'] as List?;
        for (final p in ps ?? const []) {
          final t = (p as Map)['text'];
          if (t is String) out.write(t);
        }
      }
      final r = out.toString().trim();
      if (r.isEmpty) throw AiException('لم يرجع الذكاء الاصطناعي نصاً (ربما حجب المحتوى).');
      return r;
    } on SocketException {
      throw AiException('لا يوجد اتصال بالإنترنت');
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال');
    } finally {
      client.close();
    }
  }

  static const ocrPrompt = 'استخرج النص الموجود في هذه الصورة كما هو تماماً دون أي شرح أو إضافة، وحافظ على ترتيب الأسطر والفقرات. النص عربي غالباً وقد يحوي كلمات إنجليزية.';
  static const studySystem = 'أنت مساعد دراسة. أجب بالعربية الفصحى المبسطة وبإيجاز ودقة، اعتماداً على النص المرفق فقط. إن لم تجد الجواب في النص فقل ذلك صراحة.';
}
