import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'data.dart';
import 'store.dart';
import 'theme.dart';

/// جسر لكود أندرويد: إشعارات التركيز + ودجتات الشاشة الرئيسية + فتح كتاب من ودجت.
class Native {
  static const _ch = MethodChannel('hashiya/native');
  static void Function(String bookId)? onOpenBook;
  static bool _init = false;

  static void init() {
    if (_init) return;
    _init = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'openBook') onOpenBook?.call(call.arguments as String);
      return null;
    });
  }

  static Future<String?> launchBook() async {
    try {
      return await _ch.invokeMethod<String>('launchBook');
    } catch (_) {
      return null;
    }
  }

  static Future<void> requestNotifications() async {
    try {
      await _ch.invokeMethod('requestNotifications');
    } catch (_) {}
  }

  static Future<void> scheduleFocus(DateTime at, String title, String body) async {
    try {
      await _ch.invokeMethod('scheduleFocus', {'at': at.millisecondsSinceEpoch, 'title': title, 'body': body});
    } catch (_) {}
  }

  static Future<void> cancelFocus() async {
    try {
      await _ch.invokeMethod('cancelFocus');
    } catch (_) {}
  }

  static Future<void> updateWidgets(String json) async {
    try {
      await _ch.invokeMethod('updateWidgets', {'json': json});
    } catch (_) {}
  }
}

/// يرسل بيانات الودجتات (آخر كتاب، المهام، الإحصائيات) لأندرويد بعد كل تغيير (مع تأخير بسيط).
class WidgetSync {
  static Timer? _t;

  static void schedule() {
    _t?.cancel();
    _t = Timer(const Duration(seconds: 2), push);
  }

  static Future<void> push() async {
    try {
      final recent = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
      final last = recent.isEmpty ? null : recent.first;
      final today = AppData.dayKey();
      final pending = AppData.tasks.value.where((t) => !t.done).toList();
      final json = jsonEncode({
        'bg': HC.green.toARGB32(),
        'fg': HC.cream.toARGB32(),
        'book': last == null ? null : {'id': last.id, 'title': last.title, 'page': last.lastPage, 'total': last.total, 'cover': Store.hasCover(last) ? last.cover : null},
        'tasks': [for (final t in pending.take(6)) t.title],
        'pending': pending.length,
        'readMin': (AppData.secondsOn(today) / 60).round(),
        'focusMin': AppData.focusMinutesOn(today),
        'streak': AppData.streak,
      });
      await Native.updateWidgets(json);
    } catch (_) {}
  }
}
