import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'data.dart';
import 'paper_stickers.dart';
import 'store.dart';
import 'theme.dart';

/// تعريف القوالب التفاعلية (النمط اليدوي الدافئ + تفاعل مباشر باللمس وتقييم 5 نجوم).
class InteractiveTemplateInfo {
  const InteractiveTemplateInfo({required this.id, required this.name, required this.subtitle, required this.accent, required this.bg, required this.icon});
  final String id;
  final String name;
  final String subtitle;
  final Color accent;
  final Color bg;
  final IconData icon;
}

const kInteractiveTemplates = <InteractiveTemplateInfo>[
  InteractiveTemplateInfo(
    id: 'inter_daily',
    name: 'مخطط اليوم التفاعلي',
    subtitle: 'أولويات + خطوات يومك + 8 أكواب ماء باللمس + تقييم 5 نجوم',
    accent: Color(0xFF7A563E),
    bg: Color(0xFFFFF8F0),
    icon: Icons.wb_sunny_rounded,
  ),
  InteractiveTemplateInfo(
    id: 'inter_steps',
    name: 'خطة الأهداف والخطوات',
    subtitle: 'تتبع خطواتك مع شريط إنجاز حي + تقييم 5 نجوم + مكافأتك',
    accent: Color(0xFF865B96),
    bg: Color(0xFFFAF6FF),
    icon: Icons.checklist_rtl_rounded,
  ),
];

bool isInteractiveTemplate(String templateId) => templateId.startsWith('inter_');

/// صفحة تفاعلية كاملة للقوالب التفاعلية مع حفظ تلقائي محلياً.
class InteractiveTemplatePage extends StatefulWidget {
  const InteractiveTemplatePage({super.key, required this.meta});
  final BoardMeta meta;
  @override
  State<InteractiveTemplatePage> createState() => _InteractiveTemplatePageState();
}

class _InteractiveTemplatePageState extends State<InteractiveTemplatePage> {
  Map<String, dynamic> d = {};
  bool loaded = false;

  File get _file => File('${Store.dir.path}/inter_${widget.meta.id}.json');

  static const _hand = TextStyle(fontFamily: kPaperFont, color: Color(0xFF3A2F28));

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (await _file.exists()) {
      try {
        d = jsonDecode(await _file.readAsString()) as Map<String, dynamic>;
      } catch (_) {}
    }
    if (widget.meta.templateId == 'inter_daily') {
      d.putIfAbsent('date', () => AppData.dayKey());
      d.putIfAbsent('focus', () => '');
      d.putIfAbsent('priorities', () => [
        {'t': '', 'done': false},
        {'t': '', 'done': false},
        {'t': '', 'done': false},
      ]);
      d.putIfAbsent('steps', () => [
        {'time': '08:00 ص', 't': 'بداية اليوم وترتيب الأولويات', 'done': false},
        {'time': '11:00 ص', 't': 'جلسة دراسة عميقة', 'done': false},
        {'time': '04:00 م', 't': 'مراجعة وحل تمارين', 'done': false},
      ]);
      d.putIfAbsent('water', () => 0);
      d.putIfAbsent('ratings', () => {'الإنجاز': 0, 'التركيز': 0, 'الالتزام': 0, 'المزاج': 0});
      d.putIfAbsent('notes', () => '');
    } else {
      d.putIfAbsent('goal', () => widget.meta.title);
      d.putIfAbsent('deadline', () => '');
      d.putIfAbsent('steps', () => [
        {'t': 'تحديد المصادر والملفات المطلوبة', 'done': false},
        {'t': 'إنجاز الجزء الأول بتركيز', 'done': false},
        {'t': 'مراجعة شاملة وتثبيت المعلومات', 'done': false},
      ]);
      d.putIfAbsent('ratings', () => {'الالتزام بالخطة': 0, 'الفهم والاستيعاب': 0, 'حل الأسئلة والتدريب': 0, 'الرضا العام': 0});
      d.putIfAbsent('reward', () => '');
      d.putIfAbsent('notes', () => '');
    }
    if (mounted) setState(() => loaded = true);
  }

  Future<void> _save() async {
    widget.meta.updatedAt = DateTime.now().millisecondsSinceEpoch;
    AppData.upsertBoard(widget.meta);
    await _file.writeAsString(jsonEncode(d));
  }

  Future<String?> _promptText(String title, String initial, {String hint = ''}) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, maxLines: 3, minLines: 1, decoration: InputDecoration(hintText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Widget _card(Color border, Widget child, {Color fill = Colors.white}) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: border, width: 1.4),
          boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 8, offset: Offset(0, 3))],
        ),
        child: child,
      );

  Widget _pillTitle(String text, Color bg) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: const TextStyle(fontFamily: kPaperFont, color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.w700)),
      );

  Widget _starRatingCard(Color accent, Color border) {
    final ratings = Map<String, dynamic>.from((d['ratings'] as Map?) ?? {});
    return _card(
      border,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _pillTitle('تقييم من 5 نجوم ★', accent),
        const SizedBox(height: 10),
        for (final entry in ratings.entries)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(children: [
              Expanded(child: Text(entry.key, style: _hand.copyWith(fontSize: 14, fontWeight: FontWeight.w600))),
              for (var s = 1; s <= 5; s++)
                GestureDetector(
                  onTap: () {
                    setState(() {
                      ratings[entry.key] = (ratings[entry.key] == s) ? s - 1 : s;
                      d['ratings'] = ratings;
                    });
                    _save();
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: Icon(
                      s <= ((entry.value as num?)?.toInt() ?? 0) ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: const Color(0xFFE0A422),
                      size: 28,
                    ),
                  ),
                ),
            ]),
          ),
      ]),
    );
  }

  Widget _buildDaily() {
    const accent = Color(0xFF7A563E);
    const border = Color(0xFFE3D0BE);
    final priorities = (d['priorities'] as List).cast<Map<String, dynamic>>();
    final steps = (d['steps'] as List).cast<Map<String, dynamic>>();
    final water = (d['water'] as num?)?.toInt() ?? 0;

    return Container(
      color: const Color(0xFFFFF8F0),
      child: ListView(padding: const EdgeInsets.all(14), children: [
        Center(child: Text('مُخطّط اليوم التفاعلي', style: _hand.copyWith(fontSize: 24, fontWeight: FontWeight.w700, color: accent))),
        const SizedBox(height: 4),
        Center(
          child: InkWell(
            onTap: () async {
              final r = await _promptText('التاريخ أو عنوان اليوم', '${d['date'] ?? ''}');
              if (r != null) {
                setState(() => d['date'] = r);
                _save();
              }
            },
            child: Text('التاريخ: ${d['date']}  ✎', style: _hand.copyWith(fontSize: 13, color: accent.withValues(alpha: .8))),
          ),
        ),
        const SizedBox(height: 12),

        // أهم 3 أولويات
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _pillTitle('أهم 3 أولويات اليوم', const Color(0xFFA67B5B)),
            const SizedBox(height: 8),
            for (var i = 0; i < priorities.length; i++)
              Row(children: [
                Checkbox(
                  value: priorities[i]['done'] == true,
                  activeColor: accent,
                  onChanged: (v) {
                    setState(() => priorities[i]['done'] = v ?? false);
                    _save();
                  },
                ),
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      final r = await _promptText('الأولوية ${i + 1}', '${priorities[i]['t'] ?? ''}', hint: 'اكتب أهم إنجاز تريد تحقيقه...');
                      if (r != null) {
                        setState(() => priorities[i]['t'] = r);
                        _save();
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        (priorities[i]['t'] as String? ?? '').isEmpty ? 'اضغط لكتابة الأولوية ${i + 1}...' : priorities[i]['t'] as String,
                        style: _hand.copyWith(
                          fontSize: 14.5,
                          decoration: priorities[i]['done'] == true ? TextDecoration.lineThrough : null,
                          color: (priorities[i]['t'] as String? ?? '').isEmpty ? Colors.black38 : const Color(0xFF3A2F28),
                        ),
                      ),
                    ),
                  ),
                ),
              ]),
          ]),
        ),

        // خطوات وجدول اليوم
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _pillTitle('جدول وخطوات اليوم', accent),
              const Spacer(),
              TextButton.icon(
                onPressed: () async {
                  final r = await _promptText('إضافة خطوة جديدة', '', hint: 'مثلاً: 06:00 م · مراجعة الفصل الثالث');
                  if (r != null && r.isNotEmpty) {
                    setState(() => steps.add({'time': '', 't': r, 'done': false}));
                    _save();
                  }
                },
                icon: const Icon(Icons.add_rounded, size: 18, color: accent),
                label: const Text('إضافة', style: TextStyle(color: accent, fontWeight: FontWeight.w700)),
              ),
            ]),
            const SizedBox(height: 6),
            for (var i = 0; i < steps.length; i++)
              Row(children: [
                Checkbox(
                  value: steps[i]['done'] == true,
                  activeColor: accent,
                  onChanged: (v) {
                    setState(() => steps[i]['done'] = v ?? false);
                    _save();
                  },
                ),
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      final r = await _promptText('تعديل الخطوة', '${steps[i]['t'] ?? ''}');
                      if (r != null) {
                        setState(() => steps[i]['t'] = r);
                        _save();
                      }
                    },
                    child: Text(
                      '${(steps[i]['time'] as String? ?? '').isNotEmpty ? '${steps[i]['time']} · ' : ''}${steps[i]['t']}',
                      style: _hand.copyWith(
                        fontSize: 14,
                        decoration: steps[i]['done'] == true ? TextDecoration.lineThrough : null,
                        color: steps[i]['done'] == true ? Colors.black38 : const Color(0xFF3A2F28),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  iconSize: 18,
                  onPressed: () {
                    setState(() => steps.removeAt(i));
                    _save();
                  },
                  icon: const Icon(Icons.close_rounded, color: Colors.black38),
                ),
              ]),
          ]),
        ),

        // متتبع الماء التفاعلي (8 أكواب)
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _pillTitle('متتبع الماء ($water / 8)', const Color(0xFF568399)),
              const Spacer(),
              Text('اضغط على الكوب', style: _hand.copyWith(fontSize: 11.5, color: Colors.black45)),
            ]),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var i = 1; i <= 8; i++)
                  GestureDetector(
                    onTap: () {
                      setState(() => d['water'] = (water == i) ? i - 1 : i);
                      _save();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 32,
                      height: 38,
                      decoration: BoxDecoration(
                        color: i <= water ? const Color(0xFF66B2D6) : const Color(0xFFF0F6F9),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFF568399), width: 1.4),
                      ),
                      child: Icon(Icons.water_drop_rounded, size: 18, color: i <= water ? Colors.white : const Color(0xFF9AC2D6)),
                    ),
                  ),
              ],
            ),
          ]),
        ),

        // تقييم 5 نجوم التفاعلي
        _starRatingCard(accent, border),

        // ملاحظات وامتنان
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _pillTitle('ملاحظات وامتنان اليوم', const Color(0xFFA67B5B)),
            const SizedBox(height: 8),
            InkWell(
              onTap: () async {
                final r = await _promptText('ملاحظات وامتنان اليوم', '${d['notes'] ?? ''}');
                if (r != null) {
                  setState(() => d['notes'] = r);
                  _save();
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFFFFFBF6), borderRadius: BorderRadius.circular(10)),
                child: Text(
                  ('${d['notes'] ?? ''}').isEmpty ? 'اضغط لكتابة ملاحظاتك أو شيء ممتن له اليوم...' : '${d['notes']}',
                  style: _hand.copyWith(fontSize: 14, color: ('${d['notes'] ?? ''}').isEmpty ? Colors.black38 : const Color(0xFF3A2F28)),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildSteps() {
    const accent = Color(0xFF7B5EA7);
    const border = Color(0xFFDFD2F2);
    final steps = (d['steps'] as List).cast<Map<String, dynamic>>();
    final doneCnt = steps.where((s) => s['done'] == true).length;
    final pct = steps.isEmpty ? 0.0 : doneCnt / steps.length;

    return Container(
      color: const Color(0xFFFAF6FF),
      child: ListView(padding: const EdgeInsets.all(14), children: [
        Center(child: Text('خطة الأهداف والخطوات', style: _hand.copyWith(fontSize: 24, fontWeight: FontWeight.w700, color: accent))),
        const SizedBox(height: 8),

        // الهدف + شريط الإنجاز الحي
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _pillTitle('الهدف الرئيسي', accent),
              const Spacer(),
              Text('${(pct * 100).round()}%', style: _hand.copyWith(fontSize: 18, fontWeight: FontWeight.w700, color: accent)),
            ]),
            const SizedBox(height: 8),
            InkWell(
              onTap: () async {
                final r = await _promptText('الهدف الرئيسي', '${d['goal'] ?? ''}');
                if (r != null && r.isNotEmpty) {
                  setState(() => d['goal'] = r);
                  _save();
                }
              },
              child: Text('${d['goal'] ?? widget.meta.title}  ✎', style: _hand.copyWith(fontSize: 16.5, fontWeight: FontWeight.w700)),
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: pct,
                minHeight: 11,
                backgroundColor: const Color(0xFFEDE4FA),
                valueColor: const AlwaysStoppedAnimation<Color>(accent),
              ),
            ),
            const SizedBox(height: 6),
            Text('أنجزت $doneCnt من ${steps.length} خطوات', style: _hand.copyWith(fontSize: 12.5, color: accent.withValues(alpha: .8))),
          ]),
        ),

        // قائمة الخطوات التفاعلية
        _card(
          border,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _pillTitle('خطوات التنفيذ', const Color(0xFF5A78A8)),
              const Spacer(),
              TextButton.icon(
                onPressed: () async {
                  final r = await _promptText('خطوة جديدة', '', hint: 'اكتب الخطوة التالية...');
                  if (r != null && r.isNotEmpty) {
                    setState(() => steps.add({'t': r, 'done': false}));
                    _save();
                  }
                },
                icon: const Icon(Icons.add_rounded, size: 18, color: accent),
                label: const Text('إضافة خطوة', style: TextStyle(color: accent, fontWeight: FontWeight.w700)),
              ),
            ]),
            const SizedBox(height: 6),
            for (var i = 0; i < steps.length; i++)
              Row(children: [
                Checkbox(
                  value: steps[i]['done'] == true,
                  activeColor: accent,
                  onChanged: (v) {
                    setState(() => steps[i]['done'] = v ?? false);
                    _save();
                  },
                ),
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      final r = await _promptText('تعديل الخطوة', '${steps[i]['t'] ?? ''}');
                      if (r != null) {
                        setState(() => steps[i]['t'] = r);
                        _save();
                      }
                    },
                    child: Text(
                      '${i + 1}. ${steps[i]['t']}',
                      style: _hand.copyWith(
                        fontSize: 14.5,
                        decoration: steps[i]['done'] == true ? TextDecoration.lineThrough : null,
                        color: steps[i]['done'] == true ? Colors.black38 : const Color(0xFF3A2F28),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  iconSize: 18,
                  onPressed: () {
                    setState(() => steps.removeAt(i));
                    _save();
                  },
                  icon: const Icon(Icons.close_rounded, color: Colors.black38),
                ),
              ]),
          ]),
        ),

        // تقييم 5 نجوم التفاعلي
        _starRatingCard(accent, border),

        // مكافأتي عند الإنجاز
        _card(
          const Color(0xFFE8D59E),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _pillTitle('مكافأتي عند إتمام الخطة 🎁', const Color(0xFFC28E36)),
            const SizedBox(height: 8),
            InkWell(
              onTap: () async {
                final r = await _promptText('مكافأتي عند الالتزام', '${d['reward'] ?? ''}');
                if (r != null) {
                  setState(() => d['reward'] = r);
                  _save();
                }
              },
              child: Text(
                ('${d['reward'] ?? ''}').isEmpty ? 'اضغط لتحديد مكافأتك التحفيزية...' : '${d['reward']}',
                style: _hand.copyWith(fontSize: 14.5, color: ('${d['reward'] ?? ''}').isEmpty ? Colors.black38 : const Color(0xFF5C4212)),
              ),
            ),
          ]),
          fill: const Color(0xFFFFFAEB),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(
          backgroundColor: HC.deep,
          title: Text(widget.meta.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
        ),
        body: !loaded ? const Center(child: CircularProgressIndicator()) : (widget.meta.templateId == 'inter_daily' ? _buildDaily() : _buildSteps()),
      );
}
