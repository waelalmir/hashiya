import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'dart:ui' show Color;
import 'store.dart';
import 'native.dart';
import 'theme.dart';

class Task {
  Task({required this.id, required this.title, this.done = false, this.bookId, this.from, this.to, this.due});
  final String id;
  String title;
  bool done;
  String? bookId;
  int? from, to, due;
  Map<String, dynamic> toJson() => {'id': id, 't': title, 'd': done, 'b': bookId, 'f': from, 'to': to, 'due': due};
  factory Task.fromJson(Map<String, dynamic> j) => Task(id: j['id'], title: j['t'], done: j['d'] ?? false, bookId: j['b'], from: j['f'], to: j['to'], due: j['due']);
}

/// روتين يومي متكرر (مثل قراءة القرآن، الصلاة، الأذكار...) يتجدد تلقائياً كل يوم.
class RoutineItem {
  RoutineItem({required this.id, required this.title, this.icon = 'star', Set<String>? doneDays}) : doneDays = doneDays ?? <String>{};
  final String id;
  String title;
  String icon; // quran | pray | book | star | heart | check
  final Set<String> doneDays; // YYYY-MM-DD

  bool isDoneOn(String day) => doneDays.contains(day);

  int get streak {
    var n = 0;
    var d = DateTime.now();
    if (!doneDays.contains(AppData.dayKey(d))) d = d.subtract(const Duration(days: 1));
    while (doneDays.contains(AppData.dayKey(d))) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  Map<String, dynamic> toJson() => {'id': id, 't': title, 'ic': icon, 'days': doneDays.toList()};
  factory RoutineItem.fromJson(Map<String, dynamic> j) => RoutineItem(
        id: j['id'] as String,
        title: (j['t'] as String?) ?? '',
        icon: (j['ic'] as String?) ?? 'star',
        doneDays: {for (final d in (j['days'] as List? ?? const [])) d.toString()},
      );
}

/// سجل نتيجة اختبار واحد (يحفظ التطبيق آخر 10 نتائج).
class QuizRecord {
  QuizRecord({required this.id, required this.title, required this.at, required this.score, required this.total, this.missed = const []});
  final String id;
  final String title;
  final int at;
  final int score;
  final int total;
  final List<Map<String, String>> missed; // [{q, a, e}]

  int get percent => total == 0 ? 0 : (score * 100 / total).round();

  Map<String, dynamic> toJson() => {'id': id, 't': title, 'at': at, 's': score, 'tot': total, 'm': missed};
  factory QuizRecord.fromJson(Map<String, dynamic> j) => QuizRecord(
        id: (j['id'] as String?) ?? '',
        title: (j['t'] as String?) ?? 'اختبار',
        at: (j['at'] as num?)?.toInt() ?? 0,
        score: (j['s'] as num?)?.toInt() ?? 0,
        total: (j['tot'] as num?)?.toInt() ?? 0,
        missed: [
          for (final e in (j['m'] as List? ?? const []))
            if (e is Map) {'q': '${e['q'] ?? ''}', 'a': '${e['a'] ?? ''}', 'e': '${e['e'] ?? ''}'}
        ],
      );
}

/// بيانات تعريفية للوحة بيضاء أو قالب محفوظ.
class BoardMeta {
  BoardMeta({required this.id, required this.title, required this.templateId, required this.updatedAt, this.bookId, this.page});
  final String id;
  String title;
  String templateId;
  int updatedAt;
  String? bookId;
  int? page;
  Map<String, dynamic> toJson() => {'id': id, 't': title, 'tpl': templateId, 'u': updatedAt, if (bookId != null) 'b': bookId, if (page != null) 'p': page};
  factory BoardMeta.fromJson(Map<String, dynamic> j) => BoardMeta(
        id: j['id'] as String,
        title: (j['t'] as String?) ?? 'صفحة بيضاء',
        templateId: (j['tpl'] as String?) ?? 'blank_plain',
        updatedAt: (j['u'] as num?)?.toInt() ?? 0,
        bookId: j['b'] as String?,
        page: (j['p'] as num?)?.toInt(),
      );
}

class FocusSession {
  FocusSession({required this.at, required this.minutes, this.bookId});
  final int at, minutes;
  final String? bookId;
  Map<String, dynamic> toJson() => {'at': at, 'm': minutes, 'b': bookId};
  factory FocusSession.fromJson(Map<String, dynamic> j) => FocusSession(at: j['at'], minutes: j['m'], bookId: j['b']);
}

/// بيانات التطبيق العامة: مهام، روتين يومي، سجل امتحانات، لوحات، جلسات تركيز، وقت القراءة، إعدادات.
class AppData {
  static final tasks = ValueNotifier<List<Task>>([]);
  static final routines = ValueNotifier<List<RoutineItem>>([]);
  static final quizHistory = ValueNotifier<List<QuizRecord>>([]);
  static final boards = ValueNotifier<List<BoardMeta>>([]);
  static final sessions = ValueNotifier<List<FocusSession>>([]);
  static final reading = ValueNotifier<Map<String, Map<String, int>>>({}); // يوم -> كتاب -> ثواني
  static final name = ValueNotifier<String>('عبد الفتاح');
  static final bgPath = ValueNotifier<String?>(null);
  static final reduceBlur = ValueNotifier<bool>(false);
  static final avatar = ValueNotifier<String?>(null);
  static final mediaExternal = ValueNotifier<bool>(false);
  static final remindOn = ValueNotifier<bool>(false);
  static final remindCount = ValueNotifier<int>(1);
  static final remindT1 = ValueNotifier<int>(540); // دقائق من منتصف الليل (9:00)
  static final remindT2 = ValueNotifier<int>(1200); // 20:00
  static final aiKey = ValueNotifier<String>('');
  static final aiModel = ValueNotifier<String>('');
  static final aiFast = ValueNotifier<bool>(true); // الوضع السريع (Flash-Lite) افتراضياً لتقليل البطء
  static final themeId = ValueNotifier<String>('green');
  static final customBase = ValueNotifier<int>(0xFF064A44);
  static final customText = ValueNotifier<int>(0xFFEDE5D3);
  static AppPalette get customPalette => AppPalette('custom', 'مخصص', Color(customBase.value), Color(customText.value));

  static void applyTheme() {
    final id = themeId.value;
    HC.apply(id == 'custom' ? customPalette : kPalettes.firstWhere((e) => e.id == id, orElse: () => kPalettes.first));
  }

  static void setTheme(String id) {
    themeId.value = id;
    applyTheme();
    save();
  }

  static void setCustom({int? base, int? text}) {
    if (base != null) customBase.value = base;
    if (text != null) customText.value = text;
    themeId.value = 'custom';
    applyTheme();
    save();
  }

  static File get _f => File('${Store.dir.path}/data.json');

  static Future<void> load() async {
    if (!await _f.exists()) return;
    try {
      final j = jsonDecode(await _f.readAsString()) as Map<String, dynamic>;
      name.value = (j['name'] as String?) ?? name.value;
      bgPath.value = j['bg'] as String?;
      reduceBlur.value = (j['blur'] as bool?) ?? false;
      avatar.value = j['avatar'] as String?;
      mediaExternal.value = (j['mext'] as bool?) ?? false;
      remindOn.value = (j['rOn'] as bool?) ?? false;
      remindCount.value = (j['rCnt'] as int?) ?? 1;
      remindT1.value = (j['rT1'] as int?) ?? 540;
      remindT2.value = (j['rT2'] as int?) ?? 1200;
      aiKey.value = (j['aikey'] as String?) ?? '';
      aiModel.value = (j['aimodel'] as String?) ?? '';
      aiFast.value = (j['aiFast'] as bool?) ?? true;
      themeId.value = (j['theme'] as String?) ?? 'green';
      customBase.value = (j['cbase'] as int?) ?? customBase.value;
      customText.value = (j['ctext'] as int?) ?? customText.value;
      applyTheme();
      tasks.value = [for (final e in (j['tasks'] as List? ?? [])) Task.fromJson(e as Map<String, dynamic>)];
      routines.value = [for (final e in (j['routines'] as List? ?? [])) RoutineItem.fromJson(e as Map<String, dynamic>)];
      quizHistory.value = [for (final e in (j['quizHist'] as List? ?? [])) QuizRecord.fromJson(e as Map<String, dynamic>)];
      boards.value = [for (final e in (j['boards'] as List? ?? [])) BoardMeta.fromJson(e as Map<String, dynamic>)];
      sessions.value = [for (final e in (j['sessions'] as List? ?? [])) FocusSession.fromJson(e as Map<String, dynamic>)];
      final r = (j['reading'] as Map<String, dynamic>?) ?? {};
      reading.value = {
        for (final e in r.entries) e.key: {for (final b in (e.value as Map<String, dynamic>).entries) b.key: (b.value as num).toInt()}
      };
    } catch (_) {}
  }

  static Future<void> save() async {
    await _f.writeAsString(jsonEncode({
      'name': name.value,
      'bg': bgPath.value,
      'blur': reduceBlur.value,
      'avatar': avatar.value,
      'mext': mediaExternal.value,
      'rOn': remindOn.value,
      'rCnt': remindCount.value,
      'rT1': remindT1.value,
      'rT2': remindT2.value,
      'aikey': aiKey.value,
      'aimodel': aiModel.value,
      'aiFast': aiFast.value,
      'theme': themeId.value,
      'cbase': customBase.value,
      'ctext': customText.value,
      'tasks': tasks.value.map((e) => e.toJson()).toList(),
      'routines': routines.value.map((e) => e.toJson()).toList(),
      'quizHist': quizHistory.value.map((e) => e.toJson()).toList(),
      'boards': boards.value.map((e) => e.toJson()).toList(),
      'sessions': sessions.value.map((e) => e.toJson()).toList(),
      'reading': reading.value,
    }));
    WidgetSync.schedule();
  }

  static String dayKey([DateTime? d]) {
    final t = d ?? DateTime.now();
    return '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
  }

  static int secondsOn(String key) => (reading.value[key] ?? {}).values.fold<int>(0, (a, b) => a + b);

  static int get totalSeconds => reading.value.keys.fold<int>(0, (a, k) => a + secondsOn(k));

  static Map<String, int> perBook() {
    final m = <String, int>{};
    for (final d in reading.value.values) {
      d.forEach((b, s) => m[b] = (m[b] ?? 0) + s);
    }
    return m;
  }

  static int get streak {
    var n = 0;
    var d = DateTime.now();
    if (secondsOn(dayKey(d)) < 60) d = d.subtract(const Duration(days: 1));
    while (secondsOn(dayKey(d)) >= 60) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  static int focusMinutesOn(String key) =>
      sessions.value.where((s) => dayKey(DateTime.fromMillisecondsSinceEpoch(s.at)) == key).fold<int>(0, (a, s) => a + s.minutes);

  static void addReading(String bookId, int seconds) {
    final m = Map<String, Map<String, int>>.from(reading.value);
    final k = dayKey();
    final day = Map<String, int>.from(m[k] ?? {});
    day[bookId] = (day[bookId] ?? 0) + seconds;
    m[k] = day;
    reading.value = m;
    save();
  }

  static void addSession(FocusSession s) {
    sessions.value = [...sessions.value, s];
    save();
  }

  static void removeSession(FocusSession s) {
    sessions.value = sessions.value.where((e) => e != s).toList();
    save();
  }

  static void setTasks(List<Task> t) {
    tasks.value = t;
    save();
  }

  static void setRoutines(List<RoutineItem> r) {
    routines.value = r;
    save();
  }

  static void toggleRoutineToday(String id) {
    final today = dayKey();
    for (final r in routines.value) {
      if (r.id == id) {
        if (r.doneDays.contains(today)) {
          r.doneDays.remove(today);
        } else {
          r.doneDays.add(today);
        }
        break;
      }
    }
    routines.value = [...routines.value];
    save();
  }

  /// حفظ نتيجة اختبار جديدة (بحد أقصى آخر 10 اختبارات).
  static void addQuizRecord(QuizRecord rec) {
    final list = [rec, ...quizHistory.value];
    if (list.length > 10) list.removeRange(10, list.length);
    quizHistory.value = list;
    save();
  }

  static void clearQuizHistory() {
    quizHistory.value = [];
    save();
  }

  static void upsertBoard(BoardMeta meta) {
    final list = boards.value.where((b) => b.id != meta.id).toList();
    list.insert(0, meta);
    boards.value = list;
    save();
  }

  static void removeBoard(String id) {
    boards.value = boards.value.where((b) => b.id != id).toList();
    try {
      File('${Store.dir.path}/board_$id.json').delete();
    } catch (_) {}
    save();
  }

  static String fmtDuration(int seconds) {
    final h = seconds ~/ 3600, m = (seconds % 3600) ~/ 60;
    if (h == 0) return '$m د';
    return '$h س $m د';
  }
}
