import 'dart:async';
import 'package:flutter/material.dart';
import 'ai.dart';
import 'ocr/ocr_engine.dart';
import 'ocr_index.dart';
import 'pdf_tools.dart';
import 'store.dart';
import 'theme.dart';

/// بحث داخل الملف: يعيد النتيجة المختارة (صفحة + موضع الكلمة) أو null.
Future<SearchHit?> showSearchSheet(BuildContext context, Book book) {
  return showModalBottomSheet<SearchHit>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HC.green,
    builder: (c) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
      child: SizedBox(height: MediaQuery.sizeOf(c).height * .78, child: _SearchSheet(book: book)),
    ),
  );
}

class _SearchSheet extends StatefulWidget {
  const _SearchSheet({required this.book});
  final Book book;
  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  final c = TextEditingController();
  late final PdfSearcher searcher = PdfSearcher(widget.book.path);
  Timer? _deb;
  int _gen = 0;
  List<SearchHit> hits = [];
  int done = 0, total = 0;
  bool searching = false, searched = false;
  OcrIndex? idx;
  bool indexing = false, showIndexPanel = false, stopIndexing = false;
  String indexNote = '';
  int indexDone = 0, indexTotal = 0;

  @override
  void initState() {
    super.initState();
    OcrIndex.load(widget.book.id).then((x) {
      idx = x;
      searcher.index = x;
    });
  }

  Future<void> _index(bool online) async {
    final x = idx;
    if (x == null) return;
    setState(() {
      indexing = true;
      stopIndexing = false;
      indexNote = 'جاري التحضير...';
    });
    try {
      final n = await OcrIndexer.run(
        widget.book,
        x,
        online: online,
        cancelled: () => stopIndexing || !mounted,
        onProgress: (d, t, note) {
          if (mounted) {
            setState(() {
              indexDone = d;
              indexTotal = t;
              indexNote = note;
            });
          }
        },
      );
      if (mounted) setState(() => indexNote = n > 0 ? 'تمت فهرسة $n صفحة. جرّب البحث الآن.' : indexNote);
    } on AiException catch (e) {
      if (mounted) setState(() => indexNote = 'توقفت الفهرسة: $e');
    } catch (e) {
      if (mounted) setState(() => indexNote = 'توقفت الفهرسة: $e');
    }
    searcher.clearCache();
    if (mounted) {
      setState(() => indexing = false);
      if (c.text.trim().isNotEmpty) _run(c.text);
    }
  }

  Widget _indexPanel() => Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: HC.cream.withValues(alpha: .1), borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('فهرسة الصفحات المصوّرة (OCR)', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('الصفحات الممسوحة ضوئياً ما فيها نص، فبنقرأها بالـ OCR مرة وحدة وبنحفظ النتيجة على جهازك، وبعدها البحث بيشتغل عليها. (في هذه الصفحات التمييز ما بيظهر مكان الكلمة، بس بينفتح عليها الصفحة).', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .7))),
          const SizedBox(height: 8),
          if (indexing) ...[
            LinearProgressIndicator(value: indexTotal == 0 ? null : indexDone / indexTotal),
            const SizedBox(height: 6),
            Text(indexNote, style: const TextStyle(fontSize: 12)),
            TextButton(onPressed: () => setState(() => stopIndexing = true), child: const Text('إيقاف (بيبقى المحفوظ)')),
          ] else ...[
            Wrap(spacing: 8, runSpacing: 4, children: [
              FilledButton.tonal(onPressed: () => _index(true), child: const Text('فهرسة أونلاين (Gemini)')),
              OutlinedButton(onPressed: OcrEngine.available ? () => _index(false) : null, child: Text(OcrEngine.available ? 'فهرسة أوفلاين' : 'أوفلاين: نسخة OCR فقط')),
            ]),
            if (indexNote.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(indexNote, style: const TextStyle(fontSize: 12))),
          ],
        ]),
      );

  @override
  void dispose() {
    _gen++;
    _deb?.cancel();
    searcher.dispose();
    c.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _deb?.cancel();
    _deb = Timer(const Duration(milliseconds: 450), () => _run(v));
  }

  Future<void> _run(String q) async {
    final my = ++_gen;
    if (q.trim().isEmpty) {
      setState(() {
        hits = [];
        searching = false;
        searched = false;
      });
      return;
    }
    setState(() {
      hits = [];
      searching = true;
      searched = false;
      done = 0;
    });
    try {
      await searcher.search(
        q,
        cancelled: () => my != _gen || !mounted,
        onUpdate: (h, d, t) {
          if (my != _gen || !mounted) return;
          setState(() {
            hits = h;
            done = d;
            total = t;
          });
        },
      );
    } catch (_) {}
    if (my == _gen && mounted) {
      setState(() {
        searching = false;
        searched = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final noText = searched && hits.isEmpty && !searcher.foundAnyText;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: TextField(
          controller: c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onChanged: _onChanged,
          onSubmitted: (v) {
            _deb?.cancel();
            _run(v);
          },
          decoration: InputDecoration(
            hintText: 'ابحث عن كلمة أو جملة في الملف',
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: c.text.isEmpty ? null : IconButton(icon: const Icon(Icons.close_rounded), onPressed: () {
              c.clear();
              _run('');
            }),
            border: const OutlineInputBorder(),
          ),
        ),
      ),
      if (searching) LinearProgressIndicator(value: total == 0 ? null : done / total, minHeight: 3),
      Align(
        alignment: AlignmentDirectional.centerStart,
        child: TextButton.icon(
          onPressed: () => setState(() => showIndexPanel = !showIndexPanel),
          icon: const Icon(Icons.document_scanner_rounded, size: 18),
          label: Text(noText ? 'الملف مصوّر: فهرسة OCR للبحث' : 'فهرسة الصفحات المصوّرة (OCR)'),
        ),
      ),
      if (showIndexPanel || noText || indexing) _indexPanel(),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(
            searching ? 'جاري البحث... (${hits.length} نتيجة)' : (searched ? '${hits.length} نتيجة' : ''),
            style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65)),
          ),
        ),
      ),
      Expanded(
        child: noText
            ? Padding(
                padding: const EdgeInsets.all(24),
                child: Text('ما لقيت نصاً قابلاً للبحث بهذا الملف (غالباً صفحات ممسوحة). اضغط "فهرسة OCR" فوق وجرّب البحث بعدها.', textAlign: TextAlign.center, style: TextStyle(color: HC.cream.withValues(alpha: .75))),
              )
            : ListView.separated(
                itemCount: hits.length,
                separatorBuilder: (_, __) => Divider(height: 1, color: HC.cream.withValues(alpha: .12)),
                itemBuilder: (context, i) {
                  final h = hits[i];
                  return InkWell(
                    onTap: () => Navigator.pop(context, h),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: HC.cream.withValues(alpha: .18), borderRadius: BorderRadius.circular(10)),
                          child: Text('ص ${h.page}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: RichText(
                            textDirection: TextDirection.rtl,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            text: TextSpan(
                              style: TextStyle(fontFamily: 'IBMPlexSansArabic', fontSize: 14, height: 1.5, color: HC.cream.withValues(alpha: .85)),
                              children: [
                                TextSpan(text: '…${h.before}'),
                                TextSpan(text: h.match, style: const TextStyle(backgroundColor: Color(0xFFFFD54F), color: Color(0xFF222222), fontWeight: FontWeight.w700)),
                                TextSpan(text: '${h.after}…'),
                              ],
                            ),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
      ),
    ]);
  }
}
