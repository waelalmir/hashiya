import 'dart:async';
import 'package:flutter/material.dart';
import 'pdf_tools.dart';
import 'store.dart';
import 'theme.dart';

/// بحث داخل الملف: يعيد النتيجة المختارة (صفحة + موضع الكلمة) أو null.
Future<SearchHit?> showSearchSheet(BuildContext context, Book book) {
  return showModalBottomSheet<SearchHit>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HC.green,
    builder: (c) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
      child: SizedBox(height: MediaQuery.sizeOf(c).height * .78, child: _SearchSheet(book: book)),
    ),
  );
}

class _SearchSheet extends StatefulWidget {
  const _SearchSheet({required this.book});
  final Book book;
  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  final c = TextEditingController();
  late final PdfSearcher searcher = PdfSearcher(widget.book.path);
  Timer? _deb;
  int _gen = 0;
  List<SearchHit> hits = [];
  int done = 0, total = 0;
  bool searching = false, searched = false;

  @override
  void dispose() {
    _gen++;
    _deb?.cancel();
    searcher.dispose();
    c.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _deb?.cancel();
    _deb = Timer(const Duration(milliseconds: 450), () => _run(v));
  }

  Future<void> _run(String q) async {
    final my = ++_gen;
    if (q.trim().isEmpty) {
      setState(() {
        hits = [];
        searching = false;
        searched = false;
      });
      return;
    }
    setState(() {
      hits = [];
      searching = true;
      searched = false;
      done = 0;
    });
    try {
      await searcher.search(
        q,
        cancelled: () => my != _gen || !mounted,
        onUpdate: (h, d, t) {
          if (my != _gen || !mounted) return;
          setState(() {
            hits = h;
            done = d;
            total = t;
          });
        },
      );
    } catch (_) {}
    if (my == _gen && mounted) {
      setState(() {
        searching = false;
        searched = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final noText = searched && hits.isEmpty && !searcher.foundAnyText;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: TextField(
          controller: c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onChanged: _onChanged,
          onSubmitted: (v) {
            _deb?.cancel();
            _run(v);
          },
          decoration: InputDecoration(
            hintText: 'ابحث عن كلمة أو جملة في الملف',
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: c.text.isEmpty ? null : IconButton(icon: const Icon(Icons.close_rounded), onPressed: () {
              c.clear();
              _run('');
            }),
            border: const OutlineInputBorder(),
          ),
        ),
      ),
      if (searching) LinearProgressIndicator(value: total == 0 ? null : done / total, minHeight: 3),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(
            searching ? 'جاري البحث... (${hits.length} نتيجة)' : (searched ? '${hits.length} نتيجة' : ''),
            style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65)),
          ),
        ),
      ),
      Expanded(
        child: noText
            ? Padding(
                padding: const EdgeInsets.all(24),
                child: Text('هذا الملف لا يحوي نصاً قابلاً للبحث (ربما صور ممسوحة). استخدم "نسخ نص الصفحة" مع OCR لاستخراج النص.', textAlign: TextAlign.center, style: TextStyle(color: HC.cream.withValues(alpha: .75))),
              )
            : ListView.separated(
                itemCount: hits.length,
                separatorBuilder: (_, __) => Divider(height: 1, color: HC.cream.withValues(alpha: .12)),
                itemBuilder: (context, i) {
                  final h = hits[i];
                  return InkWell(
                    onTap: () => Navigator.pop(context, h),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: HC.cream.withValues(alpha: .18), borderRadius: BorderRadius.circular(10)),
                          child: Text('ص ${h.page}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: RichText(
                            textDirection: TextDirection.rtl,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            text: TextSpan(
                              style: TextStyle(fontFamily: 'IBMPlexSansArabic', fontSize: 14, height: 1.5, color: HC.cream.withValues(alpha: .85)),
                              children: [
                                TextSpan(text: '…${h.before}'),
                                TextSpan(text: h.match, style: const TextStyle(backgroundColor: Color(0xFFFFD54F), color: Color(0xFF222222), fontWeight: FontWeight.w700)),
                                TextSpan(text: '${h.after}…'),
                              ],
                            ),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
      ),
    ]);
  }
}
