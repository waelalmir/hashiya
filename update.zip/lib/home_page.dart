import 'dart:io';
import 'package:flutter/material.dart';
import 'assistant_page.dart';
import 'data.dart';
import 'glass.dart';
import 'reader_page.dart';
import 'store.dart';
import 'theme.dart';
import 'welcome.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.onOpenLibrary});
  final VoidCallback onOpenLibrary;

  Widget _stat(String label, String value, IconData icon) => GlassCard(
        child: Row(children: [
          Icon(icon, size: 28, color: HC.cream.withValues(alpha: .8)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
              const SizedBox(height: 4),
              Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([Store.books, AppData.reading, AppData.sessions, AppData.tasks]),
        builder: (context, _) {
          final compact = isCompact(context);
          final recent = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
          final last = recent.isEmpty ? null : recent.first;
          final today = AppData.dayKey();
          final pending = AppData.tasks.value.where((t) => !t.done).length;

          if (last != null) Store.ensureCover(last);
          final cont = GlassCard(
            child: last == null
                ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('ابدأ من هنا', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    const Text('أضف أول ملف PDF إلى مكتبتك'),
                    const SizedBox(height: 14),
                    FilledButton(onPressed: onOpenLibrary, child: const Text('فتح المكتبة')),
                  ])
                : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (Store.hasCover(last))
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 14),
                        child: SizedBox(
                          width: 78,
                          height: 108,
                          child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(last.cover!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink())),
                        ),
                      ),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('متابعة القراءة', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
                          const SizedBox(height: 6),
                          Text(last.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 12),
                          LinearProgressIndicator(value: last.progress, minHeight: 6, borderRadius: BorderRadius.circular(3)),
                          const SizedBox(height: 6),
                          Text('صفحة ${last.lastPage} من ${last.total == 0 ? '—' : last.total}', style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .65))),
                        ]),
                        const SizedBox(height: 14),
                        FilledButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(book: last))), child: const Text('متابعة')),
                      ]),
                    ),
                  ]),
          );
          final ai = GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('المساعد الذكي', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
                const SizedBox(height: 6),
                const Text('بحث وملخصات واختبارات', maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 14),
              FilledButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AssistantPage())), child: const Text('فتح المساعد')),
            ]),
          );
          final stats = [
            _stat('قراءة اليوم', AppData.fmtDuration(AppData.secondsOn(today)), Icons.auto_stories_rounded),
            _stat('تركيز اليوم', '${AppData.focusMinutesOn(today)} د', Icons.timer_rounded),
            _stat('مهام متبقية', '$pending', Icons.checklist_rounded),
            _stat('أيام متتالية', '${AppData.streak}', Icons.local_fire_department_rounded),
          ];

          return SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const PageHeader(title: 'الرئيسية'),
              ValueListenableBuilder<String>(
                valueListenable: AppData.name,
                builder: (context, nm, _) => ValueListenableBuilder<String?>(
                  valueListenable: AppData.avatar,
                  builder: (context, av, _) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: GlassCard(
                      child: Row(children: [
                        CircleAvatar(
                          radius: 26,
                          backgroundColor: HC.cream.withValues(alpha: .25),
                          backgroundImage: (av != null && File(av).existsSync()) ? FileImage(File(av)) : null,
                          child: (av != null && File(av).existsSync()) ? null : const Icon(Icons.person_rounded, size: 28),
                        ),
                        const SizedBox(width: 14),
                        Expanded(child: Text(Welcome.current(nm), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, height: 1.5))),
                      ]),
                    ),
                  ),
                ),
              ),
              if (compact) ...[cont, const SizedBox(height: 12), ai] else IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Expanded(flex: 3, child: cont), const SizedBox(width: 16), Expanded(flex: 2, child: ai)])),
              const SizedBox(height: 16),
              compact
                  ? Column(children: [
                      Row(children: [Expanded(child: stats[0]), const SizedBox(width: 12), Expanded(child: stats[1])]),
                      const SizedBox(height: 12),
                      Row(children: [Expanded(child: stats[2]), const SizedBox(width: 12), Expanded(child: stats[3])]),
                    ])
                  : Row(children: [for (var i = 0; i < 4; i++) ...[if (i > 0) const SizedBox(width: 16), Expanded(child: stats[i])]]),
            ]),
          );
        },
      );
}
