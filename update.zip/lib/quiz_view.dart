import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'glass.dart';
import 'theme.dart';

// ====================== نماذج البيانات + التحليل ======================

class QuizQ {
  QuizQ({required this.type, required this.q, this.options = const [], this.answerIndex = 0, this.answerBool = true, this.answerText = '', this.explain = ''});
  final String type; // mcq | tf | short
  final String q;
  final List<String> options;
  final int answerIndex;
  final bool answerBool;
  final String answerText, explain;

  String get correctText => type == 'mcq' ? options[answerIndex] : (type == 'tf' ? (answerBool ? 'صح' : 'خطأ') : answerText);

  QuizQ shuffled() {
    if (type != 'mcq') return this;
    final idx = List<int>.generate(options.length, (i) => i)..shuffle(math.Random());
    return QuizQ(type: type, q: q, options: [for (final i in idx) options[i]], answerIndex: idx.indexOf(answerIndex), explain: explain);
  }

  static QuizQ? fromJson(Map j) {
    final q = (j['q'] ?? j['question'] ?? '').toString().trim();
    if (q.isEmpty) return null;
    final type = (j['type'] ?? 'mcq').toString().toLowerCase();
    final explain = (j['explain'] ?? j['explanation'] ?? '').toString().trim();
    if (type == 'tf' || type == 'truefalse' || type == 'true_false') {
      final a = j['answer'];
      final b = a is bool ? a : const ['true', 'صح', 'صحيح', 'نعم', 'yes'].contains(a.toString().trim().toLowerCase());
      return QuizQ(type: 'tf', q: q, answerBool: b, explain: explain);
    }
    if (type == 'short' || type == 'open') {
      return QuizQ(type: 'short', q: q, answerText: (j['answer'] ?? '').toString().trim(), explain: explain);
    }
    final opts = [for (final o in (j['options'] as List? ?? const [])) o.toString().trim()];
    if (opts.length < 2) return null;
    final a = j['answer'];
    var idx = a is num ? a.toInt() : (int.tryParse('$a') ?? -1);
    if (idx < 0 || idx >= opts.length) idx = opts.indexOf('$a'.trim());
    if (idx < 0 || idx >= opts.length) return null;
    return QuizQ(type: 'mcq', q: q, options: opts, answerIndex: idx, explain: explain);
  }
}

class FlashCard {
  FlashCard(this.front, this.back);
  final String front, back;
}

dynamic _decode(String raw) {
  final t = raw.trim();
  final i = t.indexOf(RegExp(r'[\[{]'));
  final j = math.max(t.lastIndexOf('}'), t.lastIndexOf(']'));
  if (i < 0 || j <= i) throw const FormatException('no json');
  return jsonDecode(t.substring(i, j + 1));
}

List<QuizQ> parseQuiz(String raw) {
  final d = _decode(raw);
  final list = d is Map ? (d['questions'] ?? d['quiz'] ?? d['items']) : d;
  final out = <QuizQ>[];
  if (list is List) {
    for (final e in list) {
      if (e is Map) {
        final q = QuizQ.fromJson(e);
        if (q != null) out.add(q);
      }
    }
  }
  return out;
}

List<FlashCard> parseCards(String raw) {
  final d = _decode(raw);
  final list = d is Map ? (d['cards'] ?? d['flashcards'] ?? d['items']) : d;
  final out = <FlashCard>[];
  if (list is List) {
    for (final e in list) {
      if (e is Map) {
        final f = (e['front'] ?? e['q'] ?? '').toString().trim();
        final b = (e['back'] ?? e['a'] ?? '').toString().trim();
        if (f.isNotEmpty && b.isNotEmpty) out.add(FlashCard(f, b));
      }
    }
  }
  return out;
}

// ====================== عرض النص المنسّق (عناوين/نقاط/غامق) ======================

class RichAnswer extends StatelessWidget {
  const RichAnswer(this.text, {super.key, this.fontSize = 15});
  final String text;
  final double fontSize;

  List<InlineSpan> _inline(String s, TextStyle base) {
    final spans = <InlineSpan>[];
    final re = RegExp(r'\*\*(.+?)\*\*');
    var last = 0;
    for (final m in re.allMatches(s)) {
      if (m.start > last) spans.add(TextSpan(text: s.substring(last, m.start), style: base));
      spans.add(TextSpan(text: m.group(1), style: base.copyWith(fontWeight: FontWeight.w700)));
      last = m.end;
    }
    if (last < s.length) spans.add(TextSpan(text: s.substring(last), style: base));
    return spans;
  }

  @override
  Widget build(BuildContext context) {
    final base = TextStyle(fontSize: fontSize, height: 1.7, color: HC.cream);
    final blocks = <Widget>[];
    for (final raw in text.split('\n')) {
      final line = raw.trimRight();
      if (line.trim().isEmpty) {
        blocks.add(const SizedBox(height: 8));
        continue;
      }
      final h = RegExp(r'^\s*(#{1,4})\s+(.*)$').firstMatch(line);
      final b = RegExp(r'^\s*[-*•]\s+(.*)$').firstMatch(line);
      final n = RegExp(r'^\s*(\d+)[.)]\s+(.*)$').firstMatch(line);
      if (h != null) {
        final lvl = h.group(1)!.length;
        blocks.add(Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 4),
          child: SelectableText.rich(TextSpan(children: _inline(h.group(2)!, base.copyWith(fontSize: fontSize + (lvl == 1 ? 5 : (lvl == 2 ? 3 : 1)), fontWeight: FontWeight.w700, color: HC.cream)))),
        ));
      } else if (b != null) {
        blocks.add(Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, top: 2, bottom: 2),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(padding: const EdgeInsets.only(top: 10, left: 8, right: 8), child: Container(width: 6, height: 6, decoration: BoxDecoration(color: HC.cream.withValues(alpha: .8), shape: BoxShape.circle))),
            Expanded(child: SelectableText.rich(TextSpan(children: _inline(b.group(1)!, base)))),
          ]),
        ));
      } else if (n != null) {
        blocks.add(Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, top: 2, bottom: 2),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 26,
              height: 26,
              margin: const EdgeInsets.only(top: 3, left: 8, right: 8),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: HC.cream.withValues(alpha: .18), shape: BoxShape.circle),
              child: Text(n.group(1)!, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: HC.cream)),
            ),
            Expanded(child: SelectableText.rich(TextSpan(children: _inline(n.group(2)!, base)))),
          ]),
        ));
      } else {
        blocks.add(Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: SelectableText.rich(TextSpan(children: _inline(line, base)))));
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: blocks);
  }
}

// ====================== الاختبار التفاعلي ======================

class QuizPage extends StatefulWidget {
  const QuizPage({super.key, required this.title, required this.questions});
  final String title;
  final List<QuizQ> questions;
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late List<QuizQ> qs = [for (final q in widget.questions) q.shuffled()];
  int i = 0;
  int? picked; // mcq: رقم الخيار، tf: 0 = صح، 1 = خطأ
  bool revealed = false;
  bool? selfOk;
  final results = <int, bool>{};
  bool done = false;

  QuizQ get q => qs[i];
  bool get answered => picked != null || selfOk != null;
  bool get ok => results[i] ?? false;

  void _choose(int k) {
    if (answered) return;
    final good = q.type == 'tf' ? ((k == 0) == q.answerBool) : (k == q.answerIndex);
    setState(() {
      picked = k;
      results[i] = good;
    });
    good ? HapticFeedback.lightImpact() : HapticFeedback.heavyImpact();
  }

  void _grade(bool good) {
    setState(() {
      selfOk = good;
      results[i] = good;
    });
  }

  void _next() {
    setState(() {
      if (i < qs.length - 1) {
        i++;
        picked = null;
        revealed = false;
        selfOk = null;
      } else {
        done = true;
      }
    });
  }

  void _restart(List<QuizQ> list) {
    setState(() {
      qs = [for (final x in list) x.shuffled()];
      i = 0;
      picked = null;
      revealed = false;
      selfOk = null;
      results.clear();
      done = false;
    });
  }

  static const _letters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
  static const _good = Color(0xFF69F0AE);
  static const _bad = Color(0xFFFF5252);

  Widget _popIcon(IconData i, Color c) => TweenAnimationBuilder<double>(
        tween: Tween(begin: .2, end: 1),
        duration: const Duration(milliseconds: 450),
        curve: Curves.elasticOut,
        builder: (context, v, _) => Transform.scale(scale: v, child: Icon(i, color: c, size: 28)),
      );

  Widget _mcqOption(int k) {
    final isCorrect = k == q.answerIndex, isPicked = picked == k;
    var bg = HC.cream.withValues(alpha: .08), border = HC.cream.withValues(alpha: .25);
    IconData? icon;
    Color iconColor = _good;
    if (answered) {
      if (isCorrect) {
        bg = _good.withValues(alpha: .22);
        border = _good;
        icon = Icons.check_circle_rounded;
      } else if (isPicked) {
        bg = _bad.withValues(alpha: .22);
        border = _bad;
        icon = Icons.cancel_rounded;
        iconColor = _bad;
      } else {
        bg = HC.cream.withValues(alpha: .04);
        border = HC.cream.withValues(alpha: .1);
      }
    }
    final shake = answered && isPicked && !isCorrect;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TweenAnimationBuilder<double>(
        key: ValueKey('$i-$k-$picked'),
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 420),
        builder: (context, v, child) => Transform.translate(offset: Offset(shake ? math.sin(v * math.pi * 6) * (1 - v) * 10 : 0, 0), child: child),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: answered ? null : () => _choose(k),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: border, width: answered && (isCorrect || isPicked) ? 2 : 1)),
            child: Row(children: [
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: HC.cream.withValues(alpha: .15), shape: BoxShape.circle),
                child: Text(k < _letters.length ? _letters[k] : '${k + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(q.options[k], style: const TextStyle(fontSize: 16, height: 1.4))),
              if (icon != null) _popIcon(icon, iconColor),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _tfButton(int k) {
    final isTrue = k == 0;
    final base = isTrue ? _good : _bad;
    final correctK = q.answerBool ? 0 : 1;
    final isPicked = picked == k, isCorrect = correctK == k;
    var bg = base.withValues(alpha: .12), border = base.withValues(alpha: .5);
    var fg = HC.cream;
    if (answered) {
      if (isCorrect) {
        bg = _good.withValues(alpha: .35);
        border = _good;
      } else if (isPicked) {
        bg = _bad.withValues(alpha: .35);
        border = _bad;
      } else {
        bg = HC.cream.withValues(alpha: .04);
        border = HC.cream.withValues(alpha: .1);
        fg = HC.cream.withValues(alpha: .4);
      }
    }
    final shake = answered && isPicked && !isCorrect;
    return Expanded(
      child: TweenAnimationBuilder<double>(
        key: ValueKey('tf-$i-$k-$picked'),
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 420),
        builder: (context, v, child) => Transform.translate(offset: Offset(shake ? math.sin(v * math.pi * 6) * (1 - v) * 10 : 0, 0), child: child),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: answered ? null : () => _choose(k),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            height: 120,
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20), border: Border.all(color: border, width: answered && (isCorrect || isPicked) ? 3 : 1.5)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(isTrue ? Icons.check_circle_outline_rounded : Icons.highlight_off_rounded, size: 44, color: answered && !isCorrect && !isPicked ? fg : base),
              const SizedBox(height: 6),
              Text(isTrue ? 'صح' : 'خطأ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: fg)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _feedback() {
    if (!answered) return const SizedBox(width: double.infinity);
    final good = ok;
    final c = good ? _good : _bad;
    final lines = <Widget>[
      Row(children: [
        Icon(good ? Icons.celebration_rounded : Icons.error_outline_rounded, color: c),
        const SizedBox(width: 8),
        Text(good ? 'إجابة صحيحة! أحسنت' : 'إجابة غير صحيحة', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: c)),
      ]),
    ];
    if (!good && q.type != 'mcq') lines.add(Padding(padding: const EdgeInsets.only(top: 6), child: Text('الإجابة الصحيحة: ${q.correctText}', style: const TextStyle(fontWeight: FontWeight.w600))));
    if (!good && q.type == 'mcq') lines.add(Padding(padding: const EdgeInsets.only(top: 6), child: Text('الإجابة الصحيحة: ${q.correctText}', style: const TextStyle(fontWeight: FontWeight.w600))));
    if (q.explain.isNotEmpty) lines.add(Padding(padding: const EdgeInsets.only(top: 6), child: Text(q.explain, style: TextStyle(height: 1.5, color: HC.cream.withValues(alpha: .85)))));
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: c.withValues(alpha: .14), borderRadius: BorderRadius.circular(16), border: Border.all(color: c.withValues(alpha: .6))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: lines),
    );
  }

  Widget _shortBlock() {
    if (!revealed) {
      return Padding(padding: const EdgeInsets.only(top: 8), child: FilledButton.tonalIcon(onPressed: () => setState(() => revealed = true), icon: const Icon(Icons.visibility_rounded), label: const Text('اعرض الإجابة')));
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: HC.cream.withValues(alpha: .1), borderRadius: BorderRadius.circular(16), border: Border.all(color: HC.cream.withValues(alpha: .3))),
        child: Text(q.answerText, style: const TextStyle(fontSize: 16, height: 1.5)),
      ),
      if (!answered) ...[
        const SizedBox(height: 12),
        const Text('كيف كانت إجابتك؟', textAlign: TextAlign.center),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: () => _grade(false), icon: const Icon(Icons.close_rounded, color: _bad), label: const Text('ما عرفتها'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.icon(onPressed: () => _grade(true), icon: const Icon(Icons.check_rounded), label: const Text('عرفتها'))),
        ]),
      ],
    ]);
  }

  Widget _question() {
    final typeLabel = q.type == 'mcq' ? 'اختيار من متعدد' : (q.type == 'tf' ? 'صح أو خطأ' : 'سؤال قصير');
    return Column(children: [
      LinearProgressIndicator(value: (i + (answered ? 1 : 0)) / qs.length, minHeight: 4),
      Expanded(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(color: HC.cream.withValues(alpha: .15), borderRadius: BorderRadius.circular(20)),
              child: Text('سؤال ${i + 1} من ${qs.length}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            ),
            const SizedBox(width: 8),
            Text(typeLabel, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
          ]),
          const SizedBox(height: 12),
          GlassCard(child: Text(q.q, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600, height: 1.6))),
          const SizedBox(height: 14),
          if (q.type == 'mcq') for (var k = 0; k < q.options.length; k++) _mcqOption(k),
          if (q.type == 'tf') Row(children: [_tfButton(0), const SizedBox(width: 12), _tfButton(1)]),
          if (q.type == 'short') _shortBlock(),
          AnimatedSize(duration: const Duration(milliseconds: 250), alignment: Alignment.topCenter, child: _feedback()),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
        child: SizedBox(width: double.infinity, height: 48, child: FilledButton(onPressed: answered ? _next : null, child: Text(i == qs.length - 1 ? 'عرض النتيجة' : 'التالي'))),
      ),
    ]);
  }

  Widget _result() {
    final n = qs.length;
    final good = results.values.where((v) => v).length;
    final pct = n == 0 ? 0.0 : good / n;
    final msg = pct >= .8 ? 'ممتاز! 🌟' : (pct >= .5 ? 'جيد، كمّل مراجعة' : 'تحتاج مراجعة أكتر 💪');
    final missed = [for (final e in results.entries) if (!e.value) qs[e.key]];
    return ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 10),
      Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: pct),
          duration: const Duration(milliseconds: 900),
          curve: Curves.easeOutCubic,
          builder: (context, v, _) => SizedBox(
            width: 150,
            height: 150,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(width: 150, height: 150, child: CircularProgressIndicator(value: v, strokeWidth: 12, backgroundColor: HC.cream.withValues(alpha: .15), color: pct >= .5 ? _good : _bad)),
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text('$good/$n', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
                Text('${(pct * 100).round()}%', style: TextStyle(color: HC.cream.withValues(alpha: .7))),
              ]),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 16),
      Center(child: Text(msg, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: () => _restart(widget.questions), icon: const Icon(Icons.replay_rounded), label: const Text('أعد الاختبار'))),
        if (missed.isNotEmpty) ...[
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () => _restart(missed), icon: const Icon(Icons.rule_rounded), label: Text('أخطائي (${missed.length})'))),
        ],
      ]),
      if (missed.isNotEmpty) ...[
        const SizedBox(height: 22),
        const Text('مراجعة الأسئلة الخاطئة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        for (final m in missed)
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: _bad.withValues(alpha: .1), borderRadius: BorderRadius.circular(14), border: Border.all(color: _bad.withValues(alpha: .4))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.q, style: const TextStyle(fontWeight: FontWeight.w600, height: 1.5)),
              const SizedBox(height: 6),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.check_circle_rounded, size: 18, color: _good),
                const SizedBox(width: 6),
                Expanded(child: Text(m.correctText, style: const TextStyle(color: _good, fontWeight: FontWeight.w600))),
              ]),
              if (m.explain.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(m.explain, style: TextStyle(color: HC.cream.withValues(alpha: .8), height: 1.5))),
            ]),
          ),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(backgroundColor: HC.deep, title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16))),
        body: SafeArea(child: qs.isEmpty ? const Center(child: Text('لا توجد أسئلة')) : (done ? _result() : _question())),
      );
}

// ====================== بطاقات المراجعة (قلب) ======================

class FlashcardsPage extends StatefulWidget {
  const FlashcardsPage({super.key, required this.title, required this.cards});
  final String title;
  final List<FlashCard> cards;
  @override
  State<FlashcardsPage> createState() => _FlashcardsPageState();
}

class _FlashcardsPageState extends State<FlashcardsPage> {
  late List<FlashCard> deck = [...widget.cards];
  int i = 0;
  bool back = false, done = false;
  final knownSet = <int>{};
  final reviewList = <FlashCard>[];

  void _answer(bool known) {
    if (known) {
      knownSet.add(i);
    } else {
      reviewList.add(deck[i]);
    }
    setState(() {
      if (i < deck.length - 1) {
        i++;
        back = false;
      } else {
        done = true;
      }
    });
  }

  void _restart(List<FlashCard> list) {
    setState(() {
      deck = [...list]..shuffle(math.Random());
      i = 0;
      back = false;
      done = false;
      knownSet.clear();
      reviewList.clear();
    });
  }

  Widget _face(String text, bool isBack) => Container(
        width: double.infinity,
        height: 320,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: isBack ? HC.cream.withValues(alpha: .95) : HC.cream.withValues(alpha: .14),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: HC.cream.withValues(alpha: .4), width: 1.5),
          boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 14, offset: Offset(0, 6))],
        ),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(isBack ? 'الجواب' : 'السؤال', style: TextStyle(fontSize: 12, color: isBack ? HC.green.withValues(alpha: .6) : HC.cream.withValues(alpha: .6))),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 21, height: 1.6, fontWeight: FontWeight.w600, color: isBack ? HC.green : HC.cream)),
          ]),
        ),
      );

  Widget _card() => GestureDetector(
        onTap: () => setState(() => back = !back),
        child: TweenAnimationBuilder<double>(
          tween: Tween<double>(end: back ? 1 : 0),
          duration: const Duration(milliseconds: 450),
          curve: Curves.easeInOut,
          builder: (context, v, _) {
            final showBack = v > .5;
            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, .0012)
                ..rotateY(v * math.pi),
              child: showBack ? Transform(alignment: Alignment.center, transform: Matrix4.rotationY(math.pi), child: _face(deck[i].back, true)) : _face(deck[i].front, false),
            );
          },
        ),
      );

  Widget _study() => Column(children: [
        LinearProgressIndicator(value: (i + (back ? 1 : 0)) / deck.length, minHeight: 4),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Center(child: Text('بطاقة ${i + 1} من ${deck.length}', style: TextStyle(color: HC.cream.withValues(alpha: .7)))),
            const SizedBox(height: 14),
            _card(),
            const SizedBox(height: 14),
            Center(child: Text(back ? '' : 'اضغط على البطاقة لقلبها', style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .6)))),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          child: back
              ? Row(children: [
                  Expanded(child: OutlinedButton.icon(onPressed: () => _answer(false), icon: const Icon(Icons.refresh_rounded, color: Color(0xFFFFB74D)), label: const Text('راجعها لاحقاً'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(onPressed: () => _answer(true), icon: const Icon(Icons.check_rounded), label: const Text('عرفتها'))),
                ])
              : SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => setState(() => back = true), child: const Text('اعرض الجواب'))),
        ),
      ]);

  Widget _summary() => ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 20),
        Icon(reviewList.isEmpty ? Icons.emoji_events_rounded : Icons.auto_stories_rounded, size: 72, color: HC.cream),
        const SizedBox(height: 12),
        Center(child: Text('عرفت ${knownSet.length} من ${deck.length}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
        const SizedBox(height: 6),
        Center(child: Text(reviewList.isEmpty ? 'ما شاء الله، كل البطاقات عندك! 🌟' : 'باقي ${reviewList.length} بطاقة للمراجعة', style: TextStyle(color: HC.cream.withValues(alpha: .75)))),
        const SizedBox(height: 22),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: () => _restart(widget.cards), icon: const Icon(Icons.replay_rounded), label: const Text('كرّر الكل'))),
          if (reviewList.isNotEmpty) ...[
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: () => _restart([...reviewList]), icon: const Icon(Icons.refresh_rounded), label: const Text('المراجَعة فقط'))),
          ],
        ]),
      ]);

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(backgroundColor: HC.deep, title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16))),
        body: SafeArea(child: deck.isEmpty ? const Center(child: Text('لا توجد بطاقات')) : (done ? _summary() : _study())),
      );
}
