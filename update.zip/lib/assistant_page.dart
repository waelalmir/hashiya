import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'ai.dart';
import 'data.dart';
import 'glass.dart';
import 'pdf_tools.dart';
import 'quiz_view.dart';
import 'store.dart';
import 'theme.dart';

/// حقول مفتاح Gemini (تُستخدم في المساعد وفي الإعدادات).
class AiKeyEditor extends StatefulWidget {
  const AiKeyEditor({super.key});
  @override
  State<AiKeyEditor> createState() => _AiKeyEditorState();
}

class _AiKeyEditorState extends State<AiKeyEditor> {
  late final keyC = TextEditingController(text: AppData.aiKey.value);
  late final modelC = TextEditingController(text: AppData.aiModel.value);
  bool hide = true;

  @override
  void dispose() {
    keyC.dispose();
    modelC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('مفتاح Gemini مجاني من Google AI Studio (بدون بطاقة). بيتخزّن على جهازك فقط.', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .7))),
        const SizedBox(height: 10),
        TextField(
          controller: keyC,
          obscureText: hide,
          decoration: InputDecoration(labelText: 'مفتاح API', suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => hide = !hide))),
          onChanged: (v) {
            AppData.aiKey.value = v.trim();
            AppData.save();
          },
        ),
        const SizedBox(height: 10),
        TextField(
          controller: modelC,
          decoration: const InputDecoration(labelText: 'اسم النموذج (اختياري)', hintText: Gemini.defaultModel),
          onChanged: (v) {
            AppData.aiModel.value = v.trim();
            AppData.save();
          },
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => launchUrl(Uri.parse('https://aistudio.google.com/apikey'), mode: LaunchMode.externalApplication),
          icon: const Icon(Icons.open_in_new_rounded),
          label: const Text('احصل على مفتاح مجاني'),
        ),
      ]);
}

class AssistantPage extends StatefulWidget {
  const AssistantPage({super.key});
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}

class _AssistantPageState extends State<AssistantPage> {
  Book? book;
  final fromC = TextEditingController(text: '1');
  final toC = TextEditingController(text: '5');
  final qC = TextEditingController();
  String answer = '';
  bool busy = false;
  int qCount = 5;
  String qType = 'mixed';
  List<QuizQ>? lastQuiz;
  List<FlashCard>? lastCards;

  @override
  void initState() {
    super.initState();
    final bs = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
    if (bs.isNotEmpty) _pick(bs.first);
  }

  @override
  void dispose() {
    fromC.dispose();
    toC.dispose();
    qC.dispose();
    super.dispose();
  }

  void _pick(Book b) {
    book = b;
    final f = b.lastPage.clamp(1, b.total == 0 ? 9999 : b.total).toInt();
    fromC.text = '$f';
    toC.text = '${b.total == 0 ? f + 4 : (f + 4).clamp(f, b.total)}';
  }

  Future<void> _run(String task) async {
    final b = book;
    if (b == null) return;
    final from = int.tryParse(fromC.text) ?? 1;
    var to = int.tryParse(toC.text) ?? from;
    if (to < from) to = from;
    if (to - from > 29) to = from + 29;
    setState(() {
      busy = true;
      answer = '';
    });
    try {
      final text = await PdfTools.pagesText(b.path, from, to);
      final q = qC.text.trim();
      final typeDesc = switch (qType) {
        'mcq' => 'كلها اختيار من متعدد (4 خيارات)',
        'tf' => 'كلها صح وخطأ',
        _ => 'متنوعة: اختيار من متعدد وصح/خطأ وسؤال قصير',
      };
      final isJson = task == 'quiz' || task == 'cards';
      final instruction = switch (task) {
        'sum' => 'لخّص النص التالي في نقاط واضحة مرتبة مع أهم المفاهيم. استخدم عناوين (##) ونقاطاً (-) والخط الغامق (**) للمصطلحات.',
        'easy' => 'اشرح النص التالي بأسلوب مبسّط كأنك تشرح لطالب مبتدئ، مع أمثلة إن لزم. استخدم عناوين (##) ونقاطاً (-) والخط الغامق (**).',
        'quiz' => 'أنشئ اختباراً من $qCount أسئلة $typeDesc من النص التالي. أعد JSON فقط بهذا الشكل: '
            '{"questions":[{"type":"mcq","q":"نص السؤال","options":["..","..","..",".."],"answer":0,"explain":"شرح قصير"},'
            '{"type":"tf","q":"عبارة","answer":true,"explain":"شرح قصير"},'
            '{"type":"short","q":"سؤال","answer":"الجواب المختصر","explain":""}]}. '
            'answer في mcq هو رقم الخيار الصحيح من 0. وزّع موقع الإجابة الصحيحة عشوائياً. اعتمد على النص فقط.',
        'cards' => 'أنشئ $qCount بطاقات مراجعة (سؤال وجواب قصير) من النص التالي. أعد JSON فقط بهذا الشكل: {"cards":[{"front":"السؤال","back":"الجواب"}]}. اعتمد على النص فقط.',
        _ => q.isEmpty ? 'لخّص النص التالي.' : '$q\n(استخدم عناوين ## ونقاطاً - وخطاً غامقاً ** عند الحاجة)',
      };
      String r;
      if (text.trim().isEmpty) {
        // صفحات مصوّرة: نرسل صورة الصفحة الأولى فقط
        final png = await PdfTools.renderPagePng(b.path, from);
        if (png == null) throw AiException('تعذّر قراءة الصفحات');
        r = await Gemini.ask('$instruction\n(الصفحة مصوّرة، اقرأها من الصورة)', imagePng: png, system: Gemini.studySystem, json: isJson);
      } else {
        final ask = task == 'ask' || q.isEmpty || isJson ? instruction : '$instruction\nمع مراعاة: $q';
        r = await Gemini.ask('$ask\n\n=== النص ===\n$text', system: Gemini.studySystem, json: isJson);
      }
      if (task == 'quiz') {
        List<QuizQ> list;
        try {
          list = parseQuiz(r);
        } catch (_) {
          list = [];
        }
        if (list.isEmpty) throw AiException('تعذّر تنسيق الأسئلة، جرّب مرة ثانية');
        if (!mounted) return;
        setState(() => lastQuiz = list);
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => QuizPage(title: b.title, questions: list)));
        if (mounted) setState(() => busy = false);
        return;
      }
      if (task == 'cards') {
        List<FlashCard> list;
        try {
          list = parseCards(r);
        } catch (_) {
          list = [];
        }
        if (list.isEmpty) throw AiException('تعذّر تنسيق البطاقات، جرّب مرة ثانية');
        if (!mounted) return;
        setState(() => lastCards = list);
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => FlashcardsPage(title: b.title, cards: list)));
        if (mounted) setState(() => busy = false);
        return;
      }
      if (mounted) setState(() => answer = r);
    } catch (e) {
      if (mounted) setState(() => answer = 'تعذّر: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Widget _chip(String label, IconData i, String task) => ActionChip(avatar: Icon(i, size: 18), label: Text(label), onPressed: busy || book == null ? null : () => _run(task));

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(backgroundColor: HC.deep, title: const Text('المساعد الذكي')),
        body: SafeArea(
          child: ListenableBuilder(
            listenable: AppData.aiKey,
            builder: (context, _) {
              final hasKey = AppData.aiKey.value.isNotEmpty;
              return ListView(padding: const EdgeInsets.all(16), children: [
                if (!hasKey) GlassCard(child: const AiKeyEditor()),
                if (hasKey) ...[
                  GlassCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      ValueListenableBuilder<List<Book>>(
                        valueListenable: Store.books,
                        builder: (context, books, _) => DropdownButtonFormField<String>(
                          value: book?.id,
                          decoration: const InputDecoration(labelText: 'الكتاب'),
                          items: [for (final b in books) DropdownMenuItem(value: b.id, child: Text(b.title, overflow: TextOverflow.ellipsis))],
                          onChanged: (v) => setState(() => _pick(books.firstWhere((b) => b.id == v))),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: TextField(controller: fromC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'من صفحة'))),
                        const SizedBox(width: 12),
                        Expanded(child: TextField(controller: toC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'إلى صفحة (حتى 30)'))),
                      ]),
                      const SizedBox(height: 12),
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        _chip('لخّص', Icons.notes_rounded, 'sum'),
                        _chip('اشرح ببساطة', Icons.lightbulb_outline_rounded, 'easy'),
                        _chip('اختبرني', Icons.quiz_rounded, 'quiz'),
                        _chip('بطاقات مراجعة', Icons.style_rounded, 'cards'),
                      ]),
                      const SizedBox(height: 14),
                      Text('إعدادات الاختبار والبطاقات', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .7))),
                      const SizedBox(height: 6),
                      Wrap(spacing: 8, runSpacing: 6, children: [
                        for (final n in const [5, 10, 15]) ChoiceChip(label: Text('$n'), selected: qCount == n, onSelected: (_) => setState(() => qCount = n)),
                        for (final t in const [('mixed', 'متنوع'), ('mcq', 'اختيار من متعدد'), ('tf', 'صح وخطأ')]) ChoiceChip(label: Text(t.$2), selected: qType == t.$1, onSelected: (_) => setState(() => qType = t.$1)),
                      ]),
                      if (lastQuiz != null || lastCards != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Wrap(spacing: 8, children: [
                            if (lastQuiz != null) TextButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => QuizPage(title: book?.title ?? 'اختبار', questions: lastQuiz!))), icon: const Icon(Icons.quiz_rounded, size: 18), label: const Text('آخر اختبار')),
                            if (lastCards != null) TextButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FlashcardsPage(title: book?.title ?? 'بطاقات', cards: lastCards!))), icon: const Icon(Icons.style_rounded, size: 18), label: const Text('آخر بطاقات')),
                          ]),
                        ),
                      const SizedBox(height: 12),
                      TextField(controller: qC, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'أو اسأل سؤالاً عن هذه الصفحات')),
                      const SizedBox(height: 10),
                      FilledButton.icon(onPressed: busy || book == null ? null : () => _run('ask'), icon: const Icon(Icons.send_rounded), label: const Text('اسأل')),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  if (busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
                  if (answer.isNotEmpty)
                    GlassCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        RichAnswer(answer),
                        const SizedBox(height: 8),
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton.icon(
                            onPressed: () {
                              Clipboard.setData(ClipboardData(text: answer));
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم النسخ')));
                            },
                            icon: const Icon(Icons.copy_rounded),
                            label: const Text('نسخ'),
                          ),
                        ),
                      ]),
                    ),
                  const SizedBox(height: 12),
                  ExpansionTile(title: const Text('إعدادات المفتاح'), children: const [Padding(padding: EdgeInsets.all(8), child: AiKeyEditor())]),
                ],
              ]);
            },
          ),
        ),
      );
}
