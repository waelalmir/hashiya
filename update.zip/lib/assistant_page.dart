import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'ai.dart';
import 'data.dart';
import 'glass.dart';
import 'pdf_tools.dart';
import 'quiz_view.dart';
import 'store.dart';
import 'theme.dart';

/// حقول مفتاح Gemini وسرعة النموذج (تُستخدم في المساعد وفي الإعدادات).
class AiKeyEditor extends StatefulWidget {
  const AiKeyEditor({super.key});
  @override
  State<AiKeyEditor> createState() => _AiKeyEditorState();
}

class _AiKeyEditorState extends State<AiKeyEditor> {
  late final keyC = TextEditingController(text: AppData.aiKey.value);
  late final modelC = TextEditingController(text: AppData.aiModel.value);
  bool hide = true;

  @override
  void dispose() {
    keyC.dispose();
    modelC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('مفتاح Gemini مجاني من Google AI Studio (بدون بطاقة). بيتخزّن على جهازك فقط.', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .7))),
        const SizedBox(height: 10),
        TextField(
          controller: keyC,
          obscureText: hide,
          decoration: InputDecoration(labelText: 'مفتاح API', suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => hide = !hide))),
          onChanged: (v) {
            AppData.aiKey.value = v.trim();
            AppData.save();
          },
        ),
        const SizedBox(height: 10),
        ValueListenableBuilder<bool>(
          valueListenable: AppData.aiFast,
          builder: (context, fast, _) => SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('الوضع السريع (Flash Lite)'),
            subtitle: Text('أسرع استجابة وحد استخدام مجاني أعلى بكثير', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
            value: fast,
            onChanged: (v) {
              AppData.aiFast.value = v;
              AppData.save();
            },
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: modelC,
          decoration: const InputDecoration(labelText: 'اسم نموذج مخصص (اختياري)', hintText: Gemini.fastModel),
          onChanged: (v) {
            AppData.aiModel.value = v.trim();
            AppData.save();
          },
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => launchUrl(Uri.parse('https://aistudio.google.com/apikey'), mode: LaunchMode.externalApplication),
          icon: const Icon(Icons.open_in_new_rounded),
          label: const Text('احصل على مفتاح مجاني'),
        ),
      ]);
}

class _ChatMsg {
  _ChatMsg({required this.role, required this.text, this.quiz, this.cards});
  final String role; // user | ai
  String text;
  final List<QuizQ>? quiz;
  final List<FlashCard>? cards;
}

/// واجهة محادثة ذكاء اصطناعي حديثة مع سياق الكتاب والصفحات وكافة أدوات الدراسة.
class AssistantPage extends StatefulWidget {
  const AssistantPage({super.key, this.initialBook, this.initialPage});
  final Book? initialBook;
  final int? initialPage;
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}

class _AssistantPageState extends State<AssistantPage> {
  Book? book;
  final fromC = TextEditingController(text: '1');
  final toC = TextEditingController(text: '5');
  final qC = TextEditingController();
  final sc = ScrollController();
  final msgs = <_ChatMsg>[];
  bool busy = false;
  int qCount = 5;
  String qType = 'mixed';
  bool showContextBar = true;

  @override
  void initState() {
    super.initState();
    if (widget.initialBook != null) {
      _pick(widget.initialBook!, page: widget.initialPage);
    } else {
      final bs = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
      if (bs.isNotEmpty) _pick(bs.first);
    }
  }

  @override
  void dispose() {
    fromC.dispose();
    toC.dispose();
    qC.dispose();
    sc.dispose();
    super.dispose();
  }

  void _pick(Book b, {int? page}) {
    book = b;
    final f = (page ?? b.lastPage).clamp(1, b.total == 0 ? 9999 : b.total).toInt();
    fromC.text = '$f';
    toC.text = '${b.total == 0 ? f + 4 : (f + 4).clamp(f, b.total)}';
  }

  void _scrollBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (sc.hasClients) {
        sc.animateTo(sc.position.maxScrollExtent + 120, duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
      }
    });
  }

  void _showQuizOptions() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HC.green,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('إعدادات الاختبار والبطاقات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            const Text('عدد الأسئلة / البطاقات'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final n in const [5, 10, 15])
                ChoiceChip(
                  label: Text('$n'),
                  selected: qCount == n,
                  onSelected: (_) {
                    set(() => qCount = n);
                    setState(() {});
                  },
                ),
            ]),
            const SizedBox(height: 12),
            const Text('نوع الأسئلة'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final t in const [('mixed', 'متنوع'), ('mcq', 'اختيار من متعدد'), ('tf', 'صح وخطأ')])
                ChoiceChip(
                  label: Text(t.$2),
                  selected: qType == t.$1,
                  onSelected: (_) {
                    set(() => qType = t.$1);
                    setState(() {});
                  },
                ),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(c);
                    _run('quiz');
                  },
                  icon: const Icon(Icons.quiz_rounded),
                  label: const Text('ابدأ الاختبار الآن'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pop(c);
                    _run('cards');
                  },
                  icon: const Icon(Icons.style_rounded),
                  label: const Text('بطاقات مراجعة'),
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  void _showKeySheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HC.green,
      isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.viewInsetsOf(c).bottom + 20),
        child: const SingleChildScrollView(child: AiKeyEditor()),
      ),
    );
  }

  Future<void> _exportForNotebookLm() async {
    final b = book;
    if (b == null) return;
    final from = int.tryParse(fromC.text) ?? 1;
    var to = int.tryParse(toC.text) ?? from;
    if (to < from) to = from;
    if (to - from > 49) to = from + 49;
    setState(() => busy = true);
    try {
      final text = await PdfTools.pagesText(b.path, from, to);
      if (text.trim().isEmpty) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الصفحات مصوّرة بدون نص قابل للاستخراج')));
      } else {
        final safe = b.title.replaceAll(RegExp(r'[^\w\u0600-\u06FF]+'), '_');
        final f = File('${Store.dir.path}/${safe}_p${from}_$to.md');
        await f.writeAsString('# ${b.title} (ص $from–$to)\n\n$text');
        await Share.shareXFiles([XFile(f.path)], text: 'مصدر جاهز للرفع إلى Google NotebookLM');
      }
    } catch (_) {}
    if (mounted) setState(() => busy = false);
  }

  Future<void> _run(String task) async {
    final b = book;
    if (b == null || busy) return;
    final from = int.tryParse(fromC.text) ?? 1;
    var to = int.tryParse(toC.text) ?? from;
    if (to < from) to = from;
    if (to - from > 29) to = from + 29;
    final q = qC.text.trim();
    if (task == 'ask' && q.isEmpty) return;
    qC.clear();

    final userLabel = switch (task) {
      'sum' => 'لخّص الصفحات $from–$to من «${b.title}»',
      'easy' => 'اشرح الصفحات $from–$to بأسلوب مبسّط',
      'quiz' => 'أنشئ اختباراً ($qCount أسئلة) من ص $from–$to',
      'cards' => 'أنشئ $qCount بطاقات مراجعة من ص $from–$to',
      _ => q,
    };

    final aiMsg = _ChatMsg(role: 'ai', text: '');
    setState(() {
      busy = true;
      msgs.add(_ChatMsg(role: 'user', text: userLabel));
      msgs.add(aiMsg);
    });
    _scrollBottom();

    try {
      final text = await PdfTools.pagesText(b.path, from, to);
      final typeDesc = switch (qType) {
        'mcq' => 'كلها اختيار من متعدد (4 خيارات)',
        'tf' => 'كلها صح وخطأ',
        _ => 'متنوعة: اختيار من متعدد وصح/خطأ وسؤال قصير',
      };
      final isJson = task == 'quiz' || task == 'cards';
      final instruction = switch (task) {
        'sum' => 'لخّص النص التالي في نقاط واضحة مرتبة مع أهم المفاهيم. استخدم عناوين (##) ونقاطاً (-) والخط الغامق (**) للمصطلحات.',
        'easy' => 'اشرح النص التالي بأسلوب مبسّط كأنك تشرح لطالب مبتدئ، مع أمثلة إن لزم. استخدم عناوين (##) ونقاطاً (-) والخط الغامق (**).',
        'quiz' => 'أنشئ اختباراً من $qCount أسئلة $typeDesc من النص التالي. أعد JSON فقط بهذا الشكل: '
            '{"questions":[{"type":"mcq","q":"نص السؤال","options":["..","..","..",".."],"answer":0,"explain":"شرح قصير"},'
            '{"type":"tf","q":"عبارة","answer":true,"explain":"شرح قصير"},'
            '{"type":"short","q":"سؤال","answer":"الجواب المختصر","explain":""}]}. '
            'answer في mcq هو رقم الخيار الصحيح من 0. وزّع موقع الإجابة الصحيحة عشوائياً. اعتمد على النص فقط.',
        'cards' => 'أنشئ $qCount بطاقات مراجعة (سؤال وجواب قصير) من النص التالي. أعد JSON فقط بهذا الشكل: {"cards":[{"front":"السؤال","back":"الجواب"}]}. اعتمد على النص فقط.',
        _ => '$q\n(استخدم عناوين ## ونقاطاً - وخطاً غامقاً ** عند الحاجة)',
      };

      // تمرير سياق آخر رسالتين للمتابعة السلسة في المحادثة
      final prevCtx = StringBuffer();
      if (!isJson && msgs.length > 2) {
        final recent = msgs.sublist(0, msgs.length - 2);
        final tail = recent.length > 4 ? recent.sublist(recent.length - 4) : recent;
        for (final m in tail) {
          if (m.text.isNotEmpty) prevCtx.writeln('${m.role == 'user' ? 'المستخدم' : 'المساعد'}: ${m.text.length > 400 ? m.text.substring(0, 400) : m.text}');
        }
      }

      if (isJson) {
        String r;
        if (text.trim().isEmpty) {
          final png = await PdfTools.renderPagePng(b.path, from);
          if (png == null) throw AiException('تعذّر قراءة الصفحات');
          r = await Gemini.ask('$instruction\n(الصفحة مصوّرة، اقرأها من الصورة)', imagePng: png, system: Gemini.studySystem, json: true);
        } else {
          r = await Gemini.ask('$instruction\n\n=== النص ===\n$text', system: Gemini.studySystem, json: true);
        }
        if (task == 'quiz') {
          final list = parseQuiz(r);
          if (list.isEmpty) throw AiException('تعذّر تنسيق الأسئلة، جرّب مرة ثانية');
          if (!mounted) return;
          setState(() {
            msgs[msgs.length - 1] = _ChatMsg(role: 'ai', text: 'جهّزت لك اختباراً من ${list.length} أسئلة. اضغط للبدء:', quiz: list);
            busy = false;
          });
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => QuizPage(title: b.title, questions: list)));
          return;
        }
        if (task == 'cards') {
          final list = parseCards(r);
          if (list.isEmpty) throw AiException('تعذّر تنسيق البطاقات، جرّب مرة ثانية');
          if (!mounted) return;
          setState(() {
            msgs[msgs.length - 1] = _ChatMsg(role: 'ai', text: 'جهّزت لك ${list.length} بطاقات مراجعة. اضغط للبدء:', cards: list);
            busy = false;
          });
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => FlashcardsPage(title: b.title, cards: list)));
          return;
        }
      } else {
        final historyBlock = prevCtx.isEmpty ? '' : '\n=== سياق المحادثة السابقة ===\n$prevCtx';
        Stream<String> stream;
        if (text.trim().isEmpty) {
          final png = await PdfTools.renderPagePng(b.path, from);
          if (png == null) throw AiException('تعذّر قراءة الصفحات');
          stream = Gemini.askStream('$instruction$historyBlock\n(الصفحة مصوّرة، اقرأها من الصورة)', imagePng: png, system: Gemini.studySystem);
        } else {
          stream = Gemini.askStream('$instruction$historyBlock\n\n=== النص ===\n$text', system: Gemini.studySystem);
        }
        final buf = StringBuffer();
        await for (final chunk in stream) {
          buf.write(chunk);
          if (mounted) {
            setState(() => aiMsg.text = buf.toString());
            _scrollBottom();
          }
        }
      }
    } catch (e) {
      if (mounted) setState(() => aiMsg.text = 'تعذّر: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Widget _bubble(_ChatMsg m) {
    final isUser = m.role == 'user';
    return Align(
      alignment: isUser ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * (isUser ? .80 : .92)),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: isUser ? HC.cream : HC.cream.withValues(alpha: .11),
          borderRadius: BorderRadiusDirectional.only(
            topStart: const Radius.circular(18),
            topEnd: const Radius.circular(18),
            bottomStart: Radius.circular(isUser ? 18 : 4),
            bottomEnd: Radius.circular(isUser ? 4 : 18),
          ),
          border: isUser ? null : Border.all(color: HC.cream.withValues(alpha: .18)),
        ),
        child: isUser
            ? Text(m.text, style: TextStyle(color: HC.green, fontSize: 15, fontWeight: FontWeight.w600, height: 1.4))
            : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (m.text.isEmpty && busy)
                  const Padding(padding: EdgeInsets.all(6), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
                else
                  RichAnswer(m.text),
                if (m.quiz != null) ...[
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => QuizPage(title: book?.title ?? 'اختبار', questions: m.quiz!))),
                    icon: const Icon(Icons.quiz_rounded, size: 18),
                    label: Text('فتح الاختبار (${m.quiz!.length} أسئلة)'),
                  ),
                ],
                if (m.cards != null) ...[
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FlashcardsPage(title: book?.title ?? 'بطاقات', cards: m.cards!))),
                    icon: const Icon(Icons.style_rounded, size: 18),
                    label: Text('فتح البطاقات (${m.cards!.length})'),
                  ),
                ],
                if (m.text.isNotEmpty && m.quiz == null && m.cards == null)
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: IconButton(
                      iconSize: 18,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(minWidth: 30, minHeight: 28),
                      tooltip: 'نسخ',
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: m.text));
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم النسخ')));
                      },
                      icon: Icon(Icons.copy_rounded, color: HC.cream.withValues(alpha: .7)),
                    ),
                  ),
              ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(
          backgroundColor: HC.deep,
          title: const Text('المساعد الذكي'),
          actions: [
            IconButton(
              tooltip: showContextBar ? 'إخفاء شريط الكتاب' : 'اختيار الكتاب والصفحات',
              onPressed: () => setState(() => showContextBar = !showContextBar),
              icon: Icon(showContextBar ? Icons.expand_less_rounded : Icons.menu_book_rounded),
            ),
            IconButton(
              tooltip: 'سجل الامتحانات (آخر 10)',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const QuizHistoryPage())),
              icon: const Icon(Icons.history_edu_rounded),
            ),
            if (msgs.isNotEmpty)
              IconButton(
                tooltip: 'محادثة جديدة',
                onPressed: busy ? null : () => setState(() => msgs.clear()),
                icon: const Icon(Icons.add_comment_rounded),
              ),
            IconButton(tooltip: 'إعدادات المفتاح', onPressed: _showKeySheet, icon: const Icon(Icons.tune_rounded)),
          ],
        ),
        body: SafeArea(
          child: ListenableBuilder(
            listenable: Listenable.merge([AppData.aiKey, AppData.aiFast, Store.books]),
            builder: (context, _) {
              if (AppData.aiKey.value.isEmpty) {
                return ListView(padding: const EdgeInsets.all(16), children: const [GlassCard(child: AiKeyEditor())]);
              }
              return Column(children: [
                if (showContextBar)
                  Container(
                    padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                    decoration: BoxDecoration(color: HC.cream.withValues(alpha: .06), border: Border(bottom: BorderSide(color: HC.cream.withValues(alpha: .12)))),
                    child: Column(children: [
                      Row(children: [
                        Expanded(
                          flex: 5,
                          child: DropdownButtonFormField<String>(
                            value: book?.id,
                            isExpanded: true,
                            decoration: const InputDecoration(labelText: 'الكتاب', isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
                            items: [for (final b in Store.books.value) DropdownMenuItem(value: b.id, child: Text(b.title, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)))],
                            onChanged: (v) {
                              if (v != null) setState(() => _pick(Store.books.value.firstWhere((b) => b.id == v)));
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(width: 58, child: TextField(controller: fromC, keyboardType: TextInputType.number, textAlign: TextAlign.center, decoration: const InputDecoration(labelText: 'من', isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 8)))),
                        const SizedBox(width: 6),
                        SizedBox(width: 58, child: TextField(controller: toC, keyboardType: TextInputType.number, textAlign: TextAlign.center, decoration: const InputDecoration(labelText: 'إلى', isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 8)))),
                      ]),
                      const SizedBox(height: 8),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(children: [
                          ChoiceChip(
                            avatar: const Icon(Icons.bolt_rounded, size: 15),
                            label: const Text('سريع', style: TextStyle(fontSize: 12)),
                            selected: AppData.aiFast.value,
                            onSelected: (_) {
                              AppData.aiFast.value = true;
                              AppData.save();
                            },
                          ),
                          const SizedBox(width: 6),
                          ChoiceChip(
                            avatar: const Icon(Icons.auto_awesome_rounded, size: 15),
                            label: const Text('دقيق', style: TextStyle(fontSize: 12)),
                            selected: !AppData.aiFast.value,
                            onSelected: (_) {
                              AppData.aiFast.value = false;
                              AppData.save();
                            },
                          ),
                          const SizedBox(width: 8),
                          ActionChip(avatar: const Icon(Icons.ios_share_rounded, size: 15), label: const Text('تصدير NotebookLM', style: TextStyle(fontSize: 12)), onPressed: busy || book == null ? null : _exportForNotebookLm),
                          const SizedBox(width: 6),
                          ActionChip(avatar: const Icon(Icons.open_in_new_rounded, size: 15), label: const Text('NotebookLM', style: TextStyle(fontSize: 12)), onPressed: () => launchUrl(Uri.parse('https://notebook.google/'), mode: LaunchMode.externalApplication)),
                        ]),
                      ),
                    ]),
                  ),
                Expanded(
                  child: msgs.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.auto_awesome_rounded, size: 46, color: HC.cream.withValues(alpha: .75)),
                              const SizedBox(height: 12),
                              Text(book == null ? 'أضف كتاباً للمكتبة أولاً' : 'اسألني عن «${book!.title}»', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 6),
                              Text('اختر إجراءً سريعاً بالأسفل أو اكتب سؤالك مباشرة، وسأتابع معك المحادثة.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .68))),
                            ]),
                          ),
                        )
                      : ListView.builder(
                          controller: sc,
                          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                          itemCount: msgs.length,
                          itemBuilder: (_, i) => _bubble(msgs[i]),
                        ),
                ),
                // شريط الاختصارات السريعة فوق مربع المحادثة
                Container(
                  padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      ActionChip(avatar: const Icon(Icons.notes_rounded, size: 16), label: const Text('لخّص'), onPressed: busy || book == null ? null : () => _run('sum')),
                      const SizedBox(width: 6),
                      ActionChip(avatar: const Icon(Icons.lightbulb_outline_rounded, size: 16), label: const Text('اشرح ببساطة'), onPressed: busy || book == null ? null : () => _run('easy')),
                      const SizedBox(width: 6),
                      ActionChip(avatar: const Icon(Icons.quiz_rounded, size: 16), label: Text('اختبرني ($qCount)'), onPressed: busy || book == null ? null : _showQuizOptions),
                      const SizedBox(width: 6),
                      ActionChip(avatar: const Icon(Icons.style_rounded, size: 16), label: const Text('بطاقات مراجعة'), onPressed: busy || book == null ? null : () => _run('cards')),
                    ]),
                  ),
                ),
                // مربع إدخال المحادثة الحديث
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: qC,
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _run('ask'),
                        decoration: InputDecoration(
                          hintText: 'اكتب سؤالك عن الصفحات المختارة...',
                          filled: true,
                          fillColor: HC.cream.withValues(alpha: .10),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: busy || book == null ? null : () => _run('ask'),
                      icon: const Icon(Icons.send_rounded),
                    ),
                  ]),
                ),
              ]);
            },
          ),
        ),
      );
}
