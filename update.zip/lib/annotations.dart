import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'model.dart';
import 'pdf_tools.dart';
import 'store.dart';

class Ping extends ChangeNotifier {
  void ping() => notifyListeners();
}

/// كل ملاحظات كتاب واحد + إعدادات القراءة والأدوات.
class Annotations extends ChangeNotifier {
  Annotations._(this.bookId);
  final String bookId;
  final strokes = <Stroke>[];
  final stickers = <StickerItem>[];
  final pins = <Pin>[];
  // سجل تراجع/إعادة (لقطات كاملة): يشمل الإضافة والحذف والتحريك والتعديل
  final _hist = <String>[];
  int _hi = -1;
  Timer? _histT;
  final settings = Ping(); // يتغير عند تغيير الأداة أو وضع القراءة
  Stroke? draft;
  final hit = ValueNotifier<SearchHit?>(null); // تمييز مؤقت لنتيجة بحث
  String tool = 'none'; // none | hl | pen | arrow | circle | erase | pin
  final toolColor = <String, int>{'hl': 0xFFFFD54F, 'pen': 0xFFE53935, 'arrow': 0xFFE53935, 'circle': 0xFFE53935};
  String mode = 'original'; // original | paper | night
  final tone = <String, List<int>>{
    'paper': [0xFFF2E8C9, 0xFF3C3B37],
    'night': [0xFF16201E, 0xFFD9D4C4],
  };
  double dim = 0;
  // طريقة العرض
  bool flip = false; // false = تمرير، true = تقليب الصفحات
  bool spread = false; // صفحتان متجاورتان
  bool rtl = true; // كتاب عربي (الصفحة الأولى يمين)
  bool coverAlone = true; // الغلاف منفرد عند الصفحتين
  bool protectPhotos = true; // حماية الصور بالوضع الليلي (وضع التقليب)
  bool hlFree = false; // التمييز: false = خط مستقيم، true = رسم حر
  String arrowStyle = 'straight';
  String arrowHead = 'end'; // end | start | both | none
  double widthScale = 1; // سماكة أدوات الرسم (1 / 1.8 / 3)
  Timer? _t;

  File get _file => File('${Store.dir.path}/ann_$bookId.json');

  static Future<Annotations> open(String id) async {
    final a = Annotations._(id);
    if (await a._file.exists()) {
      try {
        a._load(jsonDecode(await a._file.readAsString()) as Map<String, dynamic>);
      } catch (_) {}
    }
    a._initHist();
    return a;
  }

  void _load(Map<String, dynamic> j) {
    strokes.addAll((j['strokes'] as List? ?? []).map((e) => Stroke.fromJson(e as Map<String, dynamic>)));
    stickers.addAll((j['stickers'] as List? ?? []).map((e) => StickerItem.fromJson(e as Map<String, dynamic>)));
    pins.addAll((j['pins'] as List? ?? []).map((e) => Pin.fromJson(e as Map<String, dynamic>)));
    mode = j['mode'] ?? 'original';
    flip = j['flip'] ?? false;
    spread = j['spread'] ?? false;
    rtl = j['rtl'] ?? true;
    coverAlone = j['cover'] ?? true;
    protectPhotos = j['protect'] ?? true;
    dim = (j['dim'] as num?)?.toDouble() ?? 0;
    final t = j['tone'] as Map<String, dynamic>?;
    if (t != null) t.forEach((k, v) => tone[k] = List<int>.from(v as List));
  }

  Map<String, dynamic> exportJson() => _json();

  /// يدمج ملاحظات مستوردة (من ملف .hashiya). replace=true يمسح الحالي أولاً.
  void importJson(Map<String, dynamic> j, {required bool replace}) {
    if (replace) {
      strokes.clear();
      stickers.clear();
      pins.clear();
      _hist.clear();
      _hi = -1;
    }
    for (final e in (j['strokes'] as List? ?? [])) {
      final x = Stroke.fromJson(e as Map<String, dynamic>);
      if (!strokes.any((o) => o.id == x.id)) strokes.add(x);
    }
    for (final e in (j['stickers'] as List? ?? [])) {
      final x = StickerItem.fromJson(e as Map<String, dynamic>);
      if (!stickers.any((o) => o.id == x.id)) stickers.add(x);
    }
    for (final e in (j['pins'] as List? ?? [])) {
      final x = Pin.fromJson(e as Map<String, dynamic>);
      if (!pins.any((o) => o.id == x.id)) pins.add(x);
    }
    touch();
  }

  Map<String, dynamic> _json() => {
        'strokes': strokes.map((e) => e.toJson()).toList(),
        'stickers': stickers.map((e) => e.toJson()).toList(),
        'pins': pins.map((e) => e.toJson()).toList(),
        'mode': mode, 'dim': dim, 'tone': tone,
        'flip': flip, 'spread': spread, 'rtl': rtl, 'cover': coverAlone, 'protect': protectPhotos,
      };

  void save() {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 400), flush);
  }

  Future<void> flush() async {
    _t?.cancel();
    await _file.writeAsString(jsonEncode(_json()));
  }

  void touch() {
    notifyListeners();
    save();
    _histT?.cancel();
    _histT = Timer(const Duration(milliseconds: 400), _commitHist);
  }

  void refresh() => notifyListeners();

  String get toneSig => '$mode|${tone[mode]?.join(',')}|${dim.toStringAsFixed(2)}';

  /// بصمة طريقة العرض + المظهر: أي تغيير فيها يعيد بناء العارض.
  String get viewSig => '$toneSig|$flip|$spread|$rtl|$coverAlone|$protectPhotos';

  void setTool(String t) {
    tool = tool == t ? 'none' : t;
    draft = null;
    settings.ping();
    notifyListeners();
  }

  void setColor(int c) {
    if (toolColor.containsKey(tool)) toolColor[tool] = c;
    settings.ping();
  }

  void setHlFree(bool v) {
    hlFree = v;
    settings.ping();
  }

  void setArrowHead(String v) {
    arrowHead = v;
    settings.ping();
  }

  void setArrowStyle(String v) {
    arrowStyle = v;
    settings.ping();
  }

  void setWidthScale(double v) {
    widthScale = v;
    settings.ping();
  }

  void setMode(String m) {
    mode = m;
    settings.ping();
    save();
  }

  void setTone(String m, {int? bg, int? text}) {
    final t = tone[m]!;
    if (bg != null) t[0] = bg;
    if (text != null) t[1] = text;
    settings.ping();
    save();
  }

  void setDim(double v) {
    dim = v;
    settings.ping();
    save();
  }

  void addStroke(Stroke s) {
    strokes.add(s);
    touch();
  }

  void commitDraft() {
    final d = draft;
    draft = null;
    if (d != null) {
      addStroke(d);
    } else {
      refresh();
    }
  }

  void addSticker(StickerItem s) {
    stickers.add(s);
    touch();
  }

  void removeSticker(StickerItem s) {
    stickers.removeWhere((x) => x.id == s.id);
    touch();
  }

  void addPin(Pin p) {
    pins.add(p);
    touch();
  }

  void removePin(Pin p) {
    pins.removeWhere((x) => x.id == p.id);
    final m = p.media;
    if (m != null) {
      try {
        File(m).delete();
      } catch (_) {}
    }
    touch();
  }

  String _snap() => jsonEncode({
        's': [for (final x in strokes) x.toJson()],
        'k': [for (final x in stickers) x.toJson()],
        'p': [for (final x in pins) x.toJson()],
      });

  void _initHist() {
    _hist
      ..clear()
      ..add(_snap());
    _hi = 0;
  }

  void _commitHist() {
    _histT?.cancel();
    _histT = null;
    if (_hi < 0) return;
    final snap = _snap();
    if (_hist[_hi] == snap) return;
    if (_hi < _hist.length - 1) _hist.removeRange(_hi + 1, _hist.length);
    _hist.add(snap);
    if (_hist.length > 80) _hist.removeAt(0);
    _hi = _hist.length - 1;
  }

  void _restore(String snap) {
    final j = jsonDecode(snap) as Map<String, dynamic>;
    strokes
      ..clear()
      ..addAll((j['s'] as List).map((e) => Stroke.fromJson(e as Map<String, dynamic>)));
    stickers
      ..clear()
      ..addAll((j['k'] as List).map((e) => StickerItem.fromJson(e as Map<String, dynamic>)));
    pins
      ..clear()
      ..addAll((j['p'] as List).map((e) => Pin.fromJson(e as Map<String, dynamic>)));
    draft = null;
    notifyListeners();
    save();
  }

  /// تراجع خطوة (ctrl+Z).
  void undo() {
    _commitHist();
    if (_hi > 0) {
      _hi--;
      _restore(_hist[_hi]);
    }
  }

  /// إعادة خطوة تم التراجع عنها (ctrl+shift+Z).
  void redo() {
    _commitHist();
    if (_hi >= 0 && _hi < _hist.length - 1) {
      _hi++;
      _restore(_hist[_hi]);
    }
  }

  void setFlip(bool v) {
    flip = v;
    settings.ping();
    save();
  }

  void setSpread(bool v) {
    spread = v;
    settings.ping();
    save();
  }

  void setRtl(bool v) {
    rtl = v;
    settings.ping();
    save();
  }

  void setCoverAlone(bool v) {
    coverAlone = v;
    settings.ping();
    save();
  }

  void setProtectPhotos(bool v) {
    protectPhotos = v;
    settings.ping();
    save();
  }

  @override
  void dispose() {
    _histT?.cancel();
    super.dispose();
  }

  bool eraseAt(int page, Offset q, double thr) {
    final before = strokes.length;
    strokes.removeWhere((s) => s.page == page && _hit(s, q, thr));
    if (strokes.length != before) {
      touch();
      return true;
    }
    return false;
  }

  bool _hit(Stroke s, Offset q, double thr) {
    if (s.kind == 'arrow' || s.kind == 'hl') {
      final wide = s.style.contains('curve') || s.style == 'wave' || s.style == 'hand';
      return _segDist(s.pts.first, s.pts.last, q) < (wide ? thr * 3 : thr);
    }
    if (s.kind == 'circle') return Rect.fromPoints(s.pts.first, s.pts.last).inflate(thr).contains(q);
    if (s.pts.length == 1) return (s.pts.first - q).distance < thr;
    for (var i = 0; i < s.pts.length - 1; i++) {
      if (_segDist(s.pts[i], s.pts[i + 1], q) < thr) return true;
    }
    return false;
  }

  double _segDist(Offset a, Offset b, Offset p) {
    final ab = b - a;
    final l2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (l2 == 0) return (p - a).distance;
    final ap = p - a;
    final t = ((ap.dx * ab.dx + ap.dy * ab.dy) / l2).clamp(0.0, 1.0).toDouble();
    return (p - (a + ab * t)).distance;
  }
}
