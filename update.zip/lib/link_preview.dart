import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'theme.dart';

final _urlRe = RegExp(r'https?://[^\s<>"]+', caseSensitive: false);

List<String> extractUrls(String text) => _urlRe.allMatches(text).map((m) => m.group(0)!).toList();

String? youtubeId(String url) {
  final u = Uri.tryParse(url);
  if (u == null) return null;
  final h = u.host.replaceFirst('www.', '').replaceFirst('m.', '');
  if (h == 'youtu.be' && u.pathSegments.isNotEmpty) return u.pathSegments.first;
  if (h == 'youtube.com' || h == 'music.youtube.com') {
    if (u.queryParameters['v'] != null) return u.queryParameters['v'];
    if (u.pathSegments.length >= 2 && (u.pathSegments.first == 'shorts' || u.pathSegments.first == 'embed' || u.pathSegments.first == 'live')) return u.pathSegments[1];
  }
  return null;
}

class LinkInfo {
  LinkInfo(this.url, {this.title, this.image, this.video = false});
  final String url;
  final String? title, image;
  final bool video;
}

final _cache = <String, LinkInfo>{};

String _unescape(String s) => s.replaceAll('&amp;', '&').replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>');

String? _meta(String html, String prop) {
  final a = RegExp('<meta[^>]+(?:property|name)=["\']$prop["\'][^>]*content=["\']([^"\']*)["\']', caseSensitive: false).firstMatch(html);
  if (a != null) return _unescape(a.group(1)!);
  final b = RegExp('<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:property|name)=["\']$prop["\']', caseSensitive: false).firstMatch(html);
  return b == null ? null : _unescape(b.group(1)!);
}

Future<String> _get(String url) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 6);
  try {
    final req = await c.getUrl(Uri.parse(url));
    req.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36');
    final resp = await req.close().timeout(const Duration(seconds: 8));
    final bytes = <int>[];
    await for (final chunk in resp) {
      bytes.addAll(chunk);
      if (bytes.length > 250000) break;
    }
    return utf8.decode(bytes, allowMalformed: true);
  } finally {
    c.close(force: true);
  }
}

Future<LinkInfo> fetchInfo(String url) async {
  final hit = _cache[url];
  if (hit != null) return hit;
  LinkInfo info;
  final id = youtubeId(url);
  try {
    if (id != null) {
      String? title;
      try {
        final j = jsonDecode(await _get('https://www.youtube.com/oembed?format=json&url=${Uri.encodeComponent(url)}')) as Map<String, dynamic>;
        title = j['title'] as String?;
      } catch (_) {}
      info = LinkInfo(url, title: title, image: 'https://img.youtube.com/vi/$id/hqdefault.jpg', video: true);
    } else {
      final html = await _get(url);
      var img = _meta(html, 'og:image') ?? _meta(html, 'twitter:image');
      if (img != null) img = Uri.parse(url).resolve(img).toString();
      final t = _meta(html, 'og:title') ?? RegExp(r'<title[^>]*>([^<]*)</title>', caseSensitive: false).firstMatch(html)?.group(1);
      info = LinkInfo(url, title: t == null ? null : _unescape(t.trim()), image: img);
    }
  } catch (_) {
    info = LinkInfo(url, image: id == null ? null : 'https://img.youtube.com/vi/$id/hqdefault.jpg', video: id != null);
  }
  return _cache[url] = info;
}

Future<void> openLink(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

/// بطاقة رابط: مصغّرة فيديو يوتيوب أو صورة/عنوان الصفحة، وبالضغط يفتح الرابط.
class LinkCard extends StatefulWidget {
  const LinkCard({super.key, required this.url});
  final String url;
  @override
  State<LinkCard> createState() => _LinkCardState();
}

class _LinkCardState extends State<LinkCard> {
  Timer? _t;
  Future<LinkInfo>? _f;

  @override
  void initState() {
    super.initState();
    // انتظار قصير حتى لا نجلب الرابط وهو قيد الكتابة
    _t = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _f = fetchInfo(widget.url));
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final host = Uri.tryParse(widget.url)?.host ?? widget.url;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => openLink(widget.url),
      child: Container(
        decoration: BoxDecoration(color: HC.cream.withValues(alpha: .08), borderRadius: BorderRadius.circular(14), border: Border.all(color: HC.cream.withValues(alpha: .2))),
        clipBehavior: Clip.antiAlias,
        child: FutureBuilder<LinkInfo>(
          future: _f,
          builder: (context, snap) {
            final i = snap.data;
            final loading = _f == null || snap.connectionState != ConnectionState.done;
            return Row(children: [
              SizedBox(
                width: 130,
                height: 80,
                child: Stack(fit: StackFit.expand, children: [
                  if (i?.image != null)
                    Image.network(i!.image!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const _Ph())
                  else
                    const _Ph(),
                  if (i?.video == true) const Center(child: Icon(Icons.play_circle_fill_rounded, size: 38, color: Colors.white)),
                ]),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(loading ? 'جاري تحميل المعاينة...' : (i?.title ?? host), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(host, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
                  ]),
                ),
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.open_in_new_rounded, size: 20)),
            ]);
          },
        ),
      ),
    );
  }
}

class _Ph extends StatelessWidget {
  const _Ph();
  @override
  Widget build(BuildContext context) => Container(color: HC.cream.withValues(alpha: .12), child: const Center(child: Icon(Icons.link_rounded, size: 30)));
}
