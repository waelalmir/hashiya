import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:pdfrx/pdfrx.dart';
import 'ai.dart';
import 'ocr/ocr_engine.dart';
import 'pdf_tools.dart';
import 'store.dart';

/// فهرس نص (OCR) للصفحات المصوّرة في كتاب، يُحفظ على الجهاز ويُستخدم في البحث.
class OcrIndex {
  OcrIndex(this.bookId);
  final String bookId;
  final Map<int, String> pages = {};
  File get _f => File('${Store.dir.path}/ocr/$bookId.json');

  static Future<OcrIndex> load(String bookId) async {
    final x = OcrIndex(bookId);
    try {
      if (await x._f.exists()) {
        final j = jsonDecode(await x._f.readAsString()) as Map<String, dynamic>;
        ((j['pages'] as Map?) ?? {}).forEach((k, v) => x.pages[int.parse('$k')] = '$v');
      }
    } catch (_) {}
    return x;
  }

  Future<void> save() async {
    await _f.parent.create(recursive: true);
    await _f.writeAsString(jsonEncode({'pages': pages.map((k, v) => MapEntry('$k', v))}));
  }
}

class OcrIndexer {
  static final _marker = RegExp(r'={2,}\s*PAGE\s*(\d+)\s*={2,}');

  /// يفهرس الصفحات التي بلا نص. online عبر Gemini (3 صفحات بكل طلب)، وإلا بمحرك OCR أوفلاين.
  /// يرجع عدد الصفحات التي فُهرست الآن.
  static Future<int> run(
    Book b,
    OcrIndex idx, {
    required bool online,
    required bool Function() cancelled,
    required void Function(int done, int total, String note) onProgress,
  }) async {
    PdfDocument? doc;
    var count = 0;
    try {
      doc = await PdfDocument.openFile(b.path);
      final total = doc.pages.length;
      onProgress(0, total, 'جاري تحديد الصفحات المصوّرة...');
      final todo = <int>[];
      for (var p = 1; p <= total; p++) {
        if (cancelled()) return count;
        if (idx.pages.containsKey(p)) continue;
        final pt = await PdfTools.loadPageText(doc, p);
        if (pt == null || pt.text.trim().length < 5) todo.add(p);
      }
      if (todo.isEmpty) {
        onProgress(0, 0, 'كل صفحات الملف فيها نص أو مفهرسة سابقاً');
        return 0;
      }
      final step = online ? 3 : 1;
      for (var i = 0; i < todo.length; i += step) {
        if (cancelled()) break;
        final batch = todo.sublist(i, math.min(i + step, todo.length));
        onProgress(i, todo.length, 'جاري فهرسة الصفحات ${batch.first}${batch.length > 1 ? '–${batch.last}' : ''} ...');
        if (online) {
          final imgs = <List<int>>[];
          for (final p in batch) {
            final png = await PdfTools.renderPng(doc, p);
            if (png != null) imgs.add(png);
          }
          if (imgs.length != batch.length) continue;
          final prompt = 'الصور التالية ${batch.length} صفحات متتالية من كتاب. استخرج نص كل صفحة كما هو تماماً دون أي شرح، '
              'وابدأ نص كل صفحة بسطر فيه فقط ===PAGE k=== حيث k رقم الصفحة بالترتيب (1 للأولى). النص عربي غالباً.';
          String r = '';
          for (var attempt = 0; attempt < 4; attempt++) {
            try {
              r = await Gemini.ask(prompt, images: imgs);
              break;
            } on AiException catch (e) {
              if (e.rateLimited && attempt < 3) {
                onProgress(i, todo.length, 'حد الاستخدام المجاني، انتظار 30 ثانية...');
                await Future.delayed(const Duration(seconds: 30));
                if (cancelled()) return count;
              } else {
                rethrow;
              }
            }
          }
          final ms = _marker.allMatches(r).toList();
          if (ms.isEmpty && batch.length == 1) {
            idx.pages[batch.first] = r.trim();
            count++;
          } else {
            for (var k = 0; k < ms.length; k++) {
              final n = int.parse(ms[k].group(1)!);
              final end = k + 1 < ms.length ? ms[k + 1].start : r.length;
              if (n >= 1 && n <= batch.length) {
                idx.pages[batch[n - 1]] = r.substring(ms[k].end, end).trim();
                count++;
              }
            }
          }
        } else {
          final p = batch.first;
          final png = await PdfTools.renderPng(doc, p, width: 1800);
          if (png == null) continue;
          final f = File('${Store.dir.path}/tmp_ocr_idx.png');
          await f.writeAsBytes(png);
          idx.pages[p] = (await OcrEngine.recognize(f.path)).trim();
          count++;
        }
        await idx.save();
      }
      onProgress(todo.length, todo.length, 'تمت الفهرسة');
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
    return count;
  }
}
