const kVersion = '2.0';
/// رقم البناء يأتي من GitHub (رقم التشغيل - رمز التعديل)، وبه تعرف أي نسخة مثبتة عندك.
const kBuild = String.fromEnvironment('BUILD_ID', defaultValue: 'محلي');
