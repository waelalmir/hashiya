import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'annotations.dart';
import 'link_preview.dart';
import 'media_view.dart';
import 'model.dart';
import 'store.dart';
import 'theme.dart';

Future<void> showPinSheet(BuildContext context, Annotations ann, Pin pin, {bool isNew = false}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HC.green,
    builder: (c) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
      child: SingleChildScrollView(child: _PinSheet(ann: ann, pin: pin, isNew: isNew)),
    ),
  );
}

class _PinSheet extends StatefulWidget {
  const _PinSheet({required this.ann, required this.pin, required this.isNew});
  final Annotations ann;
  final Pin pin;
  final bool isNew;
  @override
  State<_PinSheet> createState() => _PinSheetState();
}

class _PinSheetState extends State<_PinSheet> {
  late final text = TextEditingController(text: widget.pin.text);
  final rec = AudioRecorder();
  final player = AudioPlayer();
  bool recording = false, playing = false, busy = false, copying = false;
  Pin get pin => widget.pin;

  @override
  void initState() {
    super.initState();
    player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => playing = false);
    });
  }

  @override
  void dispose() {
    rec.dispose();
    player.dispose();
    text.dispose();
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _toggleRec() async {
    if (recording) {
      final path = await rec.stop();
      setState(() {
        recording = false;
        if (path != null) pin.audio = path;
      });
      return;
    }
    if (!await rec.hasPermission()) {
      _snack('لازم تسمح للتطبيق باستخدام الميكروفون');
      return;
    }
    final dir = Directory('${Store.dir.path}/audio');
    await dir.create(recursive: true);
    final path = '${dir.path}/${pin.id}_${DateTime.now().millisecondsSinceEpoch}.wav';
    await rec.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1), path: path);
    setState(() => recording = true);
  }

  Future<void> _togglePlay() async {
    if (pin.audio == null) return;
    if (playing) {
      await player.stop();
      setState(() => playing = false);
    } else {
      await player.play(DeviceFileSource(pin.audio!));
      setState(() => playing = true);
    }
  }

  Future<void> _attach(String kind) async {
    final r = await FilePicker.platform.pickFiles(type: kind == 'video' ? FileType.video : FileType.audio);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return;
    final f = r.files.single;
    setState(() => copying = true);
    try {
      final dir = Directory('${Store.dir.path}/media');
      await dir.create(recursive: true);
      final dest = '${dir.path}/${pin.id}_${DateTime.now().millisecondsSinceEpoch}_${f.name}';
      await File(f.path!).copy(dest);
      final old = pin.media;
      if (old != null && old != dest) {
        try {
          await File(old).delete();
        } catch (_) {}
      }
      if (mounted) {
        setState(() {
          pin.media = dest;
          pin.mediaName = f.name;
          pin.mediaKind = kind;
          pin.mediaPos = 0;
        });
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر نسخ الملف: $e')));
    }
    if (mounted) setState(() => copying = false);
  }

  Future<void> _play() async {
    final pos = await openMediaPlayer(context, path: pin.media!, kind: pin.mediaKind ?? 'audio', name: pin.mediaName ?? '', startMs: pin.mediaPos ?? 0);
    if (pos != null && mounted) setState(() => pin.mediaPos = pos);
  }

  Future<void> _removeMedia() async {
    final old = pin.media;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    setState(() {
      pin.media = null;
      pin.mediaName = null;
      pin.mediaKind = null;
      pin.mediaPos = null;
    });
  }

  Widget _mediaRow() {
    final exists = pin.media != null && File(pin.media!).existsSync();
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: HC.cream.withValues(alpha: .1), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(pin.mediaKind == 'video' ? Icons.videocam_rounded : Icons.headphones_rounded),
          const SizedBox(width: 8),
          Expanded(child: Text(pin.mediaName ?? '', maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
        if (!exists)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('تنبيه: الملف المرفق غير موجود (انحذف أو لم يُنقل مع الملاحظات). التعليق باقٍ، وبتقدر تختار الملف من جديد.', style: TextStyle(fontSize: 12, color: Colors.amber.shade200)),
          ),
        const SizedBox(height: 6),
        Wrap(spacing: 8, children: [
          if (exists) FilledButton.tonalIcon(onPressed: _play, icon: const Icon(Icons.play_arrow_rounded), label: Text((pin.mediaPos ?? 0) > 1500 ? 'تكملة التشغيل' : 'تشغيل')),
          OutlinedButton(onPressed: () => _attach(pin.mediaKind ?? 'audio'), child: Text(exists ? 'تغيير الملف' : 'اختيار الملف من جديد')),
          TextButton(onPressed: _removeMedia, child: const Text('إزالة المرفق')),
        ]),
      ]),
    );
  }

  void _save() {
    pin.text = text.text;
    widget.ann.touch();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('تعليق', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          TextField(controller: text, minLines: 3, maxLines: 6, decoration: const InputDecoration(hintText: 'اكتب ملاحظتك أو ألصق رابطاً (يوتيوب أو غيره)', border: OutlineInputBorder())),
          AnimatedBuilder(
            animation: text,
            builder: (c, _) {
              final urls = extractUrls(text.text).take(3).toList();
              if (urls.isEmpty) return const SizedBox.shrink();
              return Column(children: [
                const SizedBox(height: 12),
                for (final u in urls) Padding(padding: const EdgeInsets.only(bottom: 8), child: LinkCard(key: ValueKey(u), url: u)),
              ]);
            },
          ),
          const SizedBox(height: 14),
          Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
            FilledButton.icon(
              onPressed: _toggleRec,
              icon: Icon(recording ? Icons.stop_rounded : Icons.mic_rounded),
              label: Text(recording ? 'إيقاف التسجيل' : (pin.audio == null ? 'تسجيل صوت' : 'إعادة التسجيل')),
            ),
            if (pin.audio != null && !recording)
              OutlinedButton.icon(onPressed: _togglePlay, icon: Icon(playing ? Icons.stop_rounded : Icons.play_arrow_rounded), label: Text(playing ? 'إيقاف' : 'تشغيل')),
            if (!pin.hasMedia) OutlinedButton.icon(onPressed: copying ? null : () => _attach('audio'), icon: const Icon(Icons.headphones_rounded), label: const Text('إرفاق صوت')),
            if (!pin.hasMedia) OutlinedButton.icon(onPressed: copying ? null : () => _attach('video'), icon: const Icon(Icons.videocam_rounded), label: const Text('إرفاق فيديو')),
          ]),
          if (copying) const Padding(padding: EdgeInsets.only(top: 10), child: LinearProgressIndicator()),
          if (pin.hasMedia) _mediaRow(),
          const SizedBox(height: 18),
          Row(children: [
            FilledButton(onPressed: _save, child: const Text('حفظ')),
            const SizedBox(width: 10),
            TextButton(
              onPressed: () {
                widget.ann.removePin(pin);
                Navigator.pop(context);
              },
              child: const Text('حذف التعليق'),
            ),
          ]),
        ]),
      );
}
