import 'dart:math' as math;
import 'package:flutter/material.dart';

/// تعريف قالب واحد (صفحة بيضاء أو قالب تنظيم/حفظ قرآن).
class BoardTemplate {
  const BoardTemplate({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.category, // blank | planner | quran
    required this.accent,
    required this.paperBg,
    required this.icon,
  });
  final String id;
  final String name;
  final String subtitle;
  final String category;
  final Color accent;
  final Color paperBg;
  final IconData icon;
}

/// 4 أنماط للصفحة البيضاء + 10 قوالب عربية مميزة (7 تنظيم ودراسة + 3 حفظ القرآن الكريم).
const kBlankTemplates = <BoardTemplate>[
  BoardTemplate(id: 'blank_plain', name: 'صفحة بيضاء', subtitle: 'ورقة بيضاء سادة للرسم الحر', category: 'blank', accent: Color(0xFF4E6E5D), paperBg: Color(0xFFFFFDF8), icon: Icons.crop_portrait_rounded),
  BoardTemplate(id: 'blank_lined', name: 'ورق مسطّر', subtitle: 'أسطر هادئة للكتابة والتلخيص', category: 'blank', accent: Color(0xFF5D7A8C), paperBg: Color(0xFFFFFBF2), icon: Icons.format_align_right_rounded),
  BoardTemplate(id: 'blank_dotted', name: 'ورق منقّط', subtitle: 'نقاط بوليت جورنال للرسم والتنظيم', category: 'blank', accent: Color(0xFF8C6D5D), paperBg: Color(0xFFFFFBF5), icon: Icons.grain_rounded),
  BoardTemplate(id: 'blank_grid', name: 'ورق مربعات', subtitle: 'شبكة هندسية للجداول والمخططات', category: 'blank', accent: Color(0xFF6B7B6E), paperBg: Color(0xFFFAFBF8), icon: Icons.grid_4x4_rounded),
];

const kRichTemplates = <BoardTemplate>[
  // 7 قوالب تنظيم ودراسة بستايل يدوي دافئ
  BoardTemplate(id: 'daily_cozy', name: 'مخطط اليوم الدافئ', subtitle: 'جدول ساعي + أولويات + مهام + ماء ومزاج', category: 'planner', accent: Color(0xFF8D6B53), paperBg: Color(0xFFFFF8F0), icon: Icons.wb_sunny_rounded),
  BoardTemplate(id: 'weekly_study', name: 'خطة دراستي الأسبوعية', subtitle: 'جدول السبت–الجمعة + أهداف + تقييم الأسبوع', category: 'planner', accent: Color(0xFFB56B84), paperBg: Color(0xFFFFFAFC), icon: Icons.calendar_view_week_rounded),
  BoardTemplate(id: 'student_pomo', name: 'مخطط الطالب وبومودورو', subtitle: 'جدول مذاكرة + متتبع بومودورو + عد تنازلي', category: 'planner', accent: Color(0xFF4A6FA5), paperBg: Color(0xFFF6F9FF), icon: Icons.timer_rounded),
  BoardTemplate(id: 'monthly_plan', name: 'المخطط الشهري الشامل', subtitle: 'تقويم 5 أسابيع + عادات + امتنان وتأمل', category: 'planner', accent: Color(0xFF8669A8), paperBg: Color(0xFFFAF7FF), icon: Icons.calendar_month_rounded),
  BoardTemplate(id: 'vocab_notes', name: 'دفتر المفردات والفوائد', subtitle: 'كلمات ومصطلحات + معاني وأمثلة ببطاقات ملونة', category: 'planner', accent: Color(0xFF6F8A6B), paperBg: Color(0xFFFCF9F0), icon: Icons.menu_book_rounded),
  BoardTemplate(id: 'eisenhower', name: 'مصفوفة الأولويات', subtitle: 'عاجل ومهم / مهم / عاجل / لاحقاً (أيزنهاور)', category: 'planner', accent: Color(0xFFC27A4B), paperBg: Color(0xFFFFFBF5), icon: Icons.dashboard_rounded),
  BoardTemplate(id: 'habit_30', name: 'متتبع العادات (30 يوماً)', subtitle: '8 عادات يومية بدوائر تلوين ومكافأة الالتزام', category: 'planner', accent: Color(0xFF558B7B), paperBg: Color(0xFFF6FBF9), icon: Icons.track_changes_rounded),
  // 3 قوالب مبتكرة لتنظيم حفظ القرآن الكريم
  BoardTemplate(id: 'quran_heart', name: 'قلب القرآن (114 سورة)', subtitle: 'خريطة السور على شكل قلب — لوّن كل سورة تحفظها', category: 'quran', accent: Color(0xFFB85D72), paperBg: Color(0xFFFFF8F9), icon: Icons.favorite_rounded),
  BoardTemplate(id: 'quran_30juz', name: 'رحلة الأجزاء الثلاثين', subtitle: 'مسار الختمة (جزء 1–30) مع حفظ وتثبيت ومراجعة', category: 'quran', accent: Color(0xFF2D6A5B), paperBg: Color(0xFFF7FBF8), icon: Icons.route_rounded),
  BoardTemplate(id: 'quran_fortresses', name: 'الحصون الخمسة للحفظ', subtitle: 'الورد + التحضير + الحفظ الجديد + القريب والبعيد', category: 'quran', accent: Color(0xFF8E6C3A), paperBg: Color(0xFFFFFBF0), icon: Icons.shield_rounded),
];

BoardTemplate findTemplate(String id) {
  for (final t in kBlankTemplates) {
    if (t.id == id) return t;
  }
  for (final t in kRichTemplates) {
    if (t.id == id) return t;
  }
  return kBlankTemplates.first;
}

/// رسام القوالب بدقة متجهية عالية باستخدام خط PlaypenSansArabic (الستايل اليدوي).
class TemplatePainter extends CustomPainter {
  const TemplatePainter(this.templateId);
  final String templateId;

  static const _handFont = 'PlaypenSansArabic';

  @override
  void paint(Canvas canvas, Size size) {
    final tpl = findTemplate(templateId);
    canvas.drawRect(Offset.zero & size, Paint()..color = tpl.paperBg);
    switch (templateId) {
      case 'blank_plain':
        break;
      case 'blank_lined':
        _paintLined(canvas, size);
      case 'blank_dotted':
        _paintDotted(canvas, size);
      case 'blank_grid':
        _paintGrid(canvas, size);
      case 'daily_cozy':
        _paintDailyCozy(canvas, size);
      case 'weekly_study':
        _paintWeeklyStudy(canvas, size);
      case 'student_pomo':
        _paintStudentPomo(canvas, size);
      case 'monthly_plan':
        _paintMonthlyPlan(canvas, size);
      case 'vocab_notes':
        _paintVocabNotes(canvas, size);
      case 'eisenhower':
        _paintEisenhower(canvas, size);
      case 'habit_30':
        _paintHabit30(canvas, size);
      case 'quran_heart':
        _paintQuranHeart(canvas, size);
      case 'quran_30juz':
        _paintQuran30Juz(canvas, size);
      case 'quran_fortresses':
        _paintQuranFortresses(canvas, size);
    }
  }

  @override
  bool shouldRepaint(TemplatePainter oldDelegate) => oldDelegate.templateId != templateId;

  // ==================== أدوات رسم مساعدة ====================

  void _txt(Canvas c, String text, Offset pos, {double fs = 12, Color color = const Color(0xFF3E342C), FontWeight w = FontWeight.w600, TextAlign align = TextAlign.right, double maxW = 200, bool center = false}) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(fontFamily: _handFont, fontSize: fs, color: color, fontWeight: w, height: 1.2)),
      textDirection: TextDirection.rtl,
      textAlign: center ? TextAlign.center : align,
      maxLines: 2,
      ellipsis: '…',
    )..layout(maxWidth: maxW);
    final dx = center ? pos.dx - tp.width / 2 : (align == TextAlign.right ? pos.dx - tp.width : pos.dx);
    tp.paint(c, Offset(dx, pos.dy));
  }

  void _box(Canvas c, Rect r, {Color fill = Colors.white, Color border = const Color(0xFFD8C9B8), double rad = 10, double sw = 1.2}) {
    final rr = RRect.fromRectAndRadius(r, Radius.circular(rad));
    c.drawRRect(rr, Paint()..color = fill);
    c.drawRRect(rr, Paint()..color = border..style = PaintingStyle.stroke..strokeWidth = sw);
  }

  void _headerPill(Canvas c, Rect r, String title, Color bg, {Color fg = Colors.white, double fs = 11}) {
    final rr = RRect.fromRectAndRadius(r, Radius.circular(r.height / 2));
    c.drawRRect(rr, Paint()..color = bg);
    _txt(c, title, Offset(r.center.dx, r.top + (r.height - fs * 1.35) / 2), fs: fs, color: fg, w: FontWeight.w700, center: true, maxW: r.width - 8);
  }

  void _ruledLines(Canvas c, Rect r, int count, Color color, {bool checkCircles = false, bool checkBoxes = false, bool numbered = false}) {
    final step = r.height / count;
    final p = Paint()..color = color..strokeWidth = .8;
    final bp = Paint()..color = color.withValues(alpha: .9)..style = PaintingStyle.stroke..strokeWidth = 1.0;
    for (var i = 1; i <= count; i++) {
      final y = r.top + step * i;
      c.drawLine(Offset(r.left + 8, y), Offset(r.right - (checkCircles || checkBoxes || numbered ? 22 : 8), y), p);
      if (checkCircles) {
        c.drawCircle(Offset(r.right - 12, y - step * .42), math.min(4.2, step * .28), bp);
      } else if (checkBoxes) {
        final s = math.min(8.0, step * .52);
        c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(r.right - 12, y - step * .42), width: s, height: s), const Radius.circular(2)), bp);
      } else if (numbered) {
        _txt(c, '$i', Offset(r.right - 12, y - step * .72), fs: math.min(9.5, step * .55), color: color.withValues(alpha: .95), center: true, maxW: 16);
      }
    }
  }

  void _paintLined(Canvas c, Size s) {
    final p = Paint()..color = const Color(0xFFDCE4EA)..strokeWidth = 1;
    final step = s.height / 28;
    for (var y = step * 2; y < s.height - step; y += step) {
      c.drawLine(Offset(s.width * .05, y), Offset(s.width * .95, y), p);
    }
    c.drawLine(Offset(s.width * .88, 0), Offset(s.width * .88, s.height), Paint()..color = const Color(0xFFE9B8B8)..strokeWidth = 1.2);
  }

  void _paintDotted(Canvas c, Size s) {
    final p = Paint()..color = const Color(0xFFCBBFB2);
    final step = s.width / 24;
    for (var y = step; y < s.height - step * .5; y += step) {
      for (var x = step; x < s.width - step * .5; x += step) {
        c.drawCircle(Offset(x, y), 1.2, p);
      }
    }
  }

  void _paintGrid(Canvas c, Size s) {
    final p = Paint()..color = const Color(0xFFDDE5DC)..strokeWidth = .8;
    final step = s.width / 22;
    for (var x = step; x < s.width; x += step) {
      c.drawLine(Offset(x, 0), Offset(x, s.height), p);
    }
    for (var y = step; y < s.height; y += step) {
      c.drawLine(Offset(0, y), Offset(s.width, y), p);
    }
  }

  // ==================== 1. مخطط اليوم الدافئ ====================
  void _paintDailyCozy(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const brown = Color(0xFF7A563E);
    const soft = Color(0xFFEADACB);
    const line = Color(0xFFDCC9B6);

    // العنوان
    _txt(c, 'مُخطّط اليوم', Offset(w * .5, h * .022), fs: 22 * u, color: brown, w: FontWeight.w700, center: true, maxW: w * .7);
    _txt(c, 'خطّط ليومك • كن منتجاً • كن لطيفاً مع نفسك', Offset(w * .5, h * .072), fs: 9.5 * u, color: brown.withValues(alpha: .75), center: true, maxW: w * .85);

    // عمود أيمن: الجدول الزمني
    final schedR = Rect.fromLTWH(w * .52, h * .115, w * .44, h * .72);
    _box(c, schedR, fill: Colors.white, border: line, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(schedR.left + 8 * u, schedR.top + 6 * u, schedR.width - 16 * u, 22 * u), 'الجدول الزمني', brown, fs: 10.5 * u);
    final hours = ['6 ص', '7 ص', '8 ص', '9 ص', '10 ص', '11 ص', '12 م', '1 م', '2 م', '3 م', '4 م', '5 م', '6 م', '7 م', '8 م', '9 م', '10 م'];
    final rowH = (schedR.height - 36 * u) / hours.length;
    for (var i = 0; i < hours.length; i++) {
      final y = schedR.top + 32 * u + i * rowH;
      _txt(c, hours[i], Offset(schedR.right - 8 * u, y + 1 * u), fs: 8.2 * u, color: brown, maxW: 40 * u);
      c.drawLine(Offset(schedR.left + 10 * u, y + rowH - 2), Offset(schedR.right - 10 * u, y + rowH - 2), Paint()..color = soft..strokeWidth = .9);
    }

    // عمود أيسر علوي: أهم الأولويات
    final prioR = Rect.fromLTWH(w * .04, h * .115, w * .45, h * .21);
    _box(c, prioR, fill: Colors.white, border: line, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(prioR.left + 8 * u, prioR.top + 6 * u, prioR.width - 16 * u, 20 * u), 'أهم 3 أولويات', const Color(0xFFA67B5B), fs: 10 * u);
    _ruledLines(c, Rect.fromLTWH(prioR.left, prioR.top + 30 * u, prioR.width, prioR.height - 36 * u), 3, line, numbered: true);

    // قائمة المهام
    final todoR = Rect.fromLTWH(w * .04, h * .34, w * .45, h * .28);
    _box(c, todoR, fill: Colors.white, border: line, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(todoR.left + 8 * u, todoR.top + 6 * u, todoR.width - 16 * u, 20 * u), 'قائمة المهام', brown, fs: 10 * u);
    _ruledLines(c, Rect.fromLTWH(todoR.left, todoR.top + 30 * u, todoR.width, todoR.height - 36 * u), 6, line, checkCircles: true);

    // متتبع الماء (8 أكواب)
    final watR = Rect.fromLTWH(w * .04, h * .635, w * .45, h * .10);
    _box(c, watR, fill: Colors.white, border: line, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(watR.left + 8 * u, watR.top + 5 * u, watR.width - 16 * u, 18 * u), 'متتبع الماء (8 أكواب)', const Color(0xFF6B8E9B), fs: 9 * u);
    final cupW = (watR.width - 24 * u) / 8;
    for (var i = 0; i < 8; i++) {
      final cx = watR.left + 12 * u + i * cupW + cupW / 2;
      final cy = watR.top + 38 * u;
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy), width: cupW * .65, height: 15 * u), Radius.circular(3 * u)), Paint()..color = const Color(0xFF6B8E9B)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }

    // المزاج
    final moodR = Rect.fromLTWH(w * .04, h * .75, w * .45, h * .085);
    _box(c, moodR, fill: Colors.white, border: line, rad: 12 * u);
    _txt(c, 'مزاج اليوم:', Offset(moodR.right - 10 * u, moodR.top + 8 * u), fs: 9.5 * u, color: brown);
    final moods = ['ممتاز', 'جيد', 'عادي', 'متعب'];
    for (var i = 0; i < 4; i++) {
      final mx = moodR.left + 18 * u + i * (moodR.width - 36 * u) / 3;
      c.drawCircle(Offset(mx, moodR.bottom - 14 * u), 6 * u, Paint()..color = brown..style = PaintingStyle.stroke..strokeWidth = 1.1);
      _txt(c, moods[i], Offset(mx, moodR.bottom - 30 * u), fs: 7.5 * u, color: brown.withValues(alpha: .8), center: true, maxW: 36 * u);
    }

    // أسفل الصفحة: الامتنان والملاحظات
    final botR = Rect.fromLTWH(w * .04, h * .85, w * .92, h * .125);
    _box(c, botR, fill: const Color(0xFFFFFBF6), border: line, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(botR.right - 125 * u, botR.top + 6 * u, 115 * u, 18 * u), 'ملاحظات وامتنان اليوم', const Color(0xFFA67B5B), fs: 9 * u);
    _ruledLines(c, Rect.fromLTWH(botR.left, botR.top + 26 * u, botR.width, botR.height - 30 * u), 3, soft);
  }

  // ==================== 2. خطة دراستي الأسبوعية ====================
  void _paintWeeklyStudy(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const rose = Color(0xFFB56B84);
    const border = Color(0xFFE5CFD8);

    _txt(c, 'خُطّة دراستي الأسبوعية', Offset(w * .5, h * .02), fs: 20 * u, color: rose, w: FontWeight.w700, center: true, maxW: w * .8);
    _txt(c, 'خطوة صغيرة كل يوم تصنع فرقاً كبيراً غداً', Offset(w * .5, h * .068), fs: 9 * u, color: const Color(0xFF7A5B67), center: true, maxW: w * .85);

    // جدول الأيام السبعة
    final tbl = Rect.fromLTWH(w * .035, h * .105, w * .93, h * .55);
    _box(c, tbl, fill: Colors.white, border: border, rad: 12 * u);
    final cols = ['ملاحظات', 'مراجعة', 'فترة 3', 'فترة 2', 'فترة 1', 'اليوم'];
    final colColors = [Color(0xFFF3E5F5), Color(0xFFFFF3E0), Color(0xFFE8F5E9), Color(0xFFE3F2FD), Color(0xFFFCE4EC), Color(0xFFF5E6EC)];
    final cw = tbl.width / cols.length;
    final hh = 24 * u;
    for (var i = 0; i < cols.length; i++) {
      final cr = Rect.fromLTWH(tbl.left + i * cw, tbl.top, cw, hh);
      c.drawRect(cr, Paint()..color = colColors[i]);
      _txt(c, cols[i], Offset(cr.center.dx, cr.top + 5 * u), fs: 9 * u, color: const Color(0xFF4A3842), center: true, maxW: cw - 4);
      if (i > 0) c.drawLine(Offset(cr.left, tbl.top), Offset(cr.left, tbl.bottom), Paint()..color = border..strokeWidth = .9);
    }
    final days = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
    final rh = (tbl.height - hh) / days.length;
    for (var r = 0; r < days.length; r++) {
      final y = tbl.top + hh + r * rh;
      c.drawLine(Offset(tbl.left, y), Offset(tbl.right, y), Paint()..color = border..strokeWidth = .9);
      _txt(c, days[r], Offset(tbl.right - cw / 2, y + rh * .28), fs: 9.5 * u, color: rose, w: FontWeight.w700, center: true, maxW: cw - 4);
    }

    // أسفل الجدول: 3 بطاقات (أهداف الأسبوع، تقييم الأسبوع، ملاحظات)
    final gR = Rect.fromLTWH(w * .52, h * .675, w * .445, h * .29);
    _box(c, gR, fill: Colors.white, border: border, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(gR.left + 8 * u, gR.top + 6 * u, gR.width - 16 * u, 20 * u), 'أهداف هذا الأسبوع', const Color(0xFF9C7BB5), fs: 9.5 * u);
    _ruledLines(c, Rect.fromLTWH(gR.left, gR.top + 30 * u, gR.width, gR.height - 36 * u), 5, border, checkBoxes: true);

    final evR = Rect.fromLTWH(w * .035, h * .675, w * .46, h * .17);
    _box(c, evR, fill: Colors.white, border: border, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(evR.left + 8 * u, evR.top + 6 * u, evR.width - 16 * u, 20 * u), 'تقييم الأسبوع', const Color(0xFF6B8FB5), fs: 9.5 * u);
    final metrics = ['الالتزام بالخطة', 'الفهم والاستيعاب', 'حل الأسئلة'];
    for (var i = 0; i < 3; i++) {
      final y = evR.top + 34 * u + i * 22 * u;
      _txt(c, metrics[i], Offset(evR.right - 8 * u, y), fs: 8.5 * u, color: const Color(0xFF4A3842), maxW: 90 * u);
      for (var st = 0; st < 5; st++) {
        c.drawCircle(Offset(evR.left + 14 * u + st * 14 * u, y + 6 * u), 4.5 * u, Paint()..color = const Color(0xFFD9A64A)..style = PaintingStyle.stroke..strokeWidth = 1.1);
      }
    }

    final rewR = Rect.fromLTWH(w * .035, h * .86, w * .46, h * .105);
    _box(c, rewR, fill: const Color(0xFFFFF9E6), border: const Color(0xFFE8D59E), rad: 12 * u);
    _txt(c, 'مكافأتي إذا التزمت:', Offset(rewR.right - 10 * u, rewR.top + 7 * u), fs: 9.5 * u, color: const Color(0xFF8C6B28));
  }

  // ==================== 3. مخطط الطالب وبومودورو ====================
  void _paintStudentPomo(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const navy = Color(0xFF395B8E);
    const sky = Color(0xFFC5D7F2);

    _txt(c, 'مخطط الطالب والتركيز', Offset(w * .5, h * .02), fs: 20 * u, color: navy, w: FontWeight.w700, center: true, maxW: w * .8);
    _txt(c, 'التاريخ: ____ / ____ / ______', Offset(w * .5, h * .068), fs: 9.5 * u, color: navy.withValues(alpha: .75), center: true, maxW: w * .7);

    // جدول المذاكرة (يمين)
    final sR = Rect.fromLTWH(w * .52, h * .11, w * .445, h * .54);
    _box(c, sR, fill: Colors.white, border: sky, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(sR.left + 8 * u, sR.top + 6 * u, sR.width - 16 * u, 20 * u), 'جدول جلسات الدراسة', navy, fs: 10 * u);
    _ruledLines(c, Rect.fromLTWH(sR.left, sR.top + 30 * u, sR.width, sR.height - 36 * u), 10, sky, checkCircles: true);

    // مهام اليوم (يسار علوي)
    final tR = Rect.fromLTWH(w * .035, h * .11, w * .46, h * .28);
    _box(c, tR, fill: Colors.white, border: sky, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(tR.left + 8 * u, tR.top + 6 * u, tR.width - 16 * u, 20 * u), 'مهام اليوم الدراسية', const Color(0xFF5A7FB5), fs: 10 * u);
    _ruledLines(c, Rect.fromLTWH(tR.left, tR.top + 30 * u, tR.width, tR.height - 36 * u), 6, sky, checkBoxes: true);

    // العد التنازلي للامتحانات
    final exR = Rect.fromLTWH(w * .035, h * .405, w * .46, h * .245);
    _box(c, exR, fill: Colors.white, border: sky, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(exR.left + 8 * u, exR.top + 6 * u, exR.width - 16 * u, 20 * u), 'العد التنازلي للامتحانات', const Color(0xFF6B65A8), fs: 9.5 * u);
    _ruledLines(c, Rect.fromLTWH(exR.left, exR.top + 30 * u, exR.width, exR.height - 36 * u), 4, sky, numbered: true);

    // متتبع بومودورو (كامل العرض)
    final pmR = Rect.fromLTWH(w * .035, h * .67, w * .93, h * .145);
    _box(c, pmR, fill: const Color(0xFFF0F5FF), border: sky, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(pmR.right - 170 * u, pmR.top + 6 * u, 160 * u, 20 * u), 'متتبع بومودورو (25 د تركيز)', navy, fs: 9.5 * u);
    for (var row = 0; row < 2; row++) {
      for (var col = 0; col < 2; col++) {
        final idx = row * 2 + col + 1;
        final gx = pmR.left + 12 * u + col * (pmR.width * .48);
        final gy = pmR.top + 36 * u + row * 26 * u;
        _txt(c, 'جولة $idx', Offset(gx + 155 * u, gy - 4 * u), fs: 9 * u, color: navy, maxW: 50 * u);
        for (var k = 0; k < 5; k++) {
          c.drawCircle(Offset(gx + 12 * u + k * 22 * u, gy + 5 * u), 7.5 * u, Paint()..color = navy..style = PaintingStyle.stroke..strokeWidth = 1.3);
        }
      }
    }

    // ماذا تعلمت اليوم
    final lrnR = Rect.fromLTWH(w * .035, h * .835, w * .93, h * .135);
    _box(c, lrnR, fill: Colors.white, border: sky, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(lrnR.right - 135 * u, lrnR.top + 6 * u, 125 * u, 18 * u), 'خلاصة ما تعلمته اليوم', const Color(0xFF4F7B6C), fs: 9 * u);
    _ruledLines(c, Rect.fromLTWH(lrnR.left, lrnR.top + 26 * u, lrnR.width, lrnR.height - 30 * u), 3, sky);
  }

  // ==================== 4. المخطط الشهري الشامل ====================
  void _paintMonthlyPlan(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const plum = Color(0xFF7B5EA7);
    const lav = Color(0xFFDFD2F2);

    _txt(c, 'مُخطّط شهري', Offset(w * .5, h * .018), fs: 22 * u, color: plum, w: FontWeight.w700, center: true, maxW: w * .7);
    _txt(c, 'الشهر: ____________   •   التركيز الرئيسي: ____________________', Offset(w * .5, h * .068), fs: 9 * u, color: plum.withValues(alpha: .8), center: true, maxW: w * .92);

    // شبكة التقويم (5 صفوف × 7 أيام)
    final cal = Rect.fromLTWH(w * .035, h * .105, w * .93, h * .46);
    _box(c, cal, fill: Colors.white, border: lav, rad: 12 * u);
    final wdays = ['السبت', 'الجمعة', 'الخميس', 'الأربعاء', 'الثلاثاء', 'الاثنين', 'الأحد'];
    final cw = cal.width / 7, hh = 22 * u;
    for (var i = 0; i < 7; i++) {
      final hr = Rect.fromLTWH(cal.left + i * cw, cal.top, cw, hh);
      c.drawRect(hr, Paint()..color = const Color(0xFFEEE6FA));
      _txt(c, wdays[i], Offset(hr.center.dx, hr.top + 4 * u), fs: 8.5 * u, color: plum, w: FontWeight.w700, center: true, maxW: cw - 2);
      if (i > 0) c.drawLine(Offset(hr.left, cal.top), Offset(hr.left, cal.bottom), Paint()..color = lav..strokeWidth = .9);
    }
    final rh = (cal.height - hh) / 5;
    for (var r = 0; r < 5; r++) {
      final y = cal.top + hh + r * rh;
      c.drawLine(Offset(cal.left, y), Offset(cal.right, y), Paint()..color = lav..strokeWidth = .9);
      for (var col = 0; col < 7; col++) {
        c.drawRect(Rect.fromLTWH(cal.left + (col + 1) * cw - 14 * u, y + 2 * u, 12 * u, 11 * u), Paint()..color = const Color(0xFFF5F0FC));
      }
    }

    // أهداف كبيرة + تواريخ مهمة
    final gR = Rect.fromLTWH(w * .52, h * .585, w * .445, h * .19);
    _box(c, gR, fill: Colors.white, border: lav, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(gR.left + 8 * u, gR.top + 6 * u, gR.width - 16 * u, 19 * u), 'أهداف كبيرة لهذا الشهر', plum, fs: 9.5 * u);
    _ruledLines(c, Rect.fromLTWH(gR.left, gR.top + 28 * u, gR.width, gR.height - 32 * u), 4, lav, checkBoxes: true);

    final dR = Rect.fromLTWH(w * .035, h * .585, w * .46, h * .19);
    _box(c, dR, fill: Colors.white, border: lav, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(dR.left + 8 * u, dR.top + 6 * u, dR.width - 16 * u, 19 * u), 'تواريخ ومواعيد مهمة', const Color(0xFFB56B84), fs: 9.5 * u);
    _ruledLines(c, Rect.fromLTWH(dR.left, dR.top + 28 * u, dR.width, dR.height - 32 * u), 4, lav, checkCircles: true);

    // الامتنان والتأمل الشهري
    final refR = Rect.fromLTWH(w * .035, h * .795, w * .93, h * .175);
    _box(c, refR, fill: const Color(0xFFFDFBFF), border: lav, rad: 12 * u);
    _headerPill(c, Rect.fromLTWH(refR.right - 145 * u, refR.top + 6 * u, 135 * u, 19 * u), 'تأمل وامتنان نهاية الشهر', const Color(0xFF6B8FB5), fs: 9 * u);
    _ruledLines(c, Rect.fromLTWH(refR.left, refR.top + 28 * u, refR.width, refR.height - 32 * u), 4, lav);
  }

  // ==================== 5. دفتر المفردات والفوائد ====================
  void _paintVocabNotes(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const ink = Color(0xFF465945);
    const rule = Color(0xFFE3DEC8);
    final pills = [
      const Color(0xFFE5D9F2), const Color(0xFFFCE2D6), const Color(0xFFDCEBD8),
      const Color(0xFFD8EBF2), const Color(0xFFF9D8E2), const Color(0xFFFFF0C9),
      const Color(0xFFDCE8DF), const Color(0xFFEADCF2),
    ];

    _txt(c, 'دفتر المفردات والفوائد', Offset(w * .5, h * .022), fs: 20 * u, color: ink, w: FontWeight.w700, center: true, maxW: w * .8);
    _txt(c, 'الموضوع / الكتاب: ________________________', Offset(w * .5, h * .072), fs: 9.5 * u, color: ink.withValues(alpha: .75), center: true, maxW: w * .85);

    // رؤوس الأعمدة
    final topY = h * .115;
    _headerPill(c, Rect.fromLTWH(w * .66, topY, w * .30, 22 * u), 'المصطلح / الكلمة', ink, fs: 10 * u);
    _headerPill(c, Rect.fromLTWH(w * .04, topY, w * .60, 22 * u), 'المعنى والشرح والمثال', const Color(0xFF7B8E76), fs: 10 * u);

    final startY = topY + 30 * u;
    final rowH = (h * .95 - startY) / 8;
    // خط عمودي فاصل
    c.drawLine(Offset(w * .65, startY), Offset(w * .65, h * .95), Paint()..color = rule..strokeWidth = 1.3);

    for (var i = 0; i < 8; i++) {
      final y = startY + i * rowH;
      // بطاقة باستيل ملونة للمصطلح
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(w * .67, y + 6 * u, w * .28, rowH * .44), Radius.circular(8 * u)), Paint()..color = pills[i % pills.length]);
      // أسطر الشرح والمثال
      c.drawLine(Offset(w * .05, y + rowH * .45), Offset(w * .63, y + rowH * .45), Paint()..color = rule..strokeWidth = .9);
      c.drawLine(Offset(w * .05, y + rowH * .82), Offset(w * .63, y + rowH * .82), Paint()..color = rule..strokeWidth = .9);
      c.drawLine(Offset(w * .04, y + rowH), Offset(w * .96, y + rowH), Paint()..color = const Color(0xFFD5CEB6)..strokeWidth = 1.1);
    }
  }

  // ==================== 6. مصفوفة الأولويات (أيزنهاور) ====================
  void _paintEisenhower(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const warm = Color(0xFF9C5E35);

    _txt(c, 'مصفوفة الأولويات', Offset(w * .5, h * .022), fs: 21 * u, color: warm, w: FontWeight.w700, center: true, maxW: w * .8);
    _txt(c, 'رتّب مهامك بذكاء حسب الأهمية والاستعجال', Offset(w * .5, h * .07), fs: 9.5 * u, color: warm.withValues(alpha: .75), center: true, maxW: w * .85);

    final qW = w * .445, qH = h * .37;
    final quads = [
      (Rect.fromLTWH(w * .52, h * .115, qW, qH), '1. عاجل ومُهم (نفّذ الآن)', const Color(0xFFD96B6B), const Color(0xFFFFF5F5)),
      (Rect.fromLTWH(w * .035, h * .115, qW, qH), '2. مُهم غير عاجل (خطّط له)', const Color(0xFF4E8C6F), const Color(0xFFF4FBF7)),
      (Rect.fromLTWH(w * .52, h * .505, qW, qH), '3. عاجل غير مُهم (فوّض/اختصر)', const Color(0xFFD49B4B), const Color(0xFFFFFBF2)),
      (Rect.fromLTWH(w * .035, h * .505, qW, qH), '4. لاحقاً / تخلّص منه', const Color(0xFF6B809C), const Color(0xFFF5F8FC)),
    ];
    for (final q in quads) {
      _box(c, q.$1, fill: q.$4, border: q.$3.withValues(alpha: .45), rad: 14 * u);
      _headerPill(c, Rect.fromLTWH(q.$1.left + 8 * u, q.$1.top + 8 * u, q.$1.width - 16 * u, 22 * u), q.$2, q.$3, fs: 9 * u);
      _ruledLines(c, Rect.fromLTWH(q.$1.left, q.$1.top + 34 * u, q.$1.width, q.$1.height - 40 * u), 7, q.$3.withValues(alpha: .35), checkBoxes: true);
    }

    final foot = Rect.fromLTWH(w * .035, h * .895, w * .93, h * .075);
    _box(c, foot, fill: Colors.white, border: const Color(0xFFE3D3C1), rad: 10 * u);
    _txt(c, 'أهم خطوة أبدأ بها الآن:', Offset(foot.right - 10 * u, foot.top + 10 * u), fs: 9.5 * u, color: warm);
  }

  // ==================== 7. متتبع العادات (30 يوماً) ====================
  void _paintHabit30(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const teal = Color(0xFF3E786A);
    const mint = Color(0xFFCAE0D9);

    _txt(c, 'متتبع العادات — 30 يوماً', Offset(w * .5, h * .02), fs: 20 * u, color: teal, w: FontWeight.w700, center: true, maxW: w * .85);
    _txt(c, 'الشهر: ____________   •   الاستمرارية تصنع الفرق', Offset(w * .5, h * .068), fs: 9.5 * u, color: teal.withValues(alpha: .8), center: true, maxW: w * .85);

    // 8 بطاقات عادات، كل بطاقة تحتوي 30 دائرة (صفين × 15)
    final startY = h * .105;
    final cardH = (h * .85 - startY) / 8;
    final accents = [
      const Color(0xFF4E8C7A), const Color(0xFF5A7FB5), const Color(0xFFB56B84), const Color(0xFFC28B4B),
      const Color(0xFF7B63A6), const Color(0xFF5D8C5A), const Color(0xFFC26B5B), const Color(0xFF4E7D8C),
    ];
    for (var i = 0; i < 8; i++) {
      final r = Rect.fromLTWH(w * .035, startY + i * cardH, w * .93, cardH - 6 * u);
      _box(c, r, fill: Colors.white, border: mint, rad: 10 * u);
      final ac = accents[i];
      // اسم العادة يميناً
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(r.right - 98 * u, r.top + 5 * u, 92 * u, r.height - 10 * u), Radius.circular(8 * u)), Paint()..color = ac.withValues(alpha: .14));
      _txt(c, 'عادة ${i + 1}:', Offset(r.right - 12 * u, r.top + 8 * u), fs: 8.8 * u, color: ac, maxW: 80 * u);
      // 30 دائرة في صفّين × 15
      final gridW = r.width - 112 * u;
      final stepX = gridW / 15;
      for (var row = 0; row < 2; row++) {
        for (var col = 0; col < 15; col++) {
          final cx = r.left + 8 * u + col * stepX + stepX / 2;
          final cy = r.top + (row == 0 ? r.height * .32 : r.height * .70);
          c.drawCircle(Offset(cx, cy), math.min(5.2 * u, stepX * .38), Paint()..color = ac.withValues(alpha: .75)..style = PaintingStyle.stroke..strokeWidth = 1.1);
        }
      }
    }

    final rew = Rect.fromLTWH(w * .035, h * .87, w * .93, h * .10);
    _box(c, rew, fill: const Color(0xFFF0F9F5), border: mint, rad: 12 * u);
    _txt(c, 'مكافأتي عند إتمام الشهر:', Offset(rew.right - 12 * u, rew.top + 8 * u), fs: 10 * u, color: teal);
  }

  // ==================== 8. قلب القرآن (114 سورة) ====================
  static const _surahs = [
    'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس',
    'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه',
    'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم',
    'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر',
    'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات', 'ق',
    'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة',
    'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج',
    'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس',
    'التكوير', 'الانفطار', 'المطففين', 'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد',
    'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة', 'الزلزلة', 'العاديات',
    'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر',
    'المسد', 'الإخلاص', 'الفلق', 'الناس',
  ];

  void _paintQuranHeart(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const crimson = Color(0xFF9C3D54);
    const pinkBorder = Color(0xFFE6BAC5);

    _txt(c, 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', Offset(w * .5, h * .014), fs: 13 * u, color: const Color(0xFF5A333E), w: FontWeight.w700, center: true, maxW: w * .85);
    _txt(c, 'اجعل قلبك عامراً بالقرآن ♥', Offset(w * .5, h * .048), fs: 18 * u, color: crimson, w: FontWeight.w700, center: true, maxW: w * .85);
    _txt(c, 'كل سورة نور وكل آية حياة — لوّن بقلم التمييز كل سورة تحفظها', Offset(w * .5, h * .092), fs: 8.5 * u, color: const Color(0xFF7B4C58), center: true, maxW: w * .92);

    // رسم مخطط القلب الخارجي الخفيف كخلفية جمالية
    final cx = w * .5, cy = h * .49, rx = w * .45, ry = h * .34;
    final heart = Path()
      ..moveTo(cx, cy + ry * .92)
      ..cubicTo(cx - rx * 1.15, cy + ry * .25, cx - rx * 1.05, cy - ry * .82, cx, cy - ry * .32)
      ..cubicTo(cx + rx * 1.05, cy - ry * .82, cx + rx * 1.15, cy + ry * .25, cx, cy + ry * .92)
      ..close();
    c.drawPath(heart, Paint()..color = const Color(0xFFFFEEF2));
    c.drawPath(heart, Paint()..color = crimson.withValues(alpha: .55)..style = PaintingStyle.stroke..strokeWidth = 2.0 * u);

    // توزيع الـ 114 سورة داخل شكل القلب (صفوف متدرجة العرض تصنع شكل قلب متناسق!)
    const rowCounts = [4, 6, 8, 9, 10, 10, 10, 10, 9, 9, 8, 7, 6, 5, 3]; // مجموع = 114 بالضبط!
    var idx = 0;
    final topY = h * .145;
    final totalH = h * .67;
    final rh = totalH / rowCounts.length;
    final boxStroke = Paint()..color = crimson.withValues(alpha: .65)..style = PaintingStyle.stroke..strokeWidth = .9;
    final boxFill = Paint()..color = Colors.white.withValues(alpha: .92);

    for (var r = 0; r < rowCounts.length; r++) {
      final cnt = rowCounts[r];
      final cellW = math.min((w * .90) / 10, (w * .90) / cnt);
      final rowW = cnt * cellW;
      final startX = (w - rowW) / 2;
      final y = topY + r * rh;
      for (var k = 0; k < cnt && idx < 114; k++) {
        // ترتيب من اليمين لليسار
        final x = startX + (cnt - 1 - k) * cellW;
        final rect = Rect.fromLTWH(x + 1.2 * u, y + 1.2 * u, cellW - 2.4 * u, rh - 2.4 * u);
        final rr = RRect.fromRectAndRadius(rect, Radius.circular(5 * u));
        c.drawRRect(rr, boxFill);
        c.drawRRect(rr, boxStroke);
        _txt(c, '${idx + 1}', Offset(rect.center.dx, rect.top + 1.5 * u), fs: 6.2 * u, color: crimson.withValues(alpha: .85), center: true, maxW: rect.width - 2);
        _txt(c, _surahs[idx], Offset(rect.center.dx, rect.top + rect.height * .42), fs: 6.6 * u, color: const Color(0xFF3E262C), w: FontWeight.w600, center: true, maxW: rect.width - 2);
        idx++;
      }
    }

    // أسفل القلب: شعار تحفيزي + بطاقات نصائح
    final quoteR = Rect.fromLTWH(w * .14, h * .835, w * .72, 24 * u);
    _headerPill(c, quoteR, 'لا تقل سأبدأ غداً .. بل قُل: سأبدأ الآن!', crimson, fs: 9.5 * u);

    final tips = ['اختر وقتاً ثابتاً\nبعد الفجر', 'احفظ بتدبّر\nوفهم للآيات', 'المراجعة اليومية\nسرّ الثبات', 'ادعُ الله دائماً\nوتوكل عليه'];
    final tw = (w * .92 - 18 * u) / 4;
    for (var i = 0; i < 4; i++) {
      final tr = Rect.fromLTWH(w * .04 + i * (tw + 6 * u), h * .888, tw, h * .085);
      _box(c, tr, fill: Colors.white, border: pinkBorder, rad: 8 * u);
      _txt(c, tips[3 - i], Offset(tr.center.dx, tr.top + 8 * u), fs: 7.4 * u, color: const Color(0xFF5A333E), center: true, maxW: tw - 6);
    }
  }

  // ==================== 9. رحلة الأجزاء الثلاثين ====================
  void _paintQuran30Juz(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const emerald = Color(0xFF1F6353);
    const sage = Color(0xFFC2DDD4);

    _txt(c, 'رحلة الختمة — 30 جزءاً', Offset(w * .5, h * .02), fs: 20 * u, color: emerald, w: FontWeight.w700, center: true, maxW: w * .85);
    _txt(c, 'لوّن النقاط الثلاث لكل جزء:  ○ حفظ   ○ تثبيت   ○ مراجعة', Offset(w * .5, h * .068), fs: 9 * u, color: emerald.withValues(alpha: .8), center: true, maxW: w * .92);

    // 6 صفوف × 5 أعمدة (بمسار متعرّج من الجزء 1 إلى 30)
    final startY = h * .11, gridH = h * .72;
    const rows = 6, cols = 5;
    final cw = (w * .92) / cols, rh = gridH / rows;

    // رسم خط المسار المتعرّج الخفيف خلف البطاقات
    final path = Path();
    for (var i = 0; i < 30; i++) {
      final r = i ~/ cols;
      final cInRow = r.isEven ? (cols - 1 - (i % cols)) : (i % cols);
      final pt = Offset(w * .04 + cInRow * cw + cw / 2, startY + r * rh + rh / 2);
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    c.drawPath(path, Paint()..color = sage..style = PaintingStyle.stroke..strokeWidth = 3 * u);

    for (var i = 0; i < 30; i++) {
      final r = i ~/ cols;
      final cInRow = r.isEven ? (cols - 1 - (i % cols)) : (i % cols);
      final rect = Rect.fromLTWH(w * .04 + cInRow * cw + 4 * u, startY + r * rh + 4 * u, cw - 8 * u, rh - 8 * u);
      _box(c, rect, fill: Colors.white, border: emerald.withValues(alpha: .45), rad: 10 * u);
      _txt(c, 'الجزء ${i + 1}', Offset(rect.center.dx, rect.top + 6 * u), fs: 9.2 * u, color: emerald, w: FontWeight.w700, center: true, maxW: rect.width - 4);
      // 3 دوائر (حفظ، تثبيت، مراجعة)
      final labels = ['م', 'ت', 'ح'];
      for (var k = 0; k < 3; k++) {
        final cx = rect.left + rect.width * (.22 + k * .28);
        final cy = rect.bottom - 13 * u;
        c.drawCircle(Offset(cx, cy), 6.2 * u, Paint()..color = emerald.withValues(alpha: .7)..style = PaintingStyle.stroke..strokeWidth = 1.1);
        _txt(c, labels[k], Offset(cx, cy - 5.5 * u), fs: 6.5 * u, color: emerald.withValues(alpha: .75), center: true, maxW: 12 * u);
      }
    }

    // أسفل الصفحة: وردي اليومي وتاريخ البدء والهدف
    final bot = Rect.fromLTWH(w * .04, h * .85, w * .92, h * .12);
    _box(c, bot, fill: const Color(0xFFEFF8F4), border: sage, rad: 12 * u);
    _txt(c, 'تاريخ البدء: ____/____     •     الورد اليومي: __________     •     هدف الختمة: ____/____', Offset(bot.center.dx, bot.top + 12 * u), fs: 8.8 * u, color: emerald, center: true, maxW: bot.width - 12);
    _txt(c, '«خَيرُكُم مَن تَعَلَّمَ القُرآنَ وَعَلَّمَهُ»', Offset(bot.center.dx, bot.bottom - 26 * u), fs: 10.5 * u, color: emerald, w: FontWeight.w700, center: true, maxW: bot.width - 12);
  }

  // ==================== 10. قالب الحصون الخمسة لحفظ القرآن ====================
  void _paintQuranFortresses(Canvas c, Size s) {
    final w = s.width, h = s.height, u = w / 400;
    const gold = Color(0xFF8C662B);
    const creamBorder = Color(0xFFE5D4B3);

    _txt(c, 'جدول الحصون الخمسة لحفظ القرآن', Offset(w * .5, h * .018), fs: 18 * u, color: gold, w: FontWeight.w700, center: true, maxW: w * .9);
    _txt(c, 'الأسبوع / التاريخ: _______________   •   السورة الحالية: _______________', Offset(w * .5, h * .065), fs: 8.8 * u, color: gold.withValues(alpha: .8), center: true, maxW: w * .92);

    final fortresses = [
      ('الحصن 1: القراءة المستمرة والاستماع', 'ورد التلاوة (جزآن) + استماع السورة', const Color(0xFF4F7B6C)),
      ('الحصن 2: التحضير (أسبوعي · ليلي · قبلي)', 'قراءة الصفحة المراد حفظها قبل النوم وقبل الحفظ', const Color(0xFF5A78A0)),
      ('الحصن 3: الحفظ الجديد', 'مقدار اليوم: ________   •   الربط بالماضي', const Color(0xFF9C5E35)),
      ('الحصن 4: مراجعة القريب', 'مراجعة آخر 20 صفحة محفوظة يومياً', const Color(0xFF8A5D8F)),
      ('الحصن 5: مراجعة البعيد', 'مراجعة المحفوظ القديم حسب جدول التثبيت', const Color(0xFFB55D6E)),
    ];

    final startY = h * .105;
    final boxH = (h * .85 - startY) / 5;
    final days = ['ج', 'خ', 'ر', 'ث', 'ن', 'ح', 'س'];
    for (var i = 0; i < 5; i++) {
      final f = fortresses[i];
      final r = Rect.fromLTWH(w * .035, startY + i * boxH, w * .93, boxH - 8 * u);
      _box(c, r, fill: Colors.white, border: f.$3.withValues(alpha: .4), rad: 12 * u);
      _headerPill(c, Rect.fromLTWH(r.right - 220 * u, r.top + 6 * u, 212 * u, 20 * u), f.$1, f.$3, fs: 8.8 * u);
      _txt(c, f.$2, Offset(r.right - 12 * u, r.top + 31 * u), fs: 8 * u, color: const Color(0xFF5A4E42), maxW: r.width - 24 * u);
      // 7 دوائر لأيام الأسبوع يسار العنوان
      for (var d = 0; d < 7; d++) {
        final cx = r.left + 14 * u + d * 20 * u;
        final cy = r.top + 16 * u;
        c.drawCircle(Offset(cx, cy), 7.5 * u, Paint()..color = f.$3..style = PaintingStyle.stroke..strokeWidth = 1.1);
        _txt(c, days[d], Offset(cx, cy - 6 * u), fs: 7 * u, color: f.$3, center: true, maxW: 14 * u);
      }
      // سطر ملاحظات الحصن
      c.drawLine(Offset(r.left + 12 * u, r.bottom - 12 * u), Offset(r.right - 12 * u, r.bottom - 12 * u), Paint()..color = creamBorder..strokeWidth = .9);
    }

    final foot = Rect.fromLTWH(w * .035, h * .865, w * .93, h * .105);
    _box(c, foot, fill: const Color(0xFFFFF8E8), border: creamBorder, rad: 12 * u);
    _txt(c, 'الآيات المتشابهة وملاحظات التثبيت:', Offset(foot.right - 12 * u, foot.top + 8 * u), fs: 9.5 * u, color: gold);
    _ruledLines(c, Rect.fromLTWH(foot.left, foot.top + 24 * u, foot.width, foot.height - 28 * u), 2, creamBorder);
  }
}
