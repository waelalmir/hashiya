import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'annotations.dart';
import 'data.dart';
import 'glass.dart';
import 'model.dart';
import 'page_overlay.dart';
import 'pin_sheet.dart';
import 'sticker_sheet.dart';
import 'store.dart';
import 'interactive_templates.dart';
import 'templates.dart';
import 'theme.dart';

/// نافذة إنشاء لوحة جديدة: خيار "صفحة بيضاء" أو "قوالب (10 قوالب)".
Future<BoardMeta?> showCreateBoardSheet(BuildContext context, {String? bookId, int? page}) {
  return showModalBottomSheet<BoardMeta>(
    context: context,
    backgroundColor: HC.green,
    isScrollControlled: true,
    builder: (c) => _CreateBoardSheet(bookId: bookId, page: page),
  );
}

class _CreateBoardSheet extends StatefulWidget {
  const _CreateBoardSheet({this.bookId, this.page});
  final String? bookId;
  final int? page;
  @override
  State<_CreateBoardSheet> createState() => _CreateBoardSheetState();
}

class _CreateBoardSheetState extends State<_CreateBoardSheet> {
  int tab = 0; // 0 = صفحة بيضاء، 1 = قوالب (10 قوالب)
  final titleC = TextEditingController();

  @override
  void dispose() {
    titleC.dispose();
    super.dispose();
  }

  void _pickInteractive(InteractiveTemplateInfo tpl) {
    final name = titleC.text.trim().isEmpty ? tpl.name : titleC.text.trim();
    final meta = BoardMeta(
      id: newId(),
      title: name,
      templateId: tpl.id,
      updatedAt: DateTime.now().millisecondsSinceEpoch,
      bookId: widget.bookId,
      page: widget.page,
    );
    AppData.upsertBoard(meta);
    Navigator.pop(context, meta);
  }

  void _pick(BoardTemplate tpl) {
    final name = titleC.text.trim().isEmpty ? tpl.name : titleC.text.trim();
    final meta = BoardMeta(
      id: newId(),
      title: name,
      templateId: tpl.id,
      updatedAt: DateTime.now().millisecondsSinceEpoch,
      bookId: widget.bookId,
      page: widget.page,
    );
    AppData.upsertBoard(meta);
    Navigator.pop(context, meta);
  }

  Widget _previewCard(BoardTemplate tpl) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => _pick(tpl),
        child: Container(
          decoration: BoxDecoration(
            color: HC.cream.withValues(alpha: .10),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: HC.cream.withValues(alpha: .22)),
          ),
          padding: const EdgeInsets.all(8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AspectRatio(
                  aspectRatio: 0.72,
                  child: CustomPaint(painter: TemplatePainter(tpl.id)),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(tpl.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
            Text(tpl.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, color: HC.cream.withValues(alpha: .72))),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final plannerTpls = kRichTemplates.where((t) => t.category == 'planner').toList();
    final quranTpls = kRichTemplates.where((t) => t.category == 'quran').toList();
    return DraggableScrollableSheet(
      initialChildSize: .82,
      minChildSize: .5,
      maxChildSize: .95,
      expand: false,
      builder: (c, sc) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: HC.cream.withValues(alpha: .35), borderRadius: BorderRadius.circular(4)))),
          const SizedBox(height: 12),
          const Text('إنشاء لوحة أو قالب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          TextField(
            controller: titleC,
            decoration: const InputDecoration(labelText: 'عنوان اللوحة (اختياري)', hintText: 'مثلاً: ملخص الفصل الأول أو خطة الأسبوع'),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, icon: Icon(Icons.draw_rounded, size: 16), label: Text('بيضاء')),
                ButtonSegment(value: 1, icon: Icon(Icons.dashboard_customize_rounded, size: 16), label: Text('قوالب (10)')),
                ButtonSegment(value: 2, icon: Icon(Icons.touch_app_rounded, size: 16), label: Text('تفاعلي (2)')),
              ],
              selected: {tab},
              onSelectionChanged: (v) => setState(() => tab = v.first),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: tab == 2
                ? ListView(controller: sc, children: [
                    for (final it in kInteractiveTemplates)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _pickInteractive(it),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: it.bg,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: it.accent.withValues(alpha: .45), width: 1.5),
                            ),
                            child: Row(children: [
                              CircleAvatar(backgroundColor: it.accent, child: Icon(it.icon, color: Colors.white)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(it.name, style: TextStyle(color: it.accent, fontSize: 15.5, fontWeight: FontWeight.w700)),
                                  const SizedBox(height: 3),
                                  Text(it.subtitle, style: TextStyle(color: it.accent.withValues(alpha: .8), fontSize: 12)),
                                ]),
                              ),
                              Icon(Icons.chevron_left_rounded, color: it.accent),
                            ]),
                          ),
                        ),
                      ),
                  ])
                : (tab == 0
                ? GridView.builder(
                    controller: sc,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .72, crossAxisSpacing: 10, mainAxisSpacing: 10),
                    itemCount: kBlankTemplates.length,
                    itemBuilder: (_, i) => _previewCard(kBlankTemplates[i]),
                  )
                : ListView(controller: sc, children: [
                    const Padding(
                      padding: EdgeInsets.only(bottom: 8),
                      child: Text('قوالب التنظيم والدراسة (7 قوالب)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .68, crossAxisSpacing: 10, mainAxisSpacing: 10),
                      itemCount: plannerTpls.length,
                      itemBuilder: (_, i) => _previewCard(plannerTpls[i]),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 16, bottom: 8),
                      child: Text('قوالب حفظ القرآن الكريم (3 قوالب مبتكرة)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .68, crossAxisSpacing: 10, mainAxisSpacing: 10),
                      itemCount: quranTpls.length,
                      itemBuilder: (_, i) => _previewCard(quranTpls[i]),
                    ),
                  ])),
          ),
        ]),
      ),
    );
  }
}

/// صفحة الدفتر والقوالب (للوصول السريع لكل الصفحات البيضاء والقوالب المحفوظة).
class BoardsHubPage extends StatelessWidget {
  const BoardsHubPage({super.key});

  Future<void> _create(BuildContext context) async {
    final meta = await showCreateBoardSheet(context);
    if (meta == null || !context.mounted) return;
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => isInteractiveTemplate(meta.templateId) ? InteractiveTemplatePage(meta: meta) : WhiteboardPage(meta: meta)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: HC.deep,
        appBar: AppBar(
          backgroundColor: HC.deep,
          title: const Text('مساحة الإبداع'),
          actions: [
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: FilledButton.icon(onPressed: () => _create(context), icon: const Icon(Icons.add_rounded, size: 18), label: const Text('إنشاء')),
            ),
          ],
        ),
        body: SafeArea(
          child: ValueListenableBuilder<List<BoardMeta>>(
            valueListenable: AppData.boards,
            builder: (context, list, _) {
              if (list.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: GlassCard(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.draw_rounded, size: 48, color: HC.cream.withValues(alpha: .8)),
                        const SizedBox(height: 12),
                        const Text('ابدأ بأول صفحة بيضاء أو قالب تنظيم', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        Text('10 قوالب عربية جاهزة (تنظيم، دراسة، وحفظ القرآن) + رسم وكتابة وستيكرات.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .7))),
                        const SizedBox(height: 16),
                        FilledButton.icon(onPressed: () => _create(context), icon: const Icon(Icons.add_rounded), label: const Text('إنشاء جديد')),
                      ]),
                    ),
                  ),
                );
              }
              return GridView.builder(
                padding: const EdgeInsets.all(14),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: isCompact(context) ? 2 : 4,
                  childAspectRatio: .72,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: list.length,
                itemBuilder: (c, i) {
                  final b = list[i];
                  final tpl = findTemplate(b.templateId);
                  return GlassCard(
                    padding: const EdgeInsets.all(8),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => isInteractiveTemplate(b.templateId) ? InteractiveTemplatePage(meta: b) : WhiteboardPage(meta: b))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: isInteractiveTemplate(b.templateId)
                                ? Container(
                                    color: b.templateId == 'inter_daily' ? const Color(0xFFFFF8F0) : const Color(0xFFFAF6FF),
                                    child: Center(
                                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                                        Icon(b.templateId == 'inter_daily' ? Icons.wb_sunny_rounded : Icons.checklist_rtl_rounded, size: 38, color: b.templateId == 'inter_daily' ? const Color(0xFF7A563E) : const Color(0xFF7B5EA7)),
                                        const SizedBox(height: 6),
                                        const Text('قالب تفاعلي ★', style: TextStyle(color: Color(0xFF4A3A2E), fontWeight: FontWeight.w700, fontSize: 12)),
                                      ]),
                                    ),
                                  )
                                : CustomPaint(painter: TemplatePainter(b.templateId)),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700)),
                              Text(b.bookId != null ? 'مضمّنة بكتاب · ص ${b.page ?? ''}' : tpl.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: HC.cream.withValues(alpha: .65))),
                            ]),
                          ),
                          IconButton(
                            iconSize: 18,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                            onPressed: () => AppData.removeBoard(b.id),
                            icon: const Icon(Icons.delete_outline_rounded),
                          ),
                        ]),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      );
}

/// لوحة الرسم والكتابة والستيكرات والقوالب التفاعلية بكامل خيارات القارئ والاختصارات الذكية.
class WhiteboardPage extends StatefulWidget {
  const WhiteboardPage({super.key, required this.meta, this.attachMode = false});
  final BoardMeta meta;
  final bool attachMode;
  @override
  State<WhiteboardPage> createState() => _WhiteboardPageState();
}

class _WhiteboardPageState extends State<WhiteboardPage> {
  Annotations? ann;
  final tc = TransformationController();
  late String title = widget.meta.title;
  late String templateId = widget.meta.templateId;

  static const _colors = [0xFF2B2B2B, 0xFFE53935, 0xFF1E88E5, 0xFF2E7D32, 0xFFFB8C00, 0xFF8E24AA, 0xFFFFD54F, 0xFFF48FB1, 0xFF26A69A];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final a = await Annotations.open('board_${widget.meta.id}');
    if (!mounted) return;
    a.setTool('pen');
    setState(() => ann = a);
  }

  @override
  void dispose() {
    ann?.flush();
    ann?.dispose();
    tc.dispose();
    super.dispose();
  }

  Future<void> _saveMeta() async {
    widget.meta.title = title;
    widget.meta.templateId = templateId;
    widget.meta.updatedAt = DateTime.now().millisecondsSinceEpoch;
    AppData.upsertBoard(widget.meta);
    await ann?.flush();
  }

  Future<void> _rename() async {
    final c = TextEditingController(text: title);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسمية اللوحة'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'العنوان')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && c.text.trim().isNotEmpty) {
      setState(() => title = c.text.trim());
      await _saveMeta();
    }
  }

  Future<void> _clearStrokes() async {
    final a = ann;
    if (a == null || a.strokes.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('مسح جميع الرسوم؟'),
        content: const Text('سيتم مسح خطوط القلم والتمييز والأسهم (مع بقاء القالب والستيكرات). يمكنك التراجع لاحقاً.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('مسح')),
        ],
      ),
    );
    if (ok == true) {
      a.strokes.clear();
      a.touch();
    }
  }

  Future<String?> _pickPhoto() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return null;
    final src = r.files.single.path!;
    final dir = Directory('${Store.dir.path}/sticker_img');
    if (!await dir.exists()) await dir.create(recursive: true);
    final dot = src.lastIndexOf('.');
    final ext = dot > src.lastIndexOf('/') ? src.substring(dot) : '.jpg';
    final dst = '${dir.path}/${newId()}$ext';
    await File(src).copy(dst);
    return dst;
  }

  Future<void> _addSticker() async {
    final a = ann;
    if (a == null) return;
    final pick = await pickSticker(context);
    if (pick == null || !mounted) return;
    final id = pick['id'];
    if (id == 'pack') {
      final s = StickerItem(id: newId(), page: 1, asset: 'pack:${pick['pack']}:${pick['index']}', size: .36);
      a.addSticker(s);
    } else if (id == 'photo') {
      final path = await _pickPhoto();
      if (path == null || !mounted) return;
      final s = StickerItem(id: newId(), page: 1, asset: 'photo:${pick['style']}', size: .32, img: path);
      a.addSticker(s);
      if (!mounted) return;
      final t = await editText(context, '', title: 'تعليق تحت الصورة (اختياري)');
      if (t != null) {
        s.text = t;
        a.touch();
      }
    } else if (id == 'paper') {
      final s = StickerItem(id: newId(), page: 1, asset: 'paper:${pick['style']}', size: .32, text: (pick['text'] as String?) ?? '');
      a.addSticker(s);
      if (pick['blank'] == true && mounted) {
        final t = await editText(context, '');
        if (t != null) {
          s.text = t;
          a.touch();
        }
      }
    } else if (pick['file'] is String) {
      final s = StickerItem(id: newId(), page: 1, asset: pick['file'] as String);
      a.addSticker(s);
      if (pick['blank'] == true && mounted) {
        final t = await editText(context, '');
        if (t != null) {
          s.text = t;
          a.touch();
        }
      }
    }
    a.setTool('none');
  }

  Future<void> _stickerAction(StickerItem s, bool _) async {
    final a = ann;
    if (a == null) return;
    final act = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: HC.green,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.edit_rounded), title: const Text('تعديل النص'), onTap: () => Navigator.pop(c, 'text')),
          ListTile(leading: Icon(s.locked ? Icons.lock_open_rounded : Icons.lock_rounded), title: Text(s.locked ? 'إلغاء التثبيت' : 'تثبيت في مكانه'), onTap: () => Navigator.pop(c, 'lock')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: const Text('حذف'), onTap: () => Navigator.pop(c, 'del')),
        ]),
      ),
    );
    if (act == 'text' && mounted) {
      if (s.asset.startsWith('text:')) {
        final parts = s.asset.split(':');
        final colVal = parts.length >= 2 ? (int.tryParse(parts[1], radix: 16) ?? 0xFF2B2B2B) : 0xFF2B2B2B;
        final hand = parts.length >= 3 && parts[2] == '1';
        final fs = parts.length >= 4 ? (double.tryParse(parts[3]) ?? 18.0) : 18.0;
        final res = await showAddTextDialog(context, initial: s.text, initialColor: colVal, initialHand: hand, initialSize: fs, isEdit: true);
        if (res != null && res.$1.trim().isNotEmpty) {
          final updated = StickerItem(
            id: s.id,
            page: s.page,
            asset: 'text:${res.$2.toRadixString(16)}:${res.$3 ? 1 : 0}:${res.$4.round()}',
            x: s.x,
            y: s.y,
            size: s.size,
            rot: s.rot,
            text: res.$1.trim(),
            locked: s.locked,
          );
          final idx = a.stickers.indexWhere((x) => x.id == s.id);
          if (idx >= 0) a.stickers[idx] = updated;
          a.touch();
        }
      } else {
        final t = await editText(context, s.text);
        if (t != null) {
          s.text = t;
          a.touch();
        }
      }
    } else if (act == 'lock') {
      s.locked = !s.locked;
      a.touch();
    } else if (act == 'del') {
      a.removeSticker(s);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = ann;
    return Scaffold(
      backgroundColor: HC.deep,
      appBar: AppBar(
        backgroundColor: HC.deep,
        title: GestureDetector(
          onTap: _rename,
          child: Row(children: [
            Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16))),
            const SizedBox(width: 4),
            const Icon(Icons.edit_rounded, size: 15),
          ]),
        ),
        actions: [
          // اختصار ذكي: إعادة ضبط الزوم
          IconButton(tooltip: 'إعادة ضبط التكبير', onPressed: () => tc.value = Matrix4.identity(), icon: const Icon(Icons.fit_screen_rounded, size: 20)),
          // اختصار ذكي: مسح كل الرسوم
          IconButton(tooltip: 'مسح الرسوم', onPressed: _clearStrokes, icon: const Icon(Icons.layers_clear_rounded, size: 20)),
          if (widget.attachMode)
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: FilledButton.icon(
                onPressed: () async {
                  await _saveMeta();
                  if (context.mounted) Navigator.pop(context, widget.meta);
                },
                icon: const Icon(Icons.push_pin_rounded, size: 18),
                label: const Text('تثبيت مصغّرة'),
              ),
            )
          else
            IconButton(
              tooltip: 'حفظ',
              onPressed: () async {
                await _saveMeta();
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ اللوحة')));
              },
              icon: const Icon(Icons.check_rounded),
            ),
        ],
      ),
      body: a == null
          ? const Center(child: CircularProgressIndicator())
          : ListenableBuilder(
              listenable: Listenable.merge([a, a.settings]),
              builder: (context, _) {
                final drawing = a.tool != 'none';
                return Stack(children: [
                  // القالب يملأ الشاشة دائماً بثبات تام ولا يتغير حجمه أبداً عند تبديل الأدوات
                  Positioned.fill(
                    child: LayoutBuilder(builder: (context, box) {
                      const ratio = 0.71;
                      var cw = box.maxWidth - 12;
                      var ch = cw / ratio;
                      if (ch > box.maxHeight - 12) {
                        ch = box.maxHeight - 12;
                        cw = ch * ratio;
                      }
                      return InteractiveViewer(
                        transformationController: tc,
                        panEnabled: !drawing,
                        scaleEnabled: !drawing,
                        minScale: 0.85,
                        maxScale: 4.5,
                        boundaryMargin: const EdgeInsets.only(bottom: 150, top: 20, left: 40, right: 40),
                        child: Center(
                          child: Container(
                            width: cw,
                            height: ch,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              boxShadow: [BoxShadow(color: Colors.black45, blurRadius: 14, offset: Offset(0, 6))],
                            ),
                            child: Stack(children: [
                              Positioned.fill(child: RepaintBoundary(child: CustomPaint(painter: TemplatePainter(templateId)))),
                              Positioned.fill(
                                child: RepaintBoundary(
                                  child: PageOverlay(
                                    page: 1,
                                    ann: a,
                                    onPin: (pin, {isNew = false}) => showPinSheet(context, a, pin, isNew: isNew),
                                    onSticker: _stickerAction,
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        ),
                      );
                    }),
                  ),
                  // شريط الأدوات العائم بالأسفل (يتغير ارتفاعه لوحده بدون التأثير على مقاس القالب)
                  Positioned(
                    left: 8,
                    right: 8,
                    bottom: 8,
                    child: Material(
                      color: HC.deep.withValues(alpha: .94),
                      borderRadius: BorderRadius.circular(18),
                      elevation: 8,
                      child: ClipRRect(borderRadius: BorderRadius.circular(18), child: _toolbar(a)),
                    ),
                  ),
                ]);
              },
            ),
    );
  }

  Widget _subOptions(Annotations a) {
    final t = a.tool;
    if (t != 'hl' && t != 'pen' && t != 'arrow' && t != 'circle') return const SizedBox.shrink();
    Widget chip(Widget child, bool sel, VoidCallback onTap) => InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              color: sel ? HC.cream : HC.cream.withValues(alpha: .10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: DefaultTextStyle(style: TextStyle(fontSize: 11.5, color: sel ? HC.green : HC.cream, fontWeight: FontWeight.w600), child: child),
          ),
        );

    final items = <Widget>[];
    if (t == 'hl') {
      items.add(chip(Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.horizontal_rule_rounded, size: 16, color: !a.hlFree ? HC.green : HC.cream), const SizedBox(width: 4), const Text('مستقيم')]), !a.hlFree, () => a.setHlFree(false)));
      items.add(chip(Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.gesture_rounded, size: 16, color: a.hlFree ? HC.green : HC.cream), const SizedBox(width: 4), const Text('حر')]), a.hlFree, () => a.setHlFree(true)));
    }
    if (t == 'arrow') {
      const names = {'straight': 'مستقيم', 'curveL': 'منحني ⤴', 'curveR': 'منحني ⤵', 'wave': 'متموّج', 'hand': 'يدوي', 'double': 'مزدوج', 'dashed': 'متقطّع'};
      for (final st in kArrowStyles) {
        items.add(chip(Text(names[st] ?? st), a.arrowStyle == st, () => a.setArrowStyle(st)));
      }
      const heads = [('end', '→'), ('start', '←'), ('both', '↔'), ('none', '—')];
      for (final h in heads) {
        items.add(chip(Text(h.$2), a.arrowHead == h.$1, () => a.setArrowHead(h.$1)));
      }
    }
    for (final w in const [(1.0, 'رفيع'), (1.8, 'وسط'), (3.0, 'عريض')]) {
      items.add(chip(Text(w.$2), a.widthScale == w.$1, () => a.setWidthScale(w.$1)));
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: items)),
    );
  }

  Widget _toolbar(Annotations a) {
    final showColors = a.toolColor.containsKey(a.tool);
    Widget btn(IconData ic, String lbl, {String? tool, VoidCallback? onTap}) {
      final on = tool != null && a.tool == tool;
      final c = on ? HC.green : HC.cream;
      return InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap ?? () => a.setTool(tool!),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          decoration: BoxDecoration(color: on ? HC.cream : null, borderRadius: BorderRadius.circular(12)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(ic, size: 20, color: c),
            Text(lbl, style: TextStyle(fontSize: 10, color: c)),
          ]),
        ),
      );
    }

    return Container(
      color: HC.deep,
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _subOptions(a),
        if (showColors)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                for (final col in _colors)
                  GestureDetector(
                    onTap: () => a.setColor(col),
                    child: Container(
                      width: 26,
                      height: 26,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: Color(col),
                        shape: BoxShape.circle,
                        border: Border.all(color: a.toolColor[a.tool] == col ? HC.cream : Colors.white24, width: a.toolColor[a.tool] == col ? 3 : 1),
                      ),
                    ),
                  ),
              ]),
            ),
          ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            btn(Icons.pan_tool_alt_rounded, 'تحريك', tool: 'none', onTap: () => a.setTool(a.tool == 'none' ? 'pen' : 'none')),
            btn(Icons.edit_rounded, 'قلم', tool: 'pen'),
            btn(Icons.highlight_rounded, 'تمييز', tool: 'hl'),
            btn(Icons.title_rounded, 'نص T', tool: 'text'),
            btn(Icons.north_east_rounded, 'سهم', tool: 'arrow'),
            btn(Icons.panorama_fish_eye_rounded, 'دائرة', tool: 'circle'),
            btn(Icons.auto_fix_normal_rounded, 'ممحاة', tool: 'erase'),
            btn(Icons.emoji_emotions_rounded, 'ستيكر', onTap: _addSticker),
            btn(Icons.add_comment_rounded, 'تعليق', tool: 'pin'),
            btn(Icons.undo_rounded, 'تراجع', onTap: a.undo),
            btn(Icons.redo_rounded, 'إعادة', onTap: a.redo),
          ]),
        ),
      ]),
    );
  }
}
