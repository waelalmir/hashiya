import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'assistant_page.dart';
import 'backup.dart';
import 'data.dart';
import 'glass.dart';
import 'store.dart';
import 'theme.dart';
import 'version.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final nameC = TextEditingController(text: AppData.name.value);
  static const maxBytes = 2 * 1024 * 1024;
  static double _off = 0; // يحفظ موضع التمرير لأن الواجهة تُعاد بعد تبديل الثيم
  late final ScrollController sc = ScrollController(initialScrollOffset: _off)..addListener(() => _off = sc.offset);

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _pickBg() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.single.path == null) return;
    final src = File(r.files.single.path!);
    final size = await src.length();
    if (size > maxBytes) {
      _snack('حجم الصورة ${(size / 1048576).toStringAsFixed(1)} ميغا، الحد الأقصى 2 ميغا');
      return;
    }
    final ext = r.files.single.name.contains('.') ? r.files.single.name.split('.').last.toLowerCase() : 'jpg';
    final dest = '${Store.dir.path}/bg_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await src.copy(dest);
    final old = AppData.bgPath.value;
    AppData.bgPath.value = dest;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await AppData.save();
  }

  Future<void> _resetBg() async {
    final old = AppData.bgPath.value;
    AppData.bgPath.value = null;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await AppData.save();
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: GlassCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            child,
          ]),
        ),
      );

  Widget _dots(AppPalette p) => Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 22, height: 22, decoration: BoxDecoration(color: p.green, shape: BoxShape.circle, border: Border.all(color: Colors.white38))),
        Transform.translate(offset: const Offset(-6, 0), child: Container(width: 22, height: 22, decoration: BoxDecoration(color: p.cream, shape: BoxShape.circle, border: Border.all(color: Colors.white38)))),
      ]);

  Widget _themeTile(AppPalette p, String label, bool on, VoidCallback f) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: f,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: HC.cream.withValues(alpha: on ? .22 : .08),
            border: Border.all(color: on ? HC.cream : HC.cream.withValues(alpha: .2), width: on ? 2 : 1),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [_dots(p), const SizedBox(width: 4), Text(label, style: const TextStyle(fontSize: 14))]),
        ),
      );

  Widget _swatchRow(List<int> colors, int selected, void Function(int) onPick) => Wrap(spacing: 10, runSpacing: 10, children: [
        for (final c in colors)
          GestureDetector(
            onTap: () => onPick(c),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: selected == c ? Colors.white : Colors.white24, width: selected == c ? 3 : 1)),
            ),
          ),
      ]);

  Widget _themePicker() => ValueListenableBuilder<String>(
        valueListenable: AppData.themeId,
        builder: (context, id, _) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (final p in kPalettes) _themeTile(p, p.name, id == p.id, () => AppData.setTheme(p.id)),
            _themeTile(AppData.customPalette, 'تخصيص يدوي', id == 'custom', () => AppData.setCustom()),
          ]),
          if (id == 'custom') ...[
            const SizedBox(height: 16),
            const Text('لون الخلفية والأسطح', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            _swatchRow(kBaseSwatches, AppData.customBase.value, (c) => AppData.setCustom(base: c)),
            const SizedBox(height: 14),
            const Text('لون النص والتمييز', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            _swatchRow(kTextSwatches, AppData.customText.value, (c) => AppData.setCustom(text: c)),
          ],
        ]),
      );

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        controller: sc,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const PageHeader(title: 'الإعدادات'),
          _section(
            'الملف الشخصي',
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              // يتقلّص على الموبايل
              child: TextField(
                controller: nameC,
                decoration: const InputDecoration(labelText: 'الاسم'),
                onChanged: (v) {
                  AppData.name.value = v;
                  AppData.save();
                },
              ),
            ),
          ),
          _section('الألوان (الثيم)', _themePicker()),
          _section(
            'خلفية التطبيق',
            ValueListenableBuilder<String?>(
              valueListenable: AppData.bgPath,
              builder: (context, p, _) => Wrap(spacing: 16, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.start, children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 220,
                    height: 124,
                    child: (p != null && File(p).existsSync()) ? Image.file(File(p), fit: BoxFit.cover) : Image.asset('assets/bg/bg.jpg', fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(width: 16),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FilledButton.icon(onPressed: _pickBg, icon: const Icon(Icons.image_rounded), label: const Text('اختيار صورة')),
                  const SizedBox(height: 8),
                  OutlinedButton(onPressed: p == null ? null : _resetBg, child: const Text('الخلفية الافتراضية')),
                  const SizedBox(height: 8),
                  Text('الحد الأقصى لحجم الصورة: 2 ميغا', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
                ]),
              ]),
            ),
          ),
          _section(
            'الأداء',
            ValueListenableBuilder<bool>(
              valueListenable: AppData.reduceBlur,
              builder: (context, v, _) => SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('تقليل الشفافية (أسرع)'),
                subtitle: const Text('يوقف تمويه الزجاج في الواجهة'),
                value: v,
                onChanged: (x) {
                  AppData.reduceBlur.value = x;
                  AppData.save();
                },
              ),
            ),
          ),
          _section('المساعد الذكي و OCR (Gemini)', const AiKeyEditor()),
          _section('ملاحظات الأصدقاء', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('لتصدير ملاحظاتك: افتح الكتاب ثم القائمة ⋮ ثم تصدير. لاستيراد ملف وصلك:', style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .7))),
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: () => Backup.importFile(context), icon: const Icon(Icons.download_rounded), label: const Text('استيراد ملف .hashiya')),
          ])),
          _section('حول', Text('حاشية · الإصدار $kVersion · بناء $kBuild', style: TextStyle(color: HC.cream.withValues(alpha: .7)))),
        ]),
      );
}
