import 'package:flutter/material.dart';
import 'data.dart';
import 'glass.dart';
import 'store.dart';
import 'theme.dart';

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});

  static final _sel = ValueNotifier<int>(6);
  static const _days = ['الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];

  Widget _card(String label, String value, IconData i) => GlassCard(
        child: Row(children: [
          Icon(i, size: 28, color: HC.cream.withValues(alpha: .8)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
              const SizedBox(height: 4),
              Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
      );

  Widget _ex(BuildContext c, int flex, Widget w) => isCompact(c) ? w : Expanded(flex: flex, child: w);

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([AppData.reading, AppData.sessions, AppData.tasks, Store.books]),
        builder: (context, _) {
          final now = DateTime.now();
          final week = [for (var i = 6; i >= 0; i--) now.subtract(Duration(days: i))];
          final secs = [for (final d in week) AppData.secondsOn(AppData.dayKey(d))];
          final fm = [for (final d in week) AppData.focusMinutesOn(AppData.dayKey(d))];
          final maxM = [1.0, for (final v in secs) v / 60, for (final v in fm) v.toDouble()].reduce((a, b) => b > a ? b : a);
          final per = AppData.perBook().entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          final top = per.take(5).toList();
          final focusMin = AppData.sessions.value.fold<int>(0, (a, s) => a + s.minutes);
          final doneTasks = AppData.tasks.value.where((t) => t.done).length;
          String title(String id) {
            for (final b in Store.books.value) {
              if (b.id == id) return b.title;
            }
            return 'كتاب محذوف';
          }

          return SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const PageHeader(title: 'الإحصائيات'),
              Builder(builder: (context) {
                final cs = [
                  _card('إجمالي القراءة', AppData.fmtDuration(AppData.totalSeconds), Icons.auto_stories_rounded),
                  _card('أيام متتالية', '${AppData.streak}', Icons.local_fire_department_rounded),
                  _card('وقت التركيز', AppData.fmtDuration(focusMin * 60), Icons.timer_rounded),
                  _card('مهام منجزة', '$doneTasks', Icons.task_alt_rounded),
                ];
                if (isCompact(context)) {
                  return Column(children: [
                    Row(children: [Expanded(child: cs[0]), const SizedBox(width: 12), Expanded(child: cs[1])]),
                    const SizedBox(height: 12),
                    Row(children: [Expanded(child: cs[2]), const SizedBox(width: 12), Expanded(child: cs[3])]),
                  ]);
                }
                return Row(children: [for (var i = 0; i < 4; i++) ...[if (i > 0) const SizedBox(width: 16), Expanded(child: cs[i])]]);
              }),
              const SizedBox(height: 16),
              Flex(direction: isCompact(context) ? Axis.vertical : Axis.horizontal, crossAxisAlignment: CrossAxisAlignment.start, children: [
                _ex(context, 3, GlassCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('آخر 7 أيام', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 220,
                        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          for (var i = 0; i < 7; i++)
                            Expanded(
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => _sel.value = i,
                                child: ValueListenableBuilder<int>(
                                  valueListenable: _sel,
                                  builder: (context, sel, _) {
                                    final rd = secs[i] / 60, fc = fm[i].toDouble();
                                    return Container(
                                      decoration: BoxDecoration(color: sel == i ? HC.cream.withValues(alpha: .1) : Colors.transparent, borderRadius: BorderRadius.circular(10)),
                                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                                        Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                                          Container(width: 12, height: 4 + 150 * rd / maxM, decoration: BoxDecoration(color: HC.cream.withValues(alpha: rd == 0 ? .25 : 1), borderRadius: BorderRadius.circular(5))),
                                          const SizedBox(width: 3),
                                          Container(width: 12, height: 4 + 150 * fc / maxM, decoration: BoxDecoration(color: const Color(0xFFFFD54F).withValues(alpha: fc == 0 ? .25 : 1), borderRadius: BorderRadius.circular(5))),
                                        ]),
                                        const SizedBox(height: 6),
                                        Text(_days[week[i].weekday - 1], style: TextStyle(fontSize: 11, color: HC.cream.withValues(alpha: sel == i ? 1 : .7))),
                                        const SizedBox(height: 4),
                                      ]),
                                    );
                                  },
                                ),
                              ),
                            ),
                        ]),
                      ),
                      ValueListenableBuilder<int>(
                        valueListenable: _sel,
                        builder: (context, sel, _) {
                          final dk = AppData.dayKey(week[sel]);
                          final n = AppData.sessions.value.where((s) => AppData.dayKey(DateTime.fromMillisecondsSinceEpoch(s.at)) == dk).length;
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text('${_days[week[sel].weekday - 1]}: قراءة ${(secs[sel] / 60).round()} د · تركيز ${fm[sel]} د · $n جلسة', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                          );
                        },
                      ),
                      Text('الكريمي = قراءة · الأصفر = تركيز (اضغط على يوم للتفاصيل)', style: TextStyle(fontSize: 11, color: HC.cream.withValues(alpha: .5))),
                    ]),
                  )),
                const SizedBox(width: 16, height: 16),
                _ex(context, 2, GlassCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('حسب الكتاب', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 14),
                      if (top.isEmpty) Text('ابدأ القراءة لتظهر الإحصائيات', style: TextStyle(color: HC.cream.withValues(alpha: .6))),
                      for (final e in top)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text(title(e.key), maxLines: 1, overflow: TextOverflow.ellipsis)),
                              Text(AppData.fmtDuration(e.value), style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
                            ]),
                            const SizedBox(height: 6),
                            LinearProgressIndicator(value: e.value / top.first.value, minHeight: 6, borderRadius: BorderRadius.circular(3)),
                          ]),
                        ),
                    ]),
                  )),
              ]),
            ]),
          );
        },
      );
}
