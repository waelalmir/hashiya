import 'dart:io';
import 'package:flutter/material.dart';
import 'backup.dart';
import 'glass.dart';
import 'reader_page.dart';
import 'store.dart';
import 'theme.dart';

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  /// null = الكل، '_none' = بدون مجلد، غير ذلك = رقم مجلد
  String? folder;

  Future<void> _add(BuildContext context) async {
    final b = await Store.pickAndAdd(folderId: (folder != null && folder != '_none') ? folder : null);
    if (b != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تمت إضافة: ${b.title}')));
    }
  }

  Future<void> _menu(BuildContext context, Book b) async {
    final r = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: HC.green,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(16), child: Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
          ListTile(leading: const Icon(Icons.image_rounded), title: const Text('تغيير الغلاف (اختيار صورة)'), onTap: () => Navigator.pop(c, 'pick')),
          ListTile(leading: const Icon(Icons.auto_awesome_rounded), title: const Text('غلاف تلقائي (الصفحة الأولى)'), onTap: () => Navigator.pop(c, 'auto')),
          ListTile(leading: const Icon(Icons.folder_open_rounded), title: const Text('نقل إلى مجلد'), onTap: () => Navigator.pop(c, 'move')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: const Text('حذف الكتاب'), onTap: () => Navigator.pop(c, 'del')),
        ]),
      ),
    );
    if (r == 'pick') {
      await Store.pickManualCover(b);
    } else if (r == 'auto') {
      await Store.resetCover(b);
    } else if (r == 'move' && context.mounted) {
      await _moveDialog(context, b);
    } else if (r == 'del' && context.mounted) {
      await _confirmDelete(context, b);
    }
  }

  Future<String?> _askName(BuildContext context, {String initial = '', String title = 'اسم المجلد'}) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'مثلاً: كتب عربية، مراجع، دراسة')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Future<void> _moveDialog(BuildContext context, Book b) async {
    final r = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('نقل إلى مجلد'),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(c, '_none'), child: Text('بدون مجلد${b.folderId == null ? '  ✓' : ''}')),
          for (final f in Store.folders.value) SimpleDialogOption(onPressed: () => Navigator.pop(c, f.id), child: Text('${f.name}${b.folderId == f.id ? '  ✓' : ''}')),
          SimpleDialogOption(onPressed: () => Navigator.pop(c, '_new'), child: const Text('+ مجلد جديد', style: TextStyle(fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (r == null) return;
    if (r == '_none') {
      await Store.moveBook(b, null);
    } else if (r == '_new') {
      if (!context.mounted) return;
      final name = await _askName(context);
      if (name != null && name.trim().isNotEmpty) {
        final f = await Store.addFolder(name);
        await Store.moveBook(b, f.id);
      }
    } else {
      await Store.moveBook(b, r);
    }
  }

  Future<void> _folderMenu(BuildContext context, Folder f) async {
    final r = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: HC.green,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(16), child: Text(f.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
          ListTile(leading: const Icon(Icons.edit_rounded), title: const Text('إعادة تسمية'), onTap: () => Navigator.pop(c, 'rename')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: const Text('حذف المجلد (الكتب بتبقى)'), onTap: () => Navigator.pop(c, 'del')),
        ]),
      ),
    );
    if (r == 'rename' && context.mounted) {
      final name = await _askName(context, initial: f.name, title: 'إعادة تسمية المجلد');
      if (name != null && name.trim().isNotEmpty) await Store.renameFolder(f, name);
    } else if (r == 'del') {
      if (folder == f.id) setState(() => folder = null);
      await Store.deleteFolder(f);
    }
  }

  Widget _folderBar(BuildContext context, List<Book> books, List<Folder> folders) {
    final none = books.where((b) => b.folderId == null).length;
    Widget chip(String label, bool on, VoidCallback tap, {VoidCallback? hold}) => Padding(
          padding: const EdgeInsetsDirectional.only(end: 8),
          child: GestureDetector(onLongPress: hold, child: ChoiceChip(label: Text(label), selected: on, onSelected: (_) => tap())),
        );
    return SizedBox(
      height: 46,
      child: ListView(scrollDirection: Axis.horizontal, children: [
        chip('الكل (${books.length})', folder == null, () => setState(() => folder = null)),
        for (final f in folders) chip('${f.name} (${books.where((b) => b.folderId == f.id).length})', folder == f.id, () => setState(() => folder = f.id), hold: () => _folderMenu(context, f)),
        if (folders.isNotEmpty && none > 0) chip('بدون مجلد ($none)', folder == '_none', () => setState(() => folder = '_none')),
        ActionChip(
          avatar: const Icon(Icons.create_new_folder_rounded, size: 18),
          label: const Text('مجلد جديد'),
          onPressed: () async {
            final name = await _askName(context);
            if (name != null && name.trim().isNotEmpty) {
              final f = await Store.addFolder(name);
              setState(() => folder = f.id);
            }
          },
        ),
      ]),
    );
  }

  Future<void> _confirmDelete(BuildContext context, Book b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف الكتاب؟'),
        content: Text(b.title),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) await Store.remove(b);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        PageHeader(title: 'المكتبة', actions: [
          IconButton(tooltip: 'استيراد ملاحظات (.hashiya)', onPressed: () => Backup.importFile(context), icon: const Icon(Icons.download_rounded)),
          FilledButton.icon(onPressed: () => _add(context), icon: const Icon(Icons.add), label: const Text('إضافة PDF')),
        ]),
        Expanded(
          child: ListenableBuilder(
            listenable: Listenable.merge([Store.books, Store.folders]),
            builder: (context, _) {
              final books = Store.books.value;
              final folders = Store.folders.value;
              if (folder != null && folder != '_none' && !folders.any((f) => f.id == folder)) folder = null;
              final shown = folder == null ? books : (folder == '_none' ? books.where((b) => b.folderId == null).toList() : books.where((b) => b.folderId == folder).toList());
              if (books.isEmpty) {
                return Center(
                  child: GlassCard(
                    padding: const EdgeInsets.all(40),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('مكتبتك فارغة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Text('أضف أول ملف PDF لتبدأ', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
                      const SizedBox(height: 20),
                      FilledButton(onPressed: () => _add(context), child: const Text('+ إضافة PDF')),
                    ]),
                  ),
                );
              }
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _folderBar(context, books, folders),
                const SizedBox(height: 10),
                Expanded(
                  child: shown.isEmpty
                      ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('المجلد فارغ. اضغط مطولاً على أي كتاب ثم "نقل إلى مجلد".', textAlign: TextAlign.center, style: TextStyle(color: HC.cream.withValues(alpha: .65)))))
                      : GridView.builder(
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: isCompact(context) ? 165 : 200, childAspectRatio: .68, crossAxisSpacing: 14, mainAxisSpacing: 14),
                itemCount: shown.length,
                itemBuilder: (context, i) {
                  final b = shown[i];
                  Store.ensureCover(b);
                  return GestureDetector(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(book: b))),
                    onLongPress: () => _menu(context, b),
                    child: GlassCard(
                      padding: const EdgeInsets.all(12),
                      radius: 18,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              color: HC.cream.withValues(alpha: .14),
                              child: Store.hasCover(b)
                                  ? Image.file(File(b.cover!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.picture_as_pdf_rounded, size: 40)))
                                  : const Center(child: Icon(Icons.picture_as_pdf_rounded, size: 40)),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(value: b.progress, minHeight: 5, borderRadius: BorderRadius.circular(3)),
                      ]),
                    ),
                  );
                },
              ),
                ),
              ]);
            },
          ),
        ),
      ]);
}
