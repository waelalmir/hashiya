import 'package:flutter/material.dart';

/// لوحة ألوان: لون الأساس (الأسطح) + لون النص/التمييز. الباقي يُشتق منهما.
class AppPalette {
  const AppPalette(this.id, this.name, this.green, this.cream);
  final String id, name;
  final Color green, cream;
  Color get deep => Color.lerp(green, Colors.black, .42)!;
  Color get mid => Color.lerp(green, Colors.white, .05)!;
}

const kPalettes = <AppPalette>[
  AppPalette('green', 'أخضر وكريمي', Color(0xFF064A44), Color(0xFFEDE5D3)),
  AppPalette('navy', 'كحلي وبيج', Color(0xFF1B2C52), Color(0xFFE8DCC4)),
  AppPalette('wine', 'خمري وعاجي', Color(0xFF5A1428), Color(0xFFF3EBDD)),
  AppPalette('coffee', 'قهوة وكريمي', Color(0xFF4A3020), Color(0xFFF0E2CC)),
  AppPalette('night', 'رمادي وذهبي', Color(0xFF2A2A2E), Color(0xFFD9B563)),
];

/// ألوان الأساس المقترحة للثيم المخصص (داكنة) وألوان النص (فاتحة).
const kBaseSwatches = <int>[
  0xFF064A44, 0xFF1B2C52, 0xFF5A1428, 0xFF4A3020, 0xFF2A2A2E, 0xFF3A2A5C,
  0xFF0F4C5C, 0xFF4A1D3F, 0xFF2F4A2A, 0xFF1F3A5F, 0xFF5C2E1A, 0xFF37474F,
];
const kTextSwatches = <int>[
  0xFFEDE5D3, 0xFFE8DCC4, 0xFFF3EBDD, 0xFFFFFFFF, 0xFFD9B563,
  0xFFF0C9C9, 0xFFCFE8E0, 0xFFD6E4F5, 0xFFE9D8FF, 0xFFFFE9A8,
];

/// الألوان الحالية للتطبيق. تتغيّر عند تبديل الثيم، و rev يُعلن التغيير.
class HC {
  static AppPalette p = kPalettes.first;
  static final rev = ValueNotifier<int>(0);
  static Color get green => p.green;
  static Color get cream => p.cream;
  static Color get mid => p.mid;
  static Color get deep => p.deep;
  static void apply(AppPalette np) {
    p = np;
    rev.value++;
  }
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      fontFamily: 'IBMPlexSansArabic',
      scaffoldBackgroundColor: HC.deep,
      colorScheme: ColorScheme.dark(
        primary: HC.cream,
        onPrimary: HC.green,
        secondary: HC.cream,
        surface: HC.green,
        onSurface: HC.cream,
      ),
    );
