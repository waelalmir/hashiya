import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'annotations.dart';
import 'page_overlay.dart';
import 'reading_mode.dart';
import 'theme.dart';

/// تخطيط صفحتين متجاورتين لوضع التمرير (pdfrx). rtl = الصفحة الأولى يمين (كتاب عربي).
PdfPageLayout spreadLayout(List<PdfPage> pages, PdfViewerParams params, {required bool rtl, required bool coverAlone}) {
  final m = params.margin;
  final groups = <List<int>>[];
  var i = 0;
  if (coverAlone && pages.isNotEmpty) {
    groups.add([0]);
    i = 1;
  }
  while (i < pages.length) {
    groups.add(i + 1 < pages.length ? [i, i + 1] : [i]);
    i += 2;
  }
  var maxW = 0.0;
  for (final g in groups) {
    var w = m * (g.length + 1);
    for (final k in g) {
      w += pages[k].width;
    }
    maxW = math.max(maxW, w);
  }
  final rects = List<Rect>.filled(pages.length, Rect.zero);
  var y = m;
  for (final g in groups) {
    var rowH = 0.0, rowW = m * (g.length - 1);
    for (final k in g) {
      rowH = math.max(rowH, pages[k].height);
      rowW += pages[k].width;
    }
    var x = (maxW - rowW) / 2;
    final order = rtl ? g.reversed.toList() : g;
    for (final k in order) {
      rects[k] = Rect.fromLTWH(x, y + (rowH - pages[k].height) / 2, pages[k].width, pages[k].height);
      x += pages[k].width + m;
    }
    y += rowH + m;
  }
  return PdfPageLayout(pageLayouts: rects, documentSize: Size(maxW, y));
}

class FlipController {
  _FlipReaderState? _s;
  void jump(int page, {bool animate = true}) => _s?._jumpTo(page, animate);
}

/// قارئ بالتقليب: صفحة (أو صفحتان) بالشاشة، سحب أو أسهم للتقليب، تكبير بالقرصة/النقر المزدوج.
class FlipReader extends StatefulWidget {
  const FlipReader({
    super.key,
    required this.path,
    required this.ann,
    required this.controller,
    required this.initialPage,
    required this.onTotal,
    required this.onPageChanged,
    required this.onPin,
    required this.onSticker,
  });
  final String path;
  final Annotations ann;
  final FlipController controller;
  final int initialPage;
  final void Function(int total) onTotal;
  final void Function(int page) onPageChanged;
  final PinTap onPin;
  final StickerAction onSticker;
  @override
  State<FlipReader> createState() => _FlipReaderState();
}

class _FlipReaderState extends State<FlipReader> {
  PdfDocument? doc;
  String? error;
  PageController? pc;
  List<List<int>> groups = [];
  int current = 0;
  bool zoomed = false;
  final _futures = <String, Future<ui.Image?>>{};
  Future<void> _queue = Future.value();

  @override
  void initState() {
    super.initState();
    widget.controller._s = this;
    _open();
  }

  Future<void> _open() async {
    try {
      final d = await PdfDocument.openFile(widget.path);
      final total = d.pages.length;
      final a = widget.ann;
      final g = <List<int>>[];
      var i = 1;
      if (a.spread) {
        if (a.coverAlone && total >= 1) {
          g.add([1]);
          i = 2;
        }
        while (i <= total) {
          g.add(i + 1 <= total ? [i, i + 1] : [i]);
          i += 2;
        }
      } else {
        for (var p = 1; p <= total; p++) {
          g.add([p]);
        }
      }
      if (!mounted) {
        await Future.sync(() => d.dispose());
        return;
      }
      final start = _groupOf(g, widget.initialPage);
      setState(() {
        doc = d;
        groups = g;
        current = start;
        pc = PageController(initialPage: start);
      });
      widget.onTotal(total);
    } catch (e) {
      if (mounted) setState(() => error = 'تعذّر فتح الملف');
    }
  }

  int _groupOf(List<List<int>> g, int page) {
    for (var i = 0; i < g.length; i++) {
      if (g[i].contains(page)) return i;
    }
    return 0;
  }

  void _jumpTo(int page, bool animate) {
    final c = pc;
    if (c == null || groups.isEmpty || !c.hasClients) return;
    final gi = _groupOf(groups, page);
    if (animate) {
      c.animateToPage(gi, duration: const Duration(milliseconds: 380), curve: Curves.easeInOutCubic);
    } else {
      c.jumpToPage(gi);
    }
  }

  void _step(int dir) {
    final c = pc;
    if (c == null || !c.hasClients) return;
    final t = (current + dir).clamp(0, groups.length - 1).toInt();
    c.animateToPage(t, duration: const Duration(milliseconds: 380), curve: Curves.easeInOutCubic);
  }

  @override
  void dispose() {
    if (widget.controller._s == this) widget.controller._s = null;
    pc?.dispose();
    final d = doc;
    if (d != null) Future.sync(() => d.dispose());
    super.dispose();
  }

  // ---------- رسم الصفحات إلى صور (مع طابور حتى لا تتزاحم) ----------
  Future<ui.Image?> _image(int p, int wpx, bool protect) {
    final key = '$p@$wpx@${protect ? 1 : 0}';
    final cached = _futures[key];
    if (cached != null) return cached;
    // نحتفظ فقط بالصفحات القريبة من الحالية
    final cur = groups.isEmpty ? 1 : groups[current].first;
    _futures.removeWhere((k, _) {
      final pg = int.tryParse(k.split('@').first) ?? 0;
      return (pg - cur).abs() > 6;
    });
    final c = Completer<ui.Image?>();
    _queue = _queue.then((_) async {
      c.complete(await _render(p, wpx, protect));
    });
    return _futures[key] = c.future;
  }

  Future<ui.Image?> _render(int p, int wpx, bool protect) async {
    try {
      final d = doc;
      if (d == null) return null;
      final page = d.pages[p - 1];
      final h = (wpx * page.height / page.width).round();
      final img = await page.render(width: wpx, height: h);
      if (img == null) return null;
      ui.Image im = await img.createImage();
      img.dispose();
      if (protect) {
        final out = await _protectPhotos(im);
        if (out != null) im = out;
      }
      return im;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.ann;
    if (error != null) return Center(child: Text(error!));
    if (doc == null || pc == null) return const Center(child: CircularProgressIndicator());
    final inv = toneInverts(a);
    final drawing = a.tool != 'none';
    final rtl = a.rtl;
    Widget pv = PageView.builder(
      controller: pc,
      physics: (drawing || zoomed) ? const NeverScrollableScrollPhysics() : const PageScrollPhysics(),
      itemCount: groups.length,
      onPageChanged: (i) {
        current = i;
        zoomed = false;
        widget.onPageChanged(groups[i].first);
        setState(() {});
      },
      itemBuilder: (c, i) => _item(i),
    );
    pv = Directionality(textDirection: rtl ? TextDirection.rtl : TextDirection.ltr, child: pv);
    Widget body = Container(color: inv ? invertColor(HC.deep) : HC.deep, child: pv);
    if (inv) body = ColorFiltered(colorFilter: kInvert, child: body);
    return Stack(children: [
      Positioned.fill(child: body),
      if (!drawing && !zoomed) ...[
        Align(
          alignment: Alignment.centerLeft,
          child: _arrow(Icons.chevron_left_rounded, rtl ? 1 : -1, current > 0 || rtl, rtl ? current < groups.length - 1 : current > 0),
        ),
        Align(
          alignment: Alignment.centerRight,
          child: _arrow(Icons.chevron_right_rounded, rtl ? -1 : 1, true, rtl ? current > 0 : current < groups.length - 1),
        ),
      ],
    ]);
  }

  Widget _arrow(IconData icon, int dir, bool _, bool enabled) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Opacity(
          opacity: enabled ? 1 : .25,
          child: IconButton.filled(
            style: IconButton.styleFrom(backgroundColor: HC.deep.withValues(alpha: .55), foregroundColor: HC.cream),
            onPressed: enabled ? () => _step(dir) : null,
            icon: Icon(icon, size: 30),
          ),
        ),
      );

  Widget _item(int gi) {
    final a = widget.ann;
    return AnimatedBuilder(
      animation: pc!,
      builder: (context, child) {
        var delta = 0.0;
        if (pc!.hasClients && pc!.position.haveDimensions) delta = (pc!.page ?? gi.toDouble()) - gi;
        final d = delta.clamp(-1.0, 1.0).toDouble();
        final angle = d * .6 * (a.rtl ? -1 : 1);
        return Opacity(
          opacity: (1 - d.abs() * .35).clamp(0.0, 1.0).toDouble(),
          child: Transform(alignment: Alignment.center, transform: Matrix4.identity()..setEntry(3, 2, .0012)..rotateY(angle), child: child),
        );
      },
      child: _SpreadView(
        key: ValueKey('${groups[gi].join('-')}|${a.viewSig}'),
        doc: doc!,
        pages: groups[gi],
        ann: a,
        imageFor: _image,
        onZoom: (z) {
          if (z != zoomed && mounted) setState(() => zoomed = z);
        },
        onPin: widget.onPin,
        onSticker: widget.onSticker,
      ),
    );
  }
}

class _SpreadView extends StatefulWidget {
  const _SpreadView({super.key, required this.doc, required this.pages, required this.ann, required this.imageFor, required this.onZoom, required this.onPin, required this.onSticker});
  final PdfDocument doc;
  final List<int> pages;
  final Annotations ann;
  final Future<ui.Image?> Function(int page, int wpx, bool protect) imageFor;
  final void Function(bool zoomed) onZoom;
  final PinTap onPin;
  final StickerAction onSticker;
  @override
  State<_SpreadView> createState() => _SpreadViewState();
}

class _SpreadViewState extends State<_SpreadView> {
  final tc = TransformationController();
  int pointers = 0;
  bool zoomed = false;
  Offset? _dt;

  @override
  void initState() {
    super.initState();
    tc.addListener(() {
      final z = tc.value.getMaxScaleOnAxis() > 1.03;
      if (z != zoomed) {
        zoomed = z;
        widget.onZoom(z);
        if (mounted) setState(() {});
      }
    });
  }

  @override
  void dispose() {
    tc.dispose();
    super.dispose();
  }

  void _pointer(int delta) {
    final before = pointers;
    pointers = math.max(0, pointers + delta);
    if ((before >= 2) != (pointers >= 2)) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.ann;
    final drawing = a.tool != 'none';
    final dpr = MediaQuery.devicePixelRatioOf(context);
    return LayoutBuilder(builder: (context, box) {
      final aspects = [for (final p in widget.pages) widget.doc.pages[p - 1].width / widget.doc.pages[p - 1].height];
      final totalAsp = aspects.fold<double>(0, (s, v) => s + v);
      const pad = 14.0, gap = 8.0;
      final availW = box.maxWidth - pad * 2 - gap * (widget.pages.length - 1);
      final availH = box.maxHeight - pad * 2;
      if (availW <= 0 || availH <= 0) return const SizedBox.shrink();
      final h = math.min(availH, availW / totalAsp);
      final protect = toneInverts(a) && a.protectPhotos;
      final cards = <Widget>[
        for (var k = 0; k < widget.pages.length; k++)
          SizedBox(
            width: aspects[k] * h,
            height: h,
            child: Stack(clipBehavior: Clip.none, children: [
              Positioned.fill(child: _PageImage(future: widget.imageFor(widget.pages[k], ((aspects[k] * h) * dpr * 1.8).clamp(700, 2600).round(), protect), ann: a)),
              Positioned.fill(child: RepaintBoundary(child: PageOverlay(page: widget.pages[k], ann: a, onPin: widget.onPin, onSticker: widget.onSticker))),
            ]),
          ),
      ];
      final row = Directionality(
        textDirection: a.rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Row(mainAxisSize: MainAxisSize.min, children: [for (var k = 0; k < cards.length; k++) ...[if (k > 0) const SizedBox(width: gap), cards[k]]]),
      );
      return Listener(
        onPointerDown: (_) => _pointer(1),
        onPointerUp: (_) => _pointer(-1),
        onPointerCancel: (_) => _pointer(-1),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onDoubleTapDown: (d) => _dt = d.localPosition,
          onDoubleTap: drawing
              ? null
              : () {
                  if (zoomed) {
                    tc.value = Matrix4.identity();
                  } else {
                    final p = _dt ?? Offset(box.maxWidth / 2, box.maxHeight / 2);
                    tc.value = Matrix4.identity()
                      ..translate(-p.dx * 1.5, -p.dy * 1.5)
                      ..scale(2.5);
                  }
                },
          child: InteractiveViewer(
            transformationController: tc,
            minScale: 1,
            maxScale: 5,
            panEnabled: !drawing && zoomed,
            scaleEnabled: !drawing && (zoomed || pointers >= 2),
            child: SizedBox(width: box.maxWidth, height: box.maxHeight, child: Center(child: row)),
          ),
        ),
      );
    });
  }
}

class _PageImage extends StatelessWidget {
  const _PageImage({required this.future, required this.ann});
  final Future<ui.Image?> future;
  final Annotations ann;
  @override
  Widget build(BuildContext context) => FutureBuilder<ui.Image?>(
        future: future,
        builder: (context, snap) {
          final im = snap.data;
          if (im == null) {
            return Container(color: Colors.white, child: Center(child: snap.connectionState == ConnectionState.done ? const Icon(Icons.broken_image_rounded, color: Colors.black26) : const CircularProgressIndicator(strokeWidth: 2)));
          }
          return CustomPaint(foregroundPainter: _ToneP(ann), child: RawImage(image: im, fit: BoxFit.fill));
        },
      );
}

class _ToneP extends CustomPainter {
  _ToneP(this.ann) : super(repaint: ann.settings);
  final Annotations ann;
  @override
  void paint(Canvas canvas, Size size) => paintTone(canvas, Offset.zero & size, ann);
  @override
  bool shouldRepaint(covariant _ToneP old) => true;
}

// ---------- حماية الصور بالوضع الليلي ----------
// بالوضع الليلي تُقلب ألوان الصفحة كلها (النص يصير فاتح). لنحافظ على الصور نكشف مناطقها تقريباً
// (كتل ملوّنة/متدرجة) ونقلب بكسلاتها مسبقاً فتعود لشكلها الطبيعي بعد القلب النهائي.
Future<ui.Image?> _protectPhotos(ui.Image im) async {
  try {
    final w = im.width, h = im.height;
    final bd = await im.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (bd == null) return null;
    final out = await compute(_protectIsolate, <Object>[Uint8List.fromList(bd.buffer.asUint8List()), w, h]);
    if (out == null) return null;
    final c = Completer<ui.Image>();
    ui.decodeImageFromPixels(out, w, h, ui.PixelFormat.rgba8888, c.complete);
    return await c.future;
  } catch (_) {
    return null;
  }
}

Uint8List? _protectIsolate(List<Object> a) {
  final px = a[0] as Uint8List;
  final w = a[1] as int, h = a[2] as int;
  const blk = 16;
  final bw = (w + blk - 1) ~/ blk, bh = (h + blk - 1) ~/ blk;
  final photo = List<bool>.filled(bw * bh, false);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      var mid = 0, col = 0, n = 0;
      final y1 = math.min(h, (by + 1) * blk), x1 = math.min(w, (bx + 1) * blk);
      for (var y = by * blk; y < y1; y += 2) {
        for (var x = bx * blk; x < x1; x += 2) {
          final i = (y * w + x) * 4;
          final r = px[i], g = px[i + 1], b = px[i + 2];
          final mx = math.max(r, math.max(g, b)), mn = math.min(r, math.min(g, b));
          final lum = (r * 299 + g * 587 + b * 114) ~/ 1000;
          if (mx - mn > 36) col++;
          if (lum > 50 && lum < 205) mid++;
          n++;
        }
      }
      if (n > 0 && (mid * 100 / n > 55 || col * 100 / n > 45)) photo[by * bw + bx] = true;
    }
  }
  final keep = List<bool>.filled(bw * bh, false);
  var total = 0;
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (!photo[by * bw + bx]) continue;
      var c = 0;
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          final yy = by + dy, xx = bx + dx;
          if (yy >= 0 && yy < bh && xx >= 0 && xx < bw && photo[yy * bw + xx]) c++;
        }
      }
      if (c >= 5) {
        keep[by * bw + bx] = true;
        total++;
      }
    }
  }
  if (total == 0) return null;
  // صفحة كلها صورة تقريباً (مسح ضوئي): نتركها بالقلب العادي
  if (total * 100 / (bw * bh) > 70) return null;
  final fin = List<bool>.filled(bw * bh, false);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (!keep[by * bw + bx]) continue;
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          final yy = by + dy, xx = bx + dx;
          if (yy >= 0 && yy < bh && xx >= 0 && xx < bw) fin[yy * bw + xx] = true;
        }
      }
    }
  }
  final res = Uint8List.fromList(px);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      if (!fin[by * bw + bx]) continue;
      final y1 = math.min(h, (by + 1) * blk), x1 = math.min(w, (bx + 1) * blk);
      for (var y = by * blk; y < y1; y++) {
        for (var x = bx * blk; x < x1; x++) {
          final i = (y * w + x) * 4;
          res[i] = 255 - res[i];
          res[i + 1] = 255 - res[i + 1];
          res[i + 2] = 255 - res[i + 2];
        }
      }
    }
  }
  return res;
}
