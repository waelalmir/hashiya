import 'dart:math' as math;
import 'store.dart';

/// رسائل التذكير والتحفيز (إشعارات). {n} = الاسم، {b} = عنوان آخر كتاب.
class ReminderTexts {
  static const _generic = <String>[
    'هل ترغب بمتابعة القراءة يا {n}؟ 📖',
    'صفحات قليلة اليوم تصنع فرقاً كبيراً. افتح كتابك الآن!',
    'وقت القراءة وصل يا {n} 🌟 خمس دقائق بس؟',
    'الاستمرارية أهم من الكمية. كمّل رحلتك اليوم 💪',
    'عقلك بيحب التحدّي. شو رأيك بجلسة تركيز؟ ⏱️',
    'أنت أقرب لهدفك مما تتخيل يا {n}. كمّل!',
    'كل يوم قراءة = يوم بناء لمستقبلك 🧱',
    'لا تخلّي اليوم يمرّ بدون صفحة. جاهز؟ ✨',
    'يا {n}، إنجاز اليوم بيبدأ بفتح الكتاب 📚',
    'استراحة المحارب انتهت. يلا نرجع للقراءة 😉',
    'العلم نور، وأنت قادر تشعله اليوم 🕯️',
    'لحظة هدوء وقراءة بتغيّر مزاج يومك 🌿',
  ];

  static const _withBook = <String>[
    'كمّل في «{b}» من وين وقفت يا {n} 📖',
    'كتاب «{b}» بانتظارك. صفحة أو اتنين اليوم؟',
    'ما رأيك نكمّل «{b}» ونقرّب من الخلاص؟ 🎯',
  ];

  /// قائمة الرسائل بعد استبدال الاسم وآخر كتاب.
  static List<String> build(String name) {
    final n = name.trim().isEmpty ? 'صديقي' : name.trim();
    final books = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
    final last = books.isEmpty ? null : books.first;
    final out = <String>[for (final m in _generic) m.replaceAll('{n}', n)];
    if (last != null) {
      for (final m in _withBook) {
        out.add(m.replaceAll('{n}', n).replaceAll('{b}', last.title.length > 40 ? '${last.title.substring(0, 40)}…' : last.title));
      }
    }
    out.shuffle(math.Random());
    return out;
  }
}
