import 'package:flutter/material.dart';
import 'media_controller.dart';
import 'media_view.dart';
import 'theme.dart';

String _t(Duration d) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
}

/// كبسولة تشغيل عائمة بأعلى الشاشة (بأسلوب الجزيرة الديناميكية) تظهر طالما في صوت/فيديو شغّال بالخلفية.
class MiniPlayerOverlay extends StatelessWidget {
  const MiniPlayerOverlay({super.key, required this.navKey});
  final GlobalKey<NavigatorState> navKey;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: MediaController.I,
        builder: (context, _) {
          final m = MediaController.I;
          if (!m.active || m.pageOpen) return const SizedBox.shrink();
          final top = MediaQuery.paddingOf(context).top;
          final prog = m.dur.inMilliseconds <= 0 ? 0.0 : (m.pos.inMilliseconds / m.dur.inMilliseconds).clamp(0.0, 1.0).toDouble();
          return Directionality(
            textDirection: TextDirection.rtl,
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: EdgeInsets.only(top: top + 8, left: 12, right: 12),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 420),
                  curve: Curves.easeOutBack,
                  builder: (context, v, child) => Transform.translate(offset: Offset(0, (1 - v) * -40), child: Transform.scale(scale: .6 + .4 * v, child: Opacity(opacity: v.clamp(0.0, 1.0).toDouble(), child: child))),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 360),
                    child: Material(
                      color: Colors.black,
                      elevation: 10,
                      borderRadius: BorderRadius.circular(32),
                      clipBehavior: Clip.antiAlias,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        InkWell(
                          onTap: () => navKey.currentState?.push(MaterialPageRoute(builder: (_) => MediaPlayerPage(path: m.path!, kind: m.kind, name: m.name ?? '', startMs: m.pos.inMilliseconds))),
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
                            child: Row(children: [
                              Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(color: HC.cream, shape: BoxShape.circle),
                                child: Icon(m.playing ? Icons.graphic_eq_rounded : Icons.headphones_rounded, color: HC.green, size: 22),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                                  Text(m.name ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                                  Text('${_t(m.pos)} / ${_t(m.dur)}', style: const TextStyle(color: Colors.white60, fontSize: 11)),
                                ]),
                              ),
                              IconButton(visualDensity: VisualDensity.compact, onPressed: m.toggle, icon: Icon(m.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white)),
                              IconButton(visualDensity: VisualDensity.compact, onPressed: m.stop, icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 20)),
                            ]),
                          ),
                        ),
                        LinearProgressIndicator(value: prog, minHeight: 2.5, backgroundColor: Colors.white12, color: HC.cream),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
}
