import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'data.dart';
import 'glass.dart';
import 'model.dart';
import 'reader_page.dart';
import 'store.dart';
import 'theme.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  int tab = 0; // 0 = الروتين اليومي، 1 = المهام العادية

  static const _routineIcons = <String, (String, IconData)>{
    'quran': ('قرآن', Icons.menu_book_rounded),
    'pray': ('صلاة / ذكر', Icons.mosque_rounded),
    'book': ('قراءة', Icons.auto_stories_rounded),
    'star': ('عادة', Icons.star_rounded),
    'heart': ('صحة', Icons.favorite_rounded),
    'check': ('تنظيم', Icons.check_circle_rounded),
  };

  Book? _book(String? id) {
    for (final b in Store.books.value) {
      if (b.id == id) return b;
    }
    return null;
  }

  Future<void> _editRoutine(BuildContext context, RoutineItem? old) async {
    final title = TextEditingController(text: old?.title ?? '');
    String icon = old?.icon ?? 'quran';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(old == null ? 'روتين يومي جديد' : 'تعديل الروتين'),
          content: SizedBox(
            width: math.min(420, MediaQuery.sizeOf(context).width - 80),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              TextField(
                controller: title,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'اسم الروتين', hintText: 'مثلاً: قراءة ورد القرآن، الصلاة بوقتها، أذكار الصباح...'),
              ),
              const SizedBox(height: 14),
              const Text('الأيقونة', style: TextStyle(fontSize: 13)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final e in _routineIcons.entries)
                  ChoiceChip(
                    avatar: Icon(e.value.$2, size: 16),
                    label: Text(e.value.$1, style: const TextStyle(fontSize: 12)),
                    selected: icon == e.key,
                    onSelected: (_) => set(() => icon = e.key),
                  ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
          ],
        ),
      ),
    );
    if (ok != true || title.text.trim().isEmpty) return;
    final r = old ?? RoutineItem(id: newId(), title: '');
    r.title = title.text.trim();
    r.icon = icon;
    AppData.setRoutines(old == null ? [...AppData.routines.value, r] : [...AppData.routines.value]);
  }

  Future<void> _editTask(BuildContext context, Task? old) async {
    final title = TextEditingController(text: old?.title ?? '');
    final from = TextEditingController(text: old?.from?.toString() ?? '');
    final to = TextEditingController(text: old?.to?.toString() ?? '');
    String? bookId = old?.bookId;
    DateTime? due = old?.due == null ? null : DateTime.fromMillisecondsSinceEpoch(old!.due!);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(old == null ? 'مهمة جديدة' : 'تعديل المهمة'),
          content: SizedBox(
            width: math.min(420, MediaQuery.sizeOf(context).width - 100),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'العنوان')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String?>(
                value: bookId,
                decoration: const InputDecoration(labelText: 'الكتاب (اختياري)'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('بدون كتاب')),
                  for (final b in Store.books.value) DropdownMenuItem<String?>(value: b.id, child: Text(b.title, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => set(() => bookId = v),
              ),
              if (bookId != null) ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: TextField(controller: from, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'من صفحة'))),
                  const SizedBox(width: 12),
                  Expanded(child: TextField(controller: to, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'إلى صفحة'))),
                ]),
              ],
              const SizedBox(height: 12),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final d = await showDatePicker(context: c, initialDate: due ?? DateTime.now(), firstDate: DateTime(2024), lastDate: DateTime(2100));
                    if (d != null) set(() => due = d);
                  },
                  icon: const Icon(Icons.event_rounded),
                  label: Text(due == null ? 'الموعد (اختياري)' : AppData.dayKey(due)),
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
          ],
        ),
      ),
    );
    if (ok != true || title.text.trim().isEmpty) return;
    final t = old ?? Task(id: newId(), title: '');
    t.title = title.text.trim();
    t.bookId = bookId;
    t.from = bookId == null ? null : int.tryParse(from.text);
    t.to = bookId == null ? null : int.tryParse(to.text);
    t.due = due?.millisecondsSinceEpoch;
    AppData.setTasks(old == null ? [...AppData.tasks.value, t] : [...AppData.tasks.value]);
  }

  Widget _routineRow(BuildContext context, RoutineItem r, String today) {
    final done = r.isDoneOn(today);
    final ic = _routineIcons[r.icon]?.$2 ?? Icons.star_rounded;
    final st = r.streak;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        child: Row(children: [
          Checkbox(value: done, onChanged: (_) => AppData.toggleRoutineToday(r.id)),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(color: HC.cream.withValues(alpha: done ? .22 : .12), borderRadius: BorderRadius.circular(10)),
            child: Icon(ic, size: 18, color: HC.cream),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: InkWell(
              onTap: () => _editRoutine(context, r),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, decoration: done ? TextDecoration.lineThrough : null, color: HC.cream.withValues(alpha: done ? .55 : 1))),
                Text(st > 0 ? 'سلسلة الالتزام: $st يوم 🔥' : 'يتجدد تلقائياً كل يوم', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
              ]),
            ),
          ),
          IconButton(onPressed: () => AppData.setRoutines(AppData.routines.value.where((x) => x.id != r.id).toList()), icon: const Icon(Icons.delete_outline_rounded)),
        ]),
      ),
    );
  }

  Widget _taskRow(BuildContext context, Task t) {
    final b = _book(t.bookId);
    final sub = <String>[
      if (b != null) b.title,
      if (t.from != null) 'ص ${t.from}${t.to != null ? '–${t.to}' : ''}',
      if (t.due != null) AppData.dayKey(DateTime.fromMillisecondsSinceEpoch(t.due!)),
    ].join(' · ');
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Row(children: [
          Checkbox(
            value: t.done,
            onChanged: (v) {
              t.done = v ?? false;
              AppData.setTasks([...AppData.tasks.value]);
            },
          ),
          Expanded(
            child: InkWell(
              onTap: () => _editTask(context, t),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t.title, style: TextStyle(fontSize: 16, decoration: t.done ? TextDecoration.lineThrough : null, color: HC.cream.withValues(alpha: t.done ? .5 : 1))),
                if (sub.isNotEmpty) Text(sub, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
              ]),
            ),
          ),
          if (b != null)
            IconButton(
              tooltip: 'فتح الكتاب',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(book: b, startPage: t.from))),
              icon: const Icon(Icons.menu_book_rounded),
            ),
          IconButton(onPressed: () => AppData.setTasks(AppData.tasks.value.where((x) => x.id != t.id).toList()), icon: const Icon(Icons.delete_outline_rounded)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([AppData.tasks, AppData.routines, Store.books]),
        builder: (context, _) {
          final today = AppData.dayKey();
          final rList = AppData.routines.value;
          final rDone = rList.where((r) => r.isDoneOn(today)).length;
          final allTasks = AppData.tasks.value;
          final todo = allTasks.where((t) => !t.done).toList();
          final done = allTasks.where((t) => t.done).toList();

          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            PageHeader(title: tab == 0 ? 'الروتين اليومي' : 'المهام', actions: [
              FilledButton.icon(
                onPressed: () => tab == 0 ? _editRoutine(context, null) : _editTask(context, null),
                icon: const Icon(Icons.add),
                label: Text(tab == 0 ? 'روتين جديد' : 'مهمة جديدة'),
              ),
            ]),
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: SizedBox(
                width: double.infinity,
                child: SegmentedButton<int>(
                  segments: [
                    ButtonSegment(value: 0, icon: const Icon(Icons.repeat_rounded), label: Text('الروتين اليومي (${rList.length})')),
                    ButtonSegment(value: 1, icon: const Icon(Icons.checklist_rounded), label: Text('المهام (${todo.length})')),
                  ],
                  selected: {tab},
                  onSelectionChanged: (v) => setState(() => tab = v.first),
                ),
              ),
            ),
            if (tab == 0)
              Expanded(
                child: rList.isEmpty
                    ? Center(
                        child: GlassCard(
                          padding: const EdgeInsets.all(28),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            const Text('أضف عاداتك اليومية المتكررة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 6),
                            Text('مثل قراءة القرآن، الصلاة، الأذكار، أو ورد القراءة — تتجدد تلقائياً كل يوم جديد.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .7))),
                            const SizedBox(height: 14),
                            FilledButton.icon(onPressed: () => _editRoutine(context, null), icon: const Icon(Icons.add), label: const Text('إضافة أول روتين')),
                          ]),
                        ),
                      )
                    : ListView(children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: GlassCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                Text('إنجاز اليوم ($today)', style: const TextStyle(fontWeight: FontWeight.w600)),
                                const Spacer(),
                                Text('$rDone / ${rList.length}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              ]),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(value: rList.isEmpty ? 0 : rDone / rList.length, minHeight: 7, borderRadius: BorderRadius.circular(4)),
                            ]),
                          ),
                        ),
                        for (final r in rList) _routineRow(context, r, today),
                      ]),
              )
            else
              Expanded(
                child: allTasks.isEmpty
                    ? Center(child: GlassCard(padding: const EdgeInsets.all(32), child: const Text('ما في مهام بعد. أضف أول مهمة.', style: TextStyle(fontSize: 18))))
                    : ListView(children: [
                        if (todo.isNotEmpty) const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('قيد التنفيذ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
                        for (final t in todo) _taskRow(context, t),
                        if (done.isNotEmpty) const Padding(padding: EdgeInsets.only(top: 12, bottom: 8), child: Text('منجزة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
                        for (final t in done) _taskRow(context, t),
                      ]),
              ),
          ]);
        },
      );
}
