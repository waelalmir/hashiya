import 'package:flutter/material.dart';

/// شرح لماذا OCR الأوفلاين غير متاح بهذه النسخة وكيف تحصل عليه.
Future<void> showOfflineOcrInfo(BuildContext context) => showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('OCR أوفلاين'),
        content: const Text(
          'هذه النسخة ما فيها محرك OCR أوفلاين (بيزيد حجم التطبيق).\n\n'
          'للحصول عليه: افتح GitHub ← تبويب Actions ← Build APK ← Run workflow، فعّل خيار "نسخة OCR" وشغّله، '
          'ثم نزّل الملف hashiya-full-ocr وثبّته بدل النسخة الحالية.\n\n'
          'إلى ذلك الحين استخدم OCR أونلاين (Gemini).',
        ),
        actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('تمام'))],
      ),
    );
