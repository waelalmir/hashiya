import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'media_controller.dart';
import 'theme.dart';

/// يفتح مشغّل صوت/فيديو بشاشة كاملة. يرجع آخر موضع تشغيل (ملي ثانية) ليُحفظ مع التعليق.
Future<int?> openMediaPlayer(BuildContext context, {required String path, required String kind, required String name, int startMs = 0}) {
  return Navigator.of(context).push<int>(MaterialPageRoute(builder: (_) => MediaPlayerPage(path: path, kind: kind, name: name, startMs: startMs)));
}

String _fmt(Duration d) {
  String two(int v) => v.toString().padLeft(2, '0');
  final h = d.inHours;
  return h > 0 ? '$h:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}' : '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
}

class MediaPlayerPage extends StatefulWidget {
  const MediaPlayerPage({super.key, required this.path, required this.kind, required this.name, this.startMs = 0});
  final String path, kind, name;
  final int startMs;
  @override
  State<MediaPlayerPage> createState() => _MediaPlayerPageState();
}

class _MediaPlayerPageState extends State<MediaPlayerPage> {
  final mc = MediaController.I;
  VideoPlayerController? vc;
  bool videoMode = false, ready = false, landscape = false, playing = false;
  double vSpeed = 1;
  String? error;

  @override
  void initState() {
    super.initState();
    // فيديو جديد يُعرض بالصورة. أما لو كان الصوت شغّال بالخلفية لنفس الملف أو الملف صوتي فنستخدم المشغّل الصوتي العام.
    final resumeAudio = mc.active && mc.path == widget.path;
    videoMode = widget.kind == 'video' && !resumeAudio;
    WidgetsBinding.instance.addPostFrameCallback((_) => mc.setPageOpen(true));
    _init(resumeAudio);
  }

  Future<void> _init(bool resumeAudio) async {
    try {
      if (!File(widget.path).existsSync()) throw 'الملف غير موجود';
      if (videoMode) {
        if (mc.active && mc.playing) await mc.toggle(); // نوقف أي صوت آخر قبل الفيديو
        final c = VideoPlayerController.file(File(widget.path));
        vc = c;
        await c.initialize();
        if (widget.startMs > 0) await c.seekTo(Duration(milliseconds: widget.startMs));
        c.addListener(() {
          if (mounted) setState(() => playing = c.value.isPlaying);
        });
      } else {
        await mc.load(widget.path, widget.name, widget.kind, startMs: widget.startMs, autoplay: !resumeAudio);
      }
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) setState(() => error = videoMode ? 'تعذّر تشغيل هذا الفيديو. جرّب ملف mp4 (H.264).' : 'تعذّر تشغيل هذا الملف.');
    }
  }

  Duration get _pos => videoMode ? (vc?.value.position ?? Duration.zero) : mc.pos;
  Duration get _dur => videoMode ? (vc?.value.duration ?? Duration.zero) : mc.dur;
  bool get _playing => videoMode ? playing : mc.playing;
  double get _speed => videoMode ? vSpeed : mc.speed;

  Future<void> _toggle() async {
    if (videoMode) {
      final c = vc!;
      if (c.value.isPlaying) {
        await c.pause();
      } else {
        if (c.value.position >= c.value.duration) await c.seekTo(Duration.zero);
        await c.play();
      }
    } else {
      await mc.toggle();
    }
  }

  Future<void> _seek(Duration d) async {
    var t = d;
    if (t < Duration.zero) t = Duration.zero;
    final end = _dur;
    if (end > Duration.zero && t > end) t = end;
    if (videoMode) {
      await vc?.seekTo(t);
    } else {
      await mc.seek(t);
    }
  }

  Future<void> _setSpeed(double v) async {
    if (videoMode) {
      setState(() => vSpeed = v);
      await vc?.setPlaybackSpeed(v);
    } else {
      await mc.setSpeed(v);
    }
  }

  Future<void> _rotate() async {
    landscape = !landscape;
    await SystemChrome.setPreferredOrientations(landscape ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight] : DeviceOrientation.values);
    await SystemChrome.setEnabledSystemUIMode(landscape ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge);
    if (mounted) setState(() {});
  }

  /// الفيديو ← صوت فقط بالخلفية (يكمل من نفس الموضع) ونرجع للقراءة.
  Future<void> _toBackground() async {
    final ms = _pos.inMilliseconds;
    final c = vc;
    if (c != null) await c.pause();
    await mc.load(widget.path, widget.name, widget.kind, startMs: ms, autoplay: true);
    if (mounted) Navigator.of(context).pop(ms);
  }

  void _exit() {
    Navigator.of(context).pop(_pos.inMilliseconds);
  }

  @override
  void dispose() {
    vc?.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    Future.microtask(() => mc.setPageOpen(false));
    super.dispose();
  }

  Widget _controls() {
    final total = _dur;
    final cur = _pos > total && total > Duration.zero ? total : _pos;
    final max = total.inMilliseconds <= 0 ? 1.0 : total.inMilliseconds.toDouble();
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Slider(value: cur.inMilliseconds.clamp(0, max.toInt()).toDouble(), max: max, onChanged: (v) => _seek(Duration(milliseconds: v.round()))),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_fmt(cur)), Text(_fmt(total))]),
      ),
      const SizedBox(height: 6),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(iconSize: 34, onPressed: () => _seek(_pos - const Duration(seconds: 10)), icon: const Icon(Icons.replay_10_rounded)),
        const SizedBox(width: 8),
        IconButton.filled(iconSize: 44, onPressed: _toggle, icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded)),
        const SizedBox(width: 8),
        IconButton(iconSize: 34, onPressed: () => _seek(_pos + const Duration(seconds: 10)), icon: const Icon(Icons.forward_10_rounded)),
      ]),
      const SizedBox(height: 6),
      Wrap(alignment: WrapAlignment.center, crossAxisAlignment: WrapCrossAlignment.center, spacing: 6, children: [
        const Text('السرعة'),
        DropdownButton<double>(
          value: _speed,
          underline: const SizedBox.shrink(),
          items: [for (final s in const [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]) DropdownMenuItem(value: s, child: Text('×$s'))],
          onChanged: (v) => v == null ? null : _setSpeed(v),
        ),
        if (videoMode) IconButton(tooltip: 'ملء الشاشة', onPressed: _rotate, icon: Icon(landscape ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded)),
        if (videoMode) TextButton.icon(onPressed: _toBackground, icon: const Icon(Icons.headphones_rounded), label: const Text('تشغيل الصوت بالخلفية')),
        if (!videoMode && widget.kind == 'video')
          TextButton.icon(
            onPressed: () async {
              final ms = mc.pos.inMilliseconds;
              await mc.stop();
              if (!mounted) return;
              setState(() {
                ready = false;
                videoMode = true;
              });
              try {
                final c = VideoPlayerController.file(File(widget.path));
                vc = c;
                await c.initialize();
                await c.seekTo(Duration(milliseconds: ms));
                c.addListener(() {
                  if (mounted) setState(() => playing = c.value.isPlaying);
                });
                await c.play();
                if (mounted) setState(() => ready = true);
              } catch (_) {
                if (mounted) setState(() => error = 'تعذّر تشغيل هذا الفيديو.');
              }
            },
            icon: const Icon(Icons.videocam_rounded),
            label: const Text('عرض الفيديو'),
          ),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final Widget body;
    if (error != null) {
      body = Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16))));
    } else if (!ready) {
      body = const Center(child: CircularProgressIndicator());
    } else if (videoMode) {
      final c = vc!;
      final stage = Center(child: AspectRatio(aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio, child: GestureDetector(onTap: _toggle, child: VideoPlayer(c))));
      body = landscape
          ? Row(children: [Expanded(child: stage), SizedBox(width: 300, child: Center(child: SingleChildScrollView(child: _controls())))])
          : Column(children: [Expanded(child: stage), _controls(), const SizedBox(height: 12)]);
    } else {
      body = Column(children: [
        Expanded(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(color: HC.cream.withValues(alpha: .12), shape: BoxShape.circle),
                child: Icon(mc.playing ? Icons.graphic_eq_rounded : Icons.headphones_rounded, size: 64),
              ),
              const SizedBox(height: 18),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: Text(widget.name, textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
              const SizedBox(height: 8),
              Text('يكمل التشغيل بالخلفية أثناء القراءة', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
            ]),
          ),
        ),
        _controls(),
        const SizedBox(height: 16),
      ]);
    }
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _exit();
      },
      child: Scaffold(
        backgroundColor: HC.deep,
        appBar: landscape ? null : AppBar(backgroundColor: HC.deep, leading: IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: _exit), title: Text(widget.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15))),
        body: SafeArea(child: ListenableBuilder(listenable: mc, builder: (context, _) => body)),
      ),
    );
  }
}
