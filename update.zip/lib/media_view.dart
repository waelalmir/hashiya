import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'theme.dart';

/// يشغّل ملف صوت أو فيديو مرفق بتعليق.
Future<void> showMediaSheet(BuildContext context, String path, String kind, String name) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HC.green,
    builder: (c) => SafeArea(child: _MediaSheet(path: path, kind: kind, name: name)),
  );
}

class _MediaSheet extends StatefulWidget {
  const _MediaSheet({required this.path, required this.kind, required this.name});
  final String path, kind, name;
  @override
  State<_MediaSheet> createState() => _MediaSheetState();
}

class _MediaSheetState extends State<_MediaSheet> {
  VideoPlayerController? vc;
  final ap = AudioPlayer();
  bool playing = false;
  double speed = 1;
  Duration pos = Duration.zero, dur = Duration.zero;
  String? error;

  bool get video => widget.kind == 'video';

  @override
  void initState() {
    super.initState();
    if (video) {
      final c = VideoPlayerController.file(File(widget.path));
      vc = c;
      c.initialize().then((_) {
        if (mounted) setState(() {});
      }).catchError((Object e) {
        if (mounted) setState(() => error = 'تعذّر تشغيل الفيديو');
      });
      c.addListener(() {
        if (mounted) setState(() => playing = c.value.isPlaying);
      });
    } else {
      ap.onPositionChanged.listen((p) {
        if (mounted) setState(() => pos = p);
      });
      ap.onDurationChanged.listen((d) {
        if (mounted) setState(() => dur = d);
      });
      ap.onPlayerComplete.listen((_) {
        if (mounted) setState(() => playing = false);
      });
    }
  }

  @override
  void dispose() {
    vc?.dispose();
    ap.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (video) {
      final c = vc!;
      if (c.value.isPlaying) {
        await c.pause();
      } else {
        await c.play();
      }
    } else {
      if (playing) {
        await ap.pause();
        setState(() => playing = false);
      } else {
        await ap.play(DeviceFileSource(widget.path));
        await ap.setPlaybackRate(speed);
        setState(() => playing = true);
      }
    }
  }

  Future<void> _setSpeed(double v) async {
    setState(() => speed = v);
    if (video) {
      await vc?.setPlaybackSpeed(v);
    } else {
      await ap.setPlaybackRate(v);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = vc;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(widget.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        if (error != null) Text(error!),
        if (video && c != null && c.value.isInitialized) ...[
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .4),
            child: AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
          ),
          const SizedBox(height: 8),
          VideoProgressIndicator(c, allowScrubbing: true),
        ] else if (video && error == null)
          const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))
        else if (!video) ...[
          Slider(
            value: dur.inMilliseconds == 0 ? 0 : pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble(),
            max: dur.inMilliseconds == 0 ? 1 : dur.inMilliseconds.toDouble(),
            onChanged: (v) => ap.seek(Duration(milliseconds: v.round())),
          ),
        ],
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          FilledButton.icon(onPressed: _toggle, icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded), label: Text(playing ? 'إيقاف مؤقت' : 'تشغيل')),
          const SizedBox(width: 16),
          DropdownButton<double>(
            value: speed,
            underline: const SizedBox.shrink(),
            items: [for (final s in const [0.75, 1.0, 1.25, 1.5, 2.0]) DropdownMenuItem(value: s, child: Text('×$s'))],
            onChanged: (v) => v == null ? null : _setSpeed(v),
          ),
        ]),
      ]),
    );
  }
}
