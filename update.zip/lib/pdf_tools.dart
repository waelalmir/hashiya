import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:pdfrx/pdfrx.dart';

/// نص صفحة واحدة مع مواضع الحروف.
class PageText {
  PageText(this.text, this.rects, this.w, this.h);
  final String text;
  final List<PdfRect> rects;
  final double w, h;
}

/// نتيجة بحث: الصفحة + سياق قبل/بعد الكلمة + مستطيلات الكلمة (نسب من الصفحة).
class SearchHit {
  SearchHit(this.page, this.before, this.match, this.after, this.rects);
  final int page;
  final String before, match, after;
  final List<ui.Rect> rects;
}

class PdfTools {
  /// تطبيع للبحث: يشيل التشكيل والتطويل، يوحّد الألف والياء والتاء المربوطة، ويحافظ على خريطة المواضع.
  static (String, List<int>) norm(String s) {
    final sb = StringBuffer();
    final map = <int>[];
    for (var i = 0; i < s.length; i++) {
      final c = s.codeUnitAt(i);
      if ((c >= 0x064B && c <= 0x065F) || c == 0x0640 || c == 0x0670 || (c >= 0x200B && c <= 0x200F)) continue;
      var ch = s[i];
      if (c == 0x0623 || c == 0x0625 || c == 0x0622) {
        ch = '\u0627';
      } else if (c == 0x0649) {
        ch = '\u064A';
      } else if (c == 0x0629) {
        ch = '\u0647';
      } else if (c == 10 || c == 13 || c == 9) {
        ch = ' ';
      }
      final lc = ch.toLowerCase();
      sb.write(lc);
      for (var k = 0; k < lc.length; k++) {
        map.add(i);
      }
    }
    return (sb.toString(), map);
  }

  static Future<PageText?> loadPageText(PdfDocument doc, int pageNo) async {
    try {
      final page = doc.pages[pageNo - 1];
      final t = await page.loadText();
      if (t == null) return null;
      return PageText(t.fullText, t.charRects, page.width, page.height);
    } catch (_) {
      return null;
    }
  }

  /// نص صفحة (أو عدة صفحات) كنص عادي. يرجع '' إن كانت مصوّرة.
  static Future<String> pagesText(String path, int from, int to, {int maxChars = 24000}) async {
    PdfDocument? doc;
    try {
      doc = await PdfDocument.openFile(path);
      final sb = StringBuffer();
      for (var p = from; p <= to && p <= doc.pages.length; p++) {
        final pt = await loadPageText(doc, p);
        if (pt != null && pt.text.trim().isNotEmpty) {
          sb.writeln('--- صفحة $p ---');
          sb.writeln(pt.text.trim());
        }
        if (sb.length > maxChars) break;
      }
      final r = sb.toString();
      return r.length > maxChars ? r.substring(0, maxChars) : r;
    } catch (_) {
      return '';
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
  }

  /// يرسم صفحة كصورة PNG (للـ OCR أو للمساعد).
  static Future<Uint8List?> renderPagePng(String path, int pageNo, {int width = 1600}) async {
    PdfDocument? doc;
    try {
      doc = await PdfDocument.openFile(path);
      final page = doc.pages[pageNo - 1];
      final h = (width * page.height / page.width).round();
      final img = await page.render(width: width, height: h);
      if (img == null) return null;
      final ui.Image im = await img.createImage();
      img.dispose();
      final bd = await im.toByteData(format: ui.ImageByteFormat.png);
      im.dispose();
      return bd?.buffer.asUint8List();
    } catch (_) {
      return null;
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
  }

  static ui.Rect _norm(PdfRect r, double pw, double ph) => ui.Rect.fromLTRB(r.left / pw, (ph - r.top) / ph, r.right / pw, (ph - r.bottom) / ph);

  /// يجمع مستطيلات الحروف إلى مستطيل لكل سطر.
  static List<ui.Rect> _lineRects(PageText pt, int s, int e) {
    final out = <ui.Rect>[];
    ui.Rect? cur;
    for (var k = s; k < e && k < pt.rects.length; k++) {
      final r = _norm(pt.rects[k], pt.w, pt.h);
      if (r.width <= 0 || r.height <= 0) continue;
      if (cur != null && (r.center.dy - cur.center.dy).abs() < cur.height * .6) {
        cur = cur.expandToInclude(r);
      } else {
        if (cur != null) out.add(cur);
        cur = r;
      }
    }
    if (cur != null) out.add(cur);
    return out;
  }
}

/// بحث في كل صفحات ملف PDF مع نتائج بسياق.
class PdfSearcher {
  PdfSearcher(this.path);
  final String path;
  PdfDocument? _doc;
  bool foundAnyText = false;

  Future<PdfDocument> _open() async => _doc ??= await PdfDocument.openFile(path);

  Future<void> dispose() async {
    final d = _doc;
    _doc = null;
    if (d != null) await Future.sync(() => d.dispose());
  }

  Future<void> search(
    String query, {
    required bool Function() cancelled,
    required void Function(List<SearchHit> hits, int done, int total) onUpdate,
    int maxHits = 300,
  }) async {
    final nq = PdfTools.norm(query.trim()).$1;
    if (nq.isEmpty) return;
    final doc = await _open();
    final total = doc.pages.length;
    final hits = <SearchHit>[];
    for (var p = 1; p <= total; p++) {
      if (cancelled()) return;
      final pt = await PdfTools.loadPageText(doc, p);
      if (pt != null && pt.text.trim().isNotEmpty) {
        foundAnyText = true;
        final n = PdfTools.norm(pt.text);
        final nt = n.$1, map = n.$2;
        var from = 0;
        while (true) {
          final i = nt.indexOf(nq, from);
          if (i < 0) break;
          from = i + nq.length;
          if (i >= map.length || from - 1 >= map.length) break;
          final s = map[i], e = map[from - 1] + 1;
          final bs = math.max(0, s - 40), ae = math.min(pt.text.length, e + 40);
          String clean(String x) => x.replaceAll(RegExp(r'\s+'), ' ');
          hits.add(SearchHit(p, clean(pt.text.substring(bs, s)), clean(pt.text.substring(s, e)), clean(pt.text.substring(e, ae)), PdfTools._lineRects(pt, s, e)));
          if (hits.length >= maxHits) break;
        }
      }
      if (p % 4 == 0 || p == total || hits.length >= maxHits) onUpdate(List.of(hits), p, total);
      if (hits.length >= maxHits) break;
    }
  }
}
