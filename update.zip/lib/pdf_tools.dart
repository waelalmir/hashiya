import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:pdfrx/pdfrx.dart';
import 'arabic_norm.dart';
import 'ocr_index.dart';

/// نص صفحة واحدة مع مواضع الحروف.
class PageText {
  PageText(this.text, this.rects, this.w, this.h);
  final String text;
  final List<PdfRect> rects;
  final double w, h;
}

/// نتيجة بحث: الصفحة + سياق قبل/بعد الكلمة + مستطيلات الكلمة (نسب من الصفحة).
class SearchHit {
  SearchHit(this.page, this.before, this.match, this.after, this.rects);
  final int page;
  final String before, match, after;
  final List<ui.Rect> rects;
}

class PdfTools {
  /// تطبيع للبحث: يحوّل أشكال العرض العربية لأساسية، يشيل التشكيل والتطويل والمسافات،
  /// يوحّد الألف/الياء/التاء المربوطة/الهمزات والأرقام، ويحافظ على خريطة المواضع للنص الأصلي.
  static (String, List<int>) norm(String s) {
    final sb = StringBuffer();
    final map = <int>[];
    void put(String ch, int at) {
      for (var k = 0; k < ch.length; k++) {
        final c = ch.codeUnitAt(k);
        if (c <= 0x20 || c == 0xA0 || (c >= 0x2000 && c <= 0x200F) || (c >= 0x202A && c <= 0x202F) || c == 0xFEFF || c == 0x3000 || c == 0x061C) continue;
        if ((c >= 0x064B && c <= 0x065F) || c == 0x0640 || c == 0x0670) continue;
        var out = String.fromCharCode(c);
        switch (c) {
          case 0x0622:
          case 0x0623:
          case 0x0625:
          case 0x0671:
            out = '\u0627';
          case 0x0624:
            out = '\u0648';
          case 0x0626:
          case 0x0649:
          case 0x06CC:
          case 0x06D2:
            out = '\u064A';
          case 0x0629:
          case 0x06C1:
          case 0x06BE:
          case 0x06C0:
            out = '\u0647';
          case 0x06A9:
            out = '\u0643';
          default:
            if (c >= 0x0660 && c <= 0x0669) {
              out = String.fromCharCode(0x30 + c - 0x0660);
            } else if (c >= 0x06F0 && c <= 0x06F9) {
              out = String.fromCharCode(0x30 + c - 0x06F0);
            }
        }
        final lo = out.toLowerCase();
        sb.write(lo);
        for (var q = 0; q < lo.length; q++) {
          map.add(at);
        }
      }
    }

    for (var i = 0; i < s.length; i++) {
      final c = s.codeUnitAt(i);
      final pf = kArabicPresentationForms[c];
      put(pf ?? s[i], i);
    }
    return (sb.toString(), map);
  }

  static Future<PageText?> loadPageText(PdfDocument doc, int pageNo) async {
    try {
      final page = doc.pages[pageNo - 1];
      final t = await page.loadText();
      if (t == null) return null;
      return PageText(t.fullText, t.charRects, page.width, page.height);
    } catch (_) {
      return null;
    }
  }

  /// نص صفحة (أو عدة صفحات) كنص عادي. يرجع '' إن كانت مصوّرة.
  static Future<String> pagesText(String path, int from, int to, {int maxChars = 24000}) async {
    PdfDocument? doc;
    try {
      doc = await PdfDocument.openFile(path);
      final sb = StringBuffer();
      for (var p = from; p <= to && p <= doc.pages.length; p++) {
        final pt = await loadPageText(doc, p);
        if (pt != null && pt.text.trim().isNotEmpty) {
          sb.writeln('--- صفحة $p ---');
          sb.writeln(pt.text.trim());
        }
        if (sb.length > maxChars) break;
      }
      final r = sb.toString();
      return r.length > maxChars ? r.substring(0, maxChars) : r;
    } catch (_) {
      return '';
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
  }

  /// يرسم صفحة كصورة PNG (للـ OCR أو للمساعد).
  static Future<Uint8List?> renderPagePng(String path, int pageNo, {int width = 1600}) async {
    PdfDocument? doc;
    try {
      doc = await PdfDocument.openFile(path);
      final page = doc.pages[pageNo - 1];
      final h = (width * page.height / page.width).round();
      final img = await page.render(width: width, height: h);
      if (img == null) return null;
      final ui.Image im = await img.createImage();
      img.dispose();
      final bd = await im.toByteData(format: ui.ImageByteFormat.png);
      im.dispose();
      return bd?.buffer.asUint8List();
    } catch (_) {
      return null;
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
  }

  static Future<Uint8List?> renderPng(PdfDocument doc, int pageNo, {int width = 1400}) async {
    try {
      final page = doc.pages[pageNo - 1];
      final h = (width * page.height / page.width).round();
      final img = await page.render(width: width, height: h);
      if (img == null) return null;
      final ui.Image im = await img.createImage();
      img.dispose();
      final bd = await im.toByteData(format: ui.ImageByteFormat.png);
      im.dispose();
      return bd?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }

  static ui.Rect _norm(PdfRect r, double pw, double ph) => ui.Rect.fromLTRB(r.left / pw, (ph - r.top) / ph, r.right / pw, (ph - r.bottom) / ph);

  /// يجمع مستطيلات الحروف إلى مستطيل لكل سطر.
  static List<ui.Rect> _lineRects(PageText pt, int s, int e) {
    final out = <ui.Rect>[];
    ui.Rect? cur;
    for (var k = s; k < e && k < pt.rects.length; k++) {
      final r = _norm(pt.rects[k], pt.w, pt.h);
      if (r.width <= 0 || r.height <= 0) continue;
      if (cur != null && (r.center.dy - cur.center.dy).abs() < cur.height * .6) {
        cur = cur.expandToInclude(r);
      } else {
        if (cur != null) out.add(cur);
        cur = r;
      }
    }
    if (cur != null) out.add(cur);
    return out;
  }
}

class _Pg {
  _Pg(this.pt, this.nt, this.map);
  final PageText pt;
  final String nt;
  final List<int> map;
}

/// بحث في كل صفحات ملف PDF مع نتائج بسياق. يدعم فهرس OCR للصفحات المصوّرة.
class PdfSearcher {
  PdfSearcher(this.path);
  final String path;
  OcrIndex? index;
  PdfDocument? _doc;
  final _cache = <int, _Pg?>{};
  bool foundAnyText = false;

  Future<PdfDocument> _open() async => _doc ??= await PdfDocument.openFile(path);

  void clearCache() => _cache.clear();

  Future<void> dispose() async {
    final d = _doc;
    _doc = null;
    if (d != null) await Future.sync(() => d.dispose());
  }

  Future<_Pg?> _page(PdfDocument doc, int p) async {
    if (_cache.containsKey(p)) return _cache[p];
    var pt = await PdfTools.loadPageText(doc, p);
    if (pt == null || pt.text.trim().isEmpty) {
      final o = index?.pages[p];
      pt = (o != null && o.trim().isNotEmpty) ? PageText(o, const [], 1, 1) : null;
    }
    _Pg? r;
    if (pt != null) {
      final n = PdfTools.norm(pt.text);
      r = _Pg(pt, n.$1, n.$2);
    }
    _cache[p] = r;
    return r;
  }

  Future<List<SearchHit>> _scan(String nq, PdfDocument doc, bool Function() cancelled, void Function(List<SearchHit>, int, int) onUpdate, int maxHits) async {
    final total = doc.pages.length;
    final hits = <SearchHit>[];
    for (var p = 1; p <= total; p++) {
      if (cancelled()) return hits;
      final pg = await _page(doc, p);
      if (pg != null) {
        foundAnyText = true;
        var from = 0;
        while (true) {
          final i = pg.nt.indexOf(nq, from);
          if (i < 0) break;
          from = i + nq.length;
          if (from - 1 >= pg.map.length) break;
          final s = pg.map[i], e = pg.map[from - 1] + 1;
          final text = pg.pt.text;
          final bs = math.max(0, s - 40), ae = math.min(text.length, e + 40);
          String clean(String x) => x.replaceAll(RegExp(r'\s+'), ' ');
          hits.add(SearchHit(p, clean(text.substring(bs, s)), clean(text.substring(s, math.min(e, text.length))), clean(text.substring(math.min(e, text.length), ae)), PdfTools._lineRects(pg.pt, s, e)));
          if (hits.length >= maxHits) break;
        }
      }
      if (p % 4 == 0 || p == total || hits.length >= maxHits) onUpdate(List.of(hits), p, total);
      if (hits.length >= maxHits) break;
    }
    return hits;
  }

  Future<void> search(
    String query, {
    required bool Function() cancelled,
    required void Function(List<SearchHit> hits, int done, int total) onUpdate,
    int maxHits = 300,
  }) async {
    final nq = PdfTools.norm(query).$1;
    if (nq.isEmpty) return;
    final doc = await _open();
    final hits = await _scan(nq, doc, cancelled, onUpdate, maxHits);
    // بعض الملفات تخزّن النص العربي بترتيب معكوس: جرّب العكس إن لم نجد شيئاً
    if (hits.isEmpty && foundAnyText && !cancelled() && nq.length > 1) {
      final rev = String.fromCharCodes(nq.codeUnits.reversed);
      await _scan(rev, doc, cancelled, onUpdate, maxHits);
    }
  }
}
