import 'dart:ui';

String newId() => DateTime.now().microsecondsSinceEpoch.toString();

class Stroke {
  Stroke({required this.id, required this.page, required this.kind, required this.color, required this.width, required this.pts, this.style = ''});
  final String id;
  final int page;
  final String kind; // pen | hl (مستقيم) | hlf (حر) | arrow | circle
  final String style; // نمط السهم: straight | curveL | curveR | wave | hand | double | dashed
  final int color;
  final double width; // نسبة من عرض الصفحة
  final List<Offset> pts; // إحداثيات مطبّعة 0..1
  Map<String, dynamic> toJson() => {
        'id': id, 'p': page, 'k': kind, 'c': color, 'w': width,
        'pts': [for (final o in pts) [o.dx, o.dy]], 'st': style,
      };
  factory Stroke.fromJson(Map<String, dynamic> j) => Stroke(
        id: j['id'], page: j['p'], kind: j['k'], color: j['c'], width: (j['w'] as num).toDouble(), style: (j['st'] as String?) ?? '',
        pts: [for (final l in j['pts'] as List) Offset((l[0] as num).toDouble(), (l[1] as num).toDouble())],
      );
}

class StickerItem {
  StickerItem({required this.id, required this.page, required this.asset, this.x = .5, this.y = .35, this.size = .22, this.rot = 0, this.text = '', this.locked = false, this.img});
  final String id;
  final int page;
  final String asset; // مثل png/ask.png
  double x, y, size, rot;
  String text;
  bool locked;
  String? img; // مسار صورة (لستيكر الصورة بإطار)
  Map<String, dynamic> toJson() => {'id': id, 'p': page, 'a': asset, 'x': x, 'y': y, 's': size, 'r': rot, 't': text, 'lk': locked, 'im': img};
  factory StickerItem.fromJson(Map<String, dynamic> j) => StickerItem(
        id: j['id'], page: j['p'], asset: j['a'], x: (j['x'] as num).toDouble(), y: (j['y'] as num).toDouble(),
        size: (j['s'] as num).toDouble(), rot: (j['r'] as num).toDouble(), text: j['t'] ?? '', locked: j['lk'] ?? false, img: j['im']);
}

class Pin {
  Pin({required this.id, required this.page, required this.x, required this.y, this.text = '', this.audio, this.media, this.mediaKind, this.mediaName});
  final String id;
  final int page;
  final double x, y;
  String text;
  String? audio;
  String? media; // مسار ملف صوت/فيديو مرفق (نسخة داخل التطبيق)
  String? mediaKind; // audio | video
  String? mediaName; // اسم الملف الأصلي (للتنويه إن فُقد)
  bool get hasMedia => mediaName != null;
  Map<String, dynamic> toJson() => {'id': id, 'p': page, 'x': x, 'y': y, 't': text, 'au': audio, 'md': media, 'mk': mediaKind, 'mn': mediaName};
  factory Pin.fromJson(Map<String, dynamic> j) => Pin(
        id: j['id'], page: j['p'], x: (j['x'] as num).toDouble(), y: (j['y'] as num).toDouble(), text: j['t'] ?? '', audio: j['au'], media: j['md'], mediaKind: j['mk'], mediaName: j['mn']);
}
