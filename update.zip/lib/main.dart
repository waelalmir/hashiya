import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:pdfrx/pdfrx.dart';
import 'app_shell.dart';
import 'data.dart';
import 'mini_player.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await pdfrxFlutterInitialize();
  await Store.load();
  await AppData.load();
  runApp(const HashiyaApp());
}

final navKey = GlobalKey<NavigatorState>();

class HashiyaApp extends StatelessWidget {
  const HashiyaApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
      valueListenable: HC.rev,
      builder: (context, rev, _) => MaterialApp(
        title: 'حاشية',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        navigatorKey: navKey,
        builder: (context, child) => Stack(children: [child ?? const SizedBox.shrink(), Positioned.fill(child: MiniPlayerOverlay(navKey: navKey))]),
        theme: buildTheme(),
        home: AppShell(key: ValueKey(rev)),
      ));
}
