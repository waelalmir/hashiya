import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'ai.dart';
import 'ocr/ocr_engine.dart';
import 'ocr_info.dart';
import 'pdf_tools.dart';
import 'store.dart';
import 'theme.dart';

/// نسخ نص صفحة: مباشرة من الملف، أو OCR (أونلاين عبر Gemini / أوفلاين عبر Tesseract) للصفحات المصوّرة.
Future<void> showPageTextSheet(BuildContext context, Book book, int page) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HC.green,
    builder: (c) => SizedBox(height: MediaQuery.sizeOf(c).height * .8, child: _TextSheet(book: book, page: page)),
  );
}

class _TextSheet extends StatefulWidget {
  const _TextSheet({required this.book, required this.page});
  final Book book;
  final int page;
  @override
  State<_TextSheet> createState() => _TextSheetState();
}

class _TextSheetState extends State<_TextSheet> {
  String text = '';
  String status = 'جاري قراءة نص الصفحة...';
  bool busy = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final t = await PdfTools.pagesText(widget.book.path, widget.page, widget.page);
    if (!mounted) return;
    setState(() {
      busy = false;
      text = t.replaceFirst(RegExp(r'^--- صفحة \d+ ---\s*'), '');
      status = text.trim().isEmpty ? 'لا يوجد نص في هذه الصفحة (مصوّرة). استخدم OCR:' : 'نص الصفحة ${widget.page}:';
    });
  }

  Future<void> _ocr(bool online) async {
    setState(() {
      busy = true;
      status = online ? 'جاري الاستخراج عبر Gemini...' : 'جاري الاستخراج (أوفلاين)...';
    });
    try {
      final png = await PdfTools.renderPagePng(widget.book.path, widget.page);
      if (png == null) throw AiException('تعذّر تحويل الصفحة إلى صورة');
      String r;
      if (online) {
        r = await Gemini.ask(Gemini.ocrPrompt, imagePng: png);
      } else {
        final f = File('${Store.dir.path}/tmp_ocr.png');
        await f.writeAsBytes(png);
        r = await OcrEngine.recognize(f.path);
      }
      if (!mounted) return;
      setState(() {
        text = r.trim();
        status = 'النص المستخرج (راجعه، قد فيه أخطاء):';
      });
    } catch (e) {
      if (mounted) setState(() => status = 'تعذّر الاستخراج: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('نسخ نص الصفحة ${widget.page}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text(status, style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .7))),
          if (busy) const Padding(padding: EdgeInsets.only(top: 8), child: LinearProgressIndicator()),
          const SizedBox(height: 10),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: HC.cream.withValues(alpha: .1), borderRadius: BorderRadius.circular(12)),
              child: SingleChildScrollView(child: SizedBox(width: double.infinity, child: SelectableText(text, style: const TextStyle(fontSize: 15, height: 1.6)))),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton.icon(
              onPressed: text.trim().isEmpty
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: text));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم النسخ')));
                    },
              icon: const Icon(Icons.copy_rounded),
              label: const Text('نسخ الكل'),
            ),
            OutlinedButton.icon(onPressed: busy ? null : () => _ocr(true), icon: const Icon(Icons.cloud_rounded), label: const Text('OCR أونلاين')),
            OutlinedButton.icon(
              onPressed: busy ? null : (OcrEngine.available ? () => _ocr(false) : () => showOfflineOcrInfo(context)),
              icon: const Icon(Icons.offline_bolt_rounded),
              label: Text(OcrEngine.available ? 'OCR أوفلاين' : 'OCR أوفلاين (كيف؟)'),
            ),
          ]),
        ]),
      );
}
