import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'native.dart';

/// مشغّل صوت عام يستمر بالخلفية أثناء القراءة (للصوت وللفيديو بوضع الصوت فقط).
class MediaController extends ChangeNotifier {
  MediaController._() {
    player.onPositionChanged.listen((p) {
      pos = p;
      notifyListeners();
    });
    player.onDurationChanged.listen((d) {
      dur = d;
      notifyListeners();
    });
    player.onPlayerStateChanged.listen((st) {
      final pl = st == PlayerState.playing;
      if (pl != playing) {
        playing = pl;
        _sync();
      }
      notifyListeners();
    });
    player.onPlayerComplete.listen((_) {
      playing = false;
      pos = dur;
      _sync();
      notifyListeners();
    });
  }

  static final MediaController I = MediaController._();

  final AudioPlayer player = AudioPlayer();
  String? path, name;
  String kind = 'audio';
  bool playing = false;
  bool pageOpen = false; // صفحة المشغّل الكاملة مفتوحة حالياً
  Duration pos = Duration.zero, dur = Duration.zero;
  double speed = 1;

  bool get active => path != null;

  void init() {
    Native.onMediaAction = (a) {
      if (a == 'TOGGLE') toggle();
      if (a == 'CLOSE') stop();
    };
  }

  void setPageOpen(bool v) {
    pageOpen = v;
    notifyListeners();
  }

  void _sync() {
    if (path != null) Native.mediaNotify(name ?? '', playing);
  }

  Future<void> load(String p, String n, String k, {int startMs = 0, bool autoplay = true}) async {
    if (path == p) {
      if (startMs > 0 && (pos.inMilliseconds - startMs).abs() > 1500) await seek(Duration(milliseconds: startMs));
      if (autoplay && !playing) await toggle();
      return;
    }
    await player.stop();
    path = p;
    name = n;
    kind = k;
    pos = Duration(milliseconds: startMs);
    dur = Duration.zero;
    playing = false;
    notifyListeners();
    await player.setReleaseMode(ReleaseMode.stop);
    await player.setSource(DeviceFileSource(p));
    final d = await player.getDuration();
    if (d != null) dur = d;
    if (startMs > 0) await player.seek(Duration(milliseconds: startMs));
    await player.setPlaybackRate(speed);
    if (autoplay) await player.resume();
    _sync();
    notifyListeners();
  }

  Future<void> toggle() async {
    if (path == null) return;
    if (playing) {
      await player.pause();
    } else {
      if (dur > Duration.zero && pos >= dur - const Duration(milliseconds: 300)) await player.seek(Duration.zero);
      await player.resume();
      await player.setPlaybackRate(speed);
    }
  }

  Future<void> seek(Duration d) async {
    var t = d;
    if (t < Duration.zero) t = Duration.zero;
    if (dur > Duration.zero && t > dur) t = dur;
    await player.seek(t);
    pos = t;
    notifyListeners();
  }

  Future<void> setSpeed(double v) async {
    speed = v;
    await player.setPlaybackRate(v);
    notifyListeners();
  }

  Future<void> stop() async {
    await player.stop();
    path = null;
    name = null;
    playing = false;
    pos = Duration.zero;
    dur = Duration.zero;
    Native.mediaStop();
    notifyListeners();
  }
}
