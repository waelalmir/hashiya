import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdfrx/pdfrx.dart';
import 'native.dart';

class Book {
  Book({required this.id, required this.title, required this.path, this.lastPage = 1, this.total = 0, this.openedAt = 0, this.cover, this.coverManual = false});
  final String id;
  final String title;
  final String path;
  int lastPage;
  int total;
  int openedAt;
  String? cover; // مسار صورة الغلاف
  bool coverManual; // true = اختارها المستخدم يدوياً
  double get progress => total == 0 ? 0 : (lastPage / total).clamp(0, 1).toDouble();
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'path': path, 'lastPage': lastPage, 'total': total, 'openedAt': openedAt, 'cover': cover, 'coverManual': coverManual};
  factory Book.fromJson(Map<String, dynamic> j) => Book(id: j['id'], title: j['title'], path: j['path'], lastPage: j['lastPage'] ?? 1, total: j['total'] ?? 0, openedAt: j['openedAt'] ?? 0, cover: j['cover'], coverManual: j['coverManual'] ?? false);
}

class Store {
  static final books = ValueNotifier<List<Book>>([]);
  static late Directory _dir;
  static Directory get dir => _dir;
  static File get _db => File('${_dir.path}/library.json');

  static Future<void> load() async {
    _dir = await getApplicationDocumentsDirectory();
    await Directory('${_dir.path}/books').create(recursive: true);
    if (await _db.exists()) {
      final list = jsonDecode(await _db.readAsString()) as List;
      books.value = list.map((e) => Book.fromJson(e as Map<String, dynamic>)).toList();
    }
  }

  static Future<void> _save() async {
    await _db.writeAsString(jsonEncode(books.value.map((b) => b.toJson()).toList()));
    WidgetSync.schedule();
  }

  /// بصمة سريعة للملف (الحجم + عينة من البداية والنهاية) لمطابقة نسخ الكتاب بين الأجهزة.
  static Future<String> fingerprint(String path) async {
    final f = File(path);
    final len = await f.length();
    final raf = await f.open();
    var h = 0x811C9DC5;
    void mix(List<int> bytes) {
      for (final b in bytes) {
        h = ((h ^ b) * 0x01000193) & 0xFFFFFFFF;
      }
    }
    try {
      mix(await raf.read(65536));
      if (len > 131072) {
        await raf.setPosition(len - 65536);
        mix(await raf.read(65536));
      }
    } finally {
      await raf.close();
    }
    return '$len-${h.toRadixString(16)}';
  }

  /// يضيف كتاباً من ملف PDF موجود على الجهاز (يُستخدم عند استيراد ملف .hashiya فيه الكتاب).
  static Future<Book> addFromFile(String src, String title) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final dest = '${_dir.path}/books/$id.pdf';
    await File(dest).parent.create(recursive: true);
    await File(src).copy(dest);
    final b = Book(id: id, title: title, path: dest);
    books.value = [b, ...books.value];
    await _save();
    ensureCover(b);
    return b;
  }

  static Future<Book?> pickAndAdd() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return null;
    final f = r.files.single;
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final dest = '${_dir.path}/books/$id.pdf';
    await File(f.path!).copy(dest);
    final title = f.name.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '').replaceAll('_', ' ');
    final b = Book(id: id, title: title, path: dest);
    books.value = [b, ...books.value];
    await _save();
    ensureCover(b);
    return b;
  }


  // ===== الأغلفة =====
  static final _coverTried = <String>{};
  static Future<void> _coverQ = Future.value();

  static bool hasCover(Book b) => b.cover != null && File(b.cover!).existsSync();

  /// يولّد غلافاً تلقائياً من الصفحة الأولى إن لم يكن للكتاب غلاف (مرة واحدة لكل كتاب).
  static void ensureCover(Book b) {
    if (hasCover(b) || _coverTried.contains(b.id)) return;
    _coverTried.add(b.id);
    _coverQ = _coverQ.then((_) async {
      final path = await _renderFirstPage(b);
      if (path != null) {
        b.cover = path;
        b.coverManual = false;
        await update(b);
      }
    });
  }

  static Future<String?> _renderFirstPage(Book b) async {
    PdfDocument? doc;
    try {
      doc = await PdfDocument.openFile(b.path);
      if (doc.pages.isEmpty) return null;
      final page = doc.pages.first;
      const w = 420;
      final h = (w * page.height / page.width).round();
      final img = await page.render(width: w, height: h);
      if (img == null) return null;
      final ui.Image im = await img.createImage();
      img.dispose();
      final bd = await im.toByteData(format: ui.ImageByteFormat.png);
      im.dispose();
      if (bd == null) return null;
      final dir = Directory('${_dir.path}/covers');
      await dir.create(recursive: true);
      final dest = '${dir.path}/${b.id}_auto.png';
      await File(dest).writeAsBytes(bd.buffer.asUint8List());
      return dest;
    } catch (_) {
      return null;
    } finally {
      final d = doc;
      if (d != null) await Future.sync(() => d.dispose());
    }
  }

  /// غلاف يدوي من صورة يختارها المستخدم.
  static Future<bool> pickManualCover(Book b) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return false;
    final src = r.files.single.path!;
    final dir = Directory('${_dir.path}/covers');
    await dir.create(recursive: true);
    final dot = src.lastIndexOf('.');
    final ext = dot > src.lastIndexOf('/') ? src.substring(dot) : '.jpg';
    final dest = '${dir.path}/${b.id}_m${DateTime.now().millisecondsSinceEpoch}$ext';
    await File(src).copy(dest);
    await _deleteCoverFile(b);
    b.cover = dest;
    b.coverManual = true;
    await update(b);
    return true;
  }

  /// يلغي الغلاف اليدوي ويرجع للغلاف التلقائي (الصفحة الأولى).
  static Future<void> resetCover(Book b) async {
    await _deleteCoverFile(b);
    b.cover = null;
    b.coverManual = false;
    _coverTried.remove(b.id);
    await update(b);
    ensureCover(b);
  }

  static Future<void> _deleteCoverFile(Book b) async {
    if (b.cover == null) return;
    try {
      await File(b.cover!).delete();
    } catch (_) {}
  }

  static Future<void> update(Book b) async {
    books.value = List.of(books.value);
    await _save();
  }

  static Future<void> remove(Book b) async {
    final f = File(b.path);
    if (await f.exists()) await f.delete();
    await _deleteCoverFile(b);
    books.value = books.value.where((x) => x.id != b.id).toList();
    await _save();
  }
}
