import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'paper_stickers.dart';
import 'theme.dart';

/// يعيد خريطة وصف الستيكر المختار:
/// pack: {id:'pack', pack, index} | ورق: {id:'paper', style, text} | صورة: {id:'photo', style} | كلاسيك: عنصر manifest
Future<Map<String, dynamic>?> pickSticker(BuildContext context) async {
  final list = (jsonDecode(await rootBundle.loadString('assets/stickers/manifest.json')) as List).cast<Map<String, dynamic>>();
  if (!context.mounted) return null;
  final packKeys = kStickerPacks.keys.toList();
  return showModalBottomSheet<Map<String, dynamic>>(
    context: context,
    backgroundColor: HC.green,
    isScrollControlled: true,
    builder: (c) => SizedBox(
      height: MediaQuery.of(c).size.height * .78,
      child: DefaultTabController(
        length: packKeys.length + 4,
        child: Column(children: [
          const Padding(padding: EdgeInsets.fromLTRB(16, 14, 16, 4), child: Text('الستيكرات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600))),
          TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            labelColor: HC.cream,
            unselectedLabelColor: HC.cream.withValues(alpha: .6),
            indicatorColor: HC.cream,
            dividerColor: Colors.transparent,
            tabs: [
              for (final k in packKeys) Tab(text: kStickerPacks[k]!.$1),
              const Tab(text: 'ورق: جمل جاهزة'),
              const Tab(text: 'ورق: فارغة'),
              const Tab(text: 'صورة بإطار'),
              const Tab(text: 'كلاسيك'),
            ],
          ),
          Expanded(
            child: TabBarView(children: [
              for (final k in packKeys)
                _grid(
                  count: kStickerPacks[k]!.$2.length,
                  ratio: k == 'quran' || k == 'plan' ? .55 : .78,
                  builder: (w, i) => StyledPackSticker(def: kStickerPacks[k]!.$2[i], width: w),
                  onTap: (i) => Navigator.pop(c, {'id': 'pack', 'pack': k, 'index': i}),
                ),
              _grid(
                count: kPhrases.length,
                builder: (w, i) => PaperNote(styleIndex: i, text: kPhrases[i], width: w),
                onTap: (i) => Navigator.pop(c, {'id': 'paper', 'style': i % kPaperStyles.length, 'text': kPhrases[i]}),
              ),
              _grid(
                count: kPaperStyles.length,
                builder: (w, i) => PaperNote(styleIndex: i, text: '', hint: 'اكتب هنا', width: w),
                onTap: (i) => Navigator.pop(c, {'id': 'paper', 'style': i, 'text': '', 'blank': true}),
              ),
              _grid(
                count: kPaperStyles.length,
                builder: (w, i) => PhotoNote(styleIndex: i, width: w),
                onTap: (i) => Navigator.pop(c, {'id': 'photo', 'style': i}),
                ratio: 1.12,
              ),
              GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 170, mainAxisSpacing: 12, crossAxisSpacing: 12),
                itemCount: list.length,
                itemBuilder: (c2, i) {
                  final e = list[i];
                  return InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => Navigator.pop(c, e),
                    child: Container(
                      decoration: BoxDecoration(color: HC.cream.withValues(alpha: .08), borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.all(8),
                      child: Image.asset('assets/stickers/${e['file']}', fit: BoxFit.contain),
                    ),
                  );
                },
              ),
            ]),
          ),
        ]),
      ),
    ),
  );
}

Widget _grid({required int count, required Widget Function(double w, int i) builder, required void Function(int) onTap, double ratio = .8}) {
  return GridView.builder(
    padding: const EdgeInsets.all(14),
    gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 175, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1 / ratio),
    itemCount: count,
    itemBuilder: (c, i) => InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => onTap(i),
      child: LayoutBuilder(builder: (c, box) => Center(child: builder(box.maxWidth - 10, i))),
    ),
  );
}

Future<String?> editText(BuildContext context, String initial, {String title = 'نص الستيكر'}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true, maxLines: 6, minLines: 1),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('حفظ')),
      ],
    ),
  );
}
