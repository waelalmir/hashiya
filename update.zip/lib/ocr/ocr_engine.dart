/// محرك OCR أوفلاين. في النسخة العادية غير متوفر.
/// نسخة hashiya-full-ocr (التجريبية) تستبدل هذا الملف بمحرك Tesseract.
class OcrEngine {
  static const available = false;
  static Future<String> recognize(String imagePath) async => throw UnsupportedError('OCR أوفلاين غير متوفر في هذه النسخة');
}
