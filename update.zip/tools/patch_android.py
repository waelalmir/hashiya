import pathlib
import re

m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
if m.exists():
    s = m.read_text(encoding='utf-8')
    if 'RECORD_AUDIO' not in s:
        perms = ('    <uses-permission android:name="android.permission.INTERNET"/>\n'
                 '    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n')
        s = s.replace('<application', perms + '    <application', 1)
    if 'android:scheme="https"' not in s:
        q = '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>'
        if '<queries>' in s:
            s = s.replace('<queries>', '<queries>\n        ' + q, 1)
        else:
            s = s.replace('</manifest>', '    <queries>\n        ' + q + '\n    </queries>\n</manifest>', 1)
    s = re.sub(r'android:label="[^"]*"', 'android:label="حاشية"', s, count=1)
    m.write_text(s, encoding='utf-8')
else:
    print('AndroidManifest.xml not found - skipped')

for g in ['android/app/build.gradle.kts', 'android/app/build.gradle']:
    p = pathlib.Path(g)
    if p.exists():
        t = p.read_text(encoding='utf-8')
        t = t.replace('minSdk = flutter.minSdkVersion', 'minSdk = 24').replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 24')
        p.write_text(t, encoding='utf-8')

# ================= v1.7: إشعارات التركيز + ودجتات الشاشة الرئيسية =================
import glob

def _write(path, text):
    pth = pathlib.Path(path)
    pth.parent.mkdir(parents=True, exist_ok=True)
    pth.write_text(text, encoding='utf-8')

mains = glob.glob('android/app/src/main/**/MainActivity.kt', recursive=True)
if mains:
    main_kt = pathlib.Path(mains[0])
    pkg = re.search(r'^package\s+([\w.]+)', main_kt.read_text(encoding='utf-8'), re.M).group(1)
    kdir = main_kt.parent

    _write(kdir / 'MainActivity.kt', f"""package {pkg}

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    private var channel: MethodChannel? = null
    private var launchBook: String? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        launchBook = intent?.getStringExtra("book")
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "hashiya/native")
        channel = ch
        ch.setMethodCallHandler {{ call, result ->
            when (call.method) {{
                "requestNotifications" -> {{
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {{
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
                    }}
                    result.success(null)
                }}
                "scheduleFocus" -> {{
                    val at = (call.argument<Number>("at") ?: 0).toLong()
                    val title = call.argument<String>("title") ?: ""
                    val body = call.argument<String>("body") ?: ""
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val i = Intent(this, FocusReceiver::class.java)
                    i.putExtra("title", title)
                    i.putExtra("body", body)
                    val pi = PendingIntent.getBroadcast(this, 4001, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    result.success(null)
                }}
                "cancelFocus" -> {{
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val pi = PendingIntent.getBroadcast(this, 4001, Intent(this, FocusReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    am.cancel(pi)
                    result.success(null)
                }}
                "updateWidgets" -> {{
                    val json = call.argument<String>("json") ?: "{{}}"
                    getSharedPreferences("hashiya_widgets", Context.MODE_PRIVATE).edit().putString("data", json).apply()
                    WidgetData.refreshAll(this)
                    result.success(null)
                }}
                "launchBook" -> {{
                    val b = launchBook
                    launchBook = null
                    result.success(b)
                }}
                else -> result.notImplemented()
            }}
        }}
    }}

    override fun onNewIntent(intent: Intent) {{
        super.onNewIntent(intent)
        val b = intent.getStringExtra("book")
        if (b != null) {{
            launchBook = null
            channel?.invokeMethod("openBook", b)
        }}
    }}
}}
""")

    _write(kdir / 'FocusReceiver.kt', f"""package {pkg}

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class FocusReceiver : BroadcastReceiver() {{
    override fun onReceive(ctx: Context, intent: Intent) {{
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {{
            nm.createNotificationChannel(NotificationChannel("focus", "جلسات التركيز", NotificationManager.IMPORTANCE_HIGH))
        }}
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, "focus") else Notification.Builder(ctx)
        b.setContentTitle(intent.getStringExtra("title") ?: "حاشية")
        b.setContentText(intent.getStringExtra("body") ?: "")
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
        b.setContentIntent(open)
        b.setAutoCancel(true)
        nm.notify(4001, b.build())
    }}
}}
""")

    _write(kdir / 'Widgets.kt', f"""package {pkg}

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject

object WidgetData {{
    fun load(ctx: Context): JSONObject {{
        return try {{
            JSONObject(ctx.getSharedPreferences("hashiya_widgets", Context.MODE_PRIVATE).getString("data", "{{}}") ?: "{{}}")
        }} catch (e: Exception) {{
            JSONObject()
        }}
    }}

    fun open(ctx: Context, book: String?): PendingIntent {{
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        if (book != null) i.putExtra("book", book)
        return PendingIntent.getActivity(ctx, (book ?: "none").hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }}

    fun decodeCover(path: String?): Bitmap? {{
        if (path == null) return null
        return try {{
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > 320) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            BitmapFactory.decodeFile(path, o2)
        }} catch (e: Exception) {{
            null
        }}
    }}

    fun refreshAll(ctx: Context) {{
        val mgr = AppWidgetManager.getInstance(ctx)
        val classes = listOf(LastBookWidget::class.java, TodoWidget::class.java, StatsWidget::class.java)
        for (cls in classes) {{
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) {{
                val intent = Intent(ctx, cls)
                intent.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                ctx.sendBroadcast(intent)
            }}
        }}
    }}
}}

class LastBookWidget : AppWidgetProvider() {{
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {{
        val d = WidgetData.load(ctx)
        val bg = d.optLong("bg", 0xFF064A44).toInt()
        val fg = d.optLong("fg", 0xFFEDE5D3).toInt()
        val book = d.optJSONObject("book")
        val v = RemoteViews(ctx.packageName, R.layout.widget_lastbook)
        v.setInt(R.id.bg, "setColorFilter", bg)
        v.setInt(R.id.btnbg, "setColorFilter", fg)
        v.setTextColor(R.id.label, fg)
        v.setTextColor(R.id.title, fg)
        v.setTextColor(R.id.sub, fg)
        v.setTextColor(R.id.btntext, bg)
        if (book == null) {{
            v.setTextViewText(R.id.title, "لا يوجد كتاب بعد")
            v.setTextViewText(R.id.sub, "افتح حاشية وأضف ملف PDF")
            v.setViewVisibility(R.id.cover, View.GONE)
            v.setViewVisibility(R.id.btn, View.GONE)
            v.setOnClickPendingIntent(R.id.root, WidgetData.open(ctx, null))
        }} else {{
            val total = book.optInt("total", 0)
            v.setTextViewText(R.id.title, book.optString("title"))
            v.setTextViewText(R.id.sub, "صفحة " + book.optInt("page", 1) + (if (total > 0) " من " + total else ""))
            val bmp = WidgetData.decodeCover(if (book.isNull("cover")) null else book.optString("cover"))
            if (bmp != null) {{
                v.setImageViewBitmap(R.id.cover, bmp)
                v.setViewVisibility(R.id.cover, View.VISIBLE)
            }} else {{
                v.setViewVisibility(R.id.cover, View.GONE)
            }}
            v.setViewVisibility(R.id.btn, View.VISIBLE)
            val pi = WidgetData.open(ctx, book.optString("id"))
            v.setOnClickPendingIntent(R.id.btn, pi)
            v.setOnClickPendingIntent(R.id.root, pi)
        }}
        for (id in ids) mgr.updateAppWidget(id, v)
    }}
}}

class TodoWidget : AppWidgetProvider() {{
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {{
        val d = WidgetData.load(ctx)
        val bg = d.optLong("bg", 0xFF064A44).toInt()
        val fg = d.optLong("fg", 0xFFEDE5D3).toInt()
        val v = RemoteViews(ctx.packageName, R.layout.widget_todo)
        v.setInt(R.id.bg, "setColorFilter", bg)
        val pending = d.optInt("pending", 0)
        v.setTextColor(R.id.title, fg)
        v.setTextViewText(R.id.title, "المهام (" + pending + ")")
        val tasks = d.optJSONArray("tasks")
        val rows = intArrayOf(R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5)
        for (i in rows.indices) {{
            v.setTextColor(rows[i], fg)
            if (tasks != null && i < tasks.length()) {{
                v.setTextViewText(rows[i], "• " + tasks.optString(i))
                v.setViewVisibility(rows[i], View.VISIBLE)
            }} else {{
                v.setViewVisibility(rows[i], View.GONE)
            }}
        }}
        if (pending == 0) {{
            v.setTextViewText(R.id.t1, "لا توجد مهام معلّقة 🎉")
            v.setViewVisibility(R.id.t1, View.VISIBLE)
        }}
        v.setTextColor(R.id.more, fg)
        if (pending > 5) {{
            v.setTextViewText(R.id.more, "+" + (pending - 5) + " أخرى")
            v.setViewVisibility(R.id.more, View.VISIBLE)
        }} else {{
            v.setViewVisibility(R.id.more, View.GONE)
        }}
        v.setOnClickPendingIntent(R.id.root, WidgetData.open(ctx, null))
        for (id in ids) mgr.updateAppWidget(id, v)
    }}
}}

class StatsWidget : AppWidgetProvider() {{
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {{
        val d = WidgetData.load(ctx)
        val bg = d.optLong("bg", 0xFF064A44).toInt()
        val fg = d.optLong("fg", 0xFFEDE5D3).toInt()
        val v = RemoteViews(ctx.packageName, R.layout.widget_stats)
        v.setInt(R.id.bg, "setColorFilter", bg)
        val vals = intArrayOf(R.id.v1, R.id.v2, R.id.v3, R.id.v4)
        val labels = intArrayOf(R.id.l1, R.id.l2, R.id.l3, R.id.l4)
        val data = arrayOf(
            d.optInt("readMin", 0).toString() + " د",
            d.optInt("focusMin", 0).toString() + " د",
            d.optInt("streak", 0).toString(),
            d.optInt("pending", 0).toString()
        )
        for (i in vals.indices) {{
            v.setTextColor(vals[i], fg)
            v.setTextColor(labels[i], fg)
            v.setTextViewText(vals[i], data[i])
        }}
        v.setOnClickPendingIntent(R.id.root, WidgetData.open(ctx, null))
        for (id in ids) mgr.updateAppWidget(id, v)
    }}
}}
""")

    res = pathlib.Path('android/app/src/main/res')
    _write(res / 'drawable/widget_bg.xml', '<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle"><solid android:color="#FFFFFFFF"/><corners android:radius="22dp"/></shape>\n')
    _write(res / 'drawable/widget_btn.xml', '<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle"><solid android:color="#FFFFFFFF"/><corners android:radius="18dp"/></shape>\n')

    head = '<?xml version="1.0" encoding="utf-8"?>\n<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/root" android:layout_width="match_parent" android:layout_height="match_parent" android:layoutDirection="rtl">\n    <ImageView android:id="@+id/bg" android:layout_width="match_parent" android:layout_height="match_parent" android:scaleType="fitXY" android:src="@drawable/widget_bg"/>\n'
    _write(res / 'layout/widget_lastbook.xml', head + """    <LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="horizontal" android:padding="12dp" android:gravity="center_vertical">
        <ImageView android:id="@+id/cover" android:layout_width="60dp" android:layout_height="84dp" android:scaleType="centerCrop" android:layout_marginEnd="12dp"/>
        <LinearLayout android:layout_width="0dp" android:layout_height="wrap_content" android:layout_weight="1" android:orientation="vertical">
            <TextView android:id="@+id/label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="متابعة القراءة" android:textSize="11sp"/>
            <TextView android:id="@+id/title" android:layout_width="match_parent" android:layout_height="wrap_content" android:maxLines="2" android:ellipsize="end" android:textSize="15sp" android:textStyle="bold"/>
            <TextView android:id="@+id/sub" android:layout_width="wrap_content" android:layout_height="wrap_content" android:textSize="12sp"/>
            <FrameLayout android:id="@+id/btn" android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="8dp">
                <ImageView android:id="@+id/btnbg" android:layout_width="match_parent" android:layout_height="match_parent" android:scaleType="fitXY" android:src="@drawable/widget_btn"/>
                <TextView android:id="@+id/btntext" android:layout_width="wrap_content" android:layout_height="wrap_content" android:paddingLeft="20dp" android:paddingRight="20dp" android:paddingTop="6dp" android:paddingBottom="6dp" android:text="تابع" android:textSize="13sp" android:textStyle="bold"/>
            </FrameLayout>
        </LinearLayout>
    </LinearLayout>
</FrameLayout>
""")
    rows = ''.join(f'        <TextView android:id="@+id/t{i}" android:layout_width="match_parent" android:layout_height="wrap_content" android:maxLines="1" android:ellipsize="end" android:textSize="13sp" android:layout_marginTop="3dp"/>\n' for i in range(1, 6))
    _write(res / 'layout/widget_todo.xml', head + """    <LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:padding="14dp">
        <TextView android:id="@+id/title" android:layout_width="match_parent" android:layout_height="wrap_content" android:textSize="15sp" android:textStyle="bold"/>
""" + rows + """        <TextView android:id="@+id/more" android:layout_width="wrap_content" android:layout_height="wrap_content" android:textSize="11sp" android:layout_marginTop="4dp"/>
    </LinearLayout>
</FrameLayout>
""")
    def cell(v, l, label):
        return f"""            <LinearLayout android:layout_width="0dp" android:layout_height="wrap_content" android:layout_weight="1" android:orientation="vertical" android:gravity="center">
                <TextView android:id="@+id/{v}" android:layout_width="wrap_content" android:layout_height="wrap_content" android:textSize="20sp" android:textStyle="bold"/>
                <TextView android:id="@+id/{l}" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="{label}" android:textSize="11sp"/>
            </LinearLayout>
"""
    _write(res / 'layout/widget_stats.xml', head + """    <LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:padding="12dp" android:gravity="center">
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal">
""" + cell('v1','l1','قراءة اليوم') + cell('v2','l2','تركيز اليوم') + """        </LinearLayout>
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:layout_marginTop="10dp">
""" + cell('v3','l3','أيام متتالية') + cell('v4','l4','مهام متبقية') + """        </LinearLayout>
    </LinearLayout>
</FrameLayout>
""")
    for name, w, h, lay in [('lastbook', 250, 110, 'widget_lastbook'), ('todo', 180, 180, 'widget_todo'), ('stats', 180, 110, 'widget_stats')]:
        _write(res / f'xml/widget_{name}_info.xml', f'<?xml version="1.0" encoding="utf-8"?>\n<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="{w}dp" android:minHeight="{h}dp" android:updatePeriodMillis="0" android:initialLayout="@layout/{lay}" android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen"/>\n')

    if m.exists():
        s = m.read_text(encoding='utf-8')
        if 'FocusReceiver' not in s:
            if 'POST_NOTIFICATIONS' not in s:
                s = s.replace('<application', '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application', 1)
            def rcv(cls, label):
                res_name = {'LastBookWidget': 'widget_lastbook_info', 'TodoWidget': 'widget_todo_info', 'StatsWidget': 'widget_stats_info'}[cls]
                return (f'        <receiver android:name=".{cls}" android:exported="true" android:label="{label}">\n'
                        '            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter>\n'
                        f'            <meta-data android:name="android.appwidget.provider" android:resource="@xml/{res_name}"/>\n'
                        '        </receiver>\n')
            block = ('        <receiver android:name=".FocusReceiver" android:exported="false"/>\n'
                     + rcv('LastBookWidget', 'حاشية · آخر كتاب') + rcv('TodoWidget', 'حاشية · المهام') + rcv('StatsWidget', 'حاشية · الإحصائيات'))
            s = s.replace('</application>', block + '    </application>', 1)
            m.write_text(s, encoding='utf-8')
    print('native widgets + notifications patched, package', pkg)
else:
    print('MainActivity.kt not found - native patch skipped')

print('patch done')
