import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'glass.dart';
import 'reader_page.dart';
import 'store.dart';
import 'theme.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  Future<void> _add(BuildContext context) async {
    final b = await Store.pickAndAdd();
    if (b != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تمت إضافة: ${b.title}')));
    }
  }


  Future<void> _setCover(BuildContext context, Book b) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return;
    try {
      final dir = Directory('${Store.dir.path}/covers');
      await dir.create(recursive: true);
      final name = r.files.single.name;
      final ext = name.contains('.') ? name.substring(name.lastIndexOf('.')) : '.jpg';
      final dest = '${dir.path}/${b.id}_cover${ext.replaceAll(RegExp(r'[^.a-zA-Z0-9]'), '')}';
      await File(r.files.single.path!).copy(dest);
      final old = b.coverPath;
      b.coverPath = dest;
      await Store.update(b);
      if (old != null && old != dest) {
        try { await File(old).delete(); } catch (_) {}
      }
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تغيير غلاف الكتاب')));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر تغيير الغلاف: $e')));
    }
  }

  Future<void> _confirmDelete(BuildContext context, Book b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف الكتاب؟'),
        content: Text(b.title),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) await Store.remove(b);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        PageHeader(title: 'المكتبة', actions: [
          FilledButton.icon(onPressed: () => _add(context), icon: const Icon(Icons.add), label: const Text('إضافة PDF')),
        ]),
        Expanded(
          child: ValueListenableBuilder<List<Book>>(
            valueListenable: Store.books,
            builder: (context, books, _) {
              if (books.isEmpty) {
                return Center(
                  child: GlassCard(
                    padding: const EdgeInsets.all(40),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('مكتبتك فارغة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Text('أضف أول ملف PDF لتبدأ', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
                      const SizedBox(height: 20),
                      FilledButton(onPressed: () => _add(context), child: const Text('+ إضافة PDF')),
                    ]),
                  ),
                );
              }
              return GridView.builder(
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: isCompact(context) ? 165 : 200, childAspectRatio: .68, crossAxisSpacing: 14, mainAxisSpacing: 14),
                itemCount: books.length,
                itemBuilder: (context, i) {
                  final b = books[i];
                  return GestureDetector(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(book: b))),
                    onLongPress: () => _confirmDelete(context, b),
                    child: GlassCard(
                      padding: const EdgeInsets.all(12),
                      radius: 18,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Expanded(
                          child: Stack(children: [
                            Positioned.fill(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: b.coverPath != null && File(b.coverPath!).existsSync()
                                    ? Image.file(File(b.coverPath!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.picture_as_pdf_rounded, size: 40)))
                                    : Container(
                                        decoration: BoxDecoration(color: HC.cream.withValues(alpha: .14), borderRadius: BorderRadius.circular(10)),
                                        child: const Center(child: Icon(Icons.picture_as_pdf_rounded, size: 40)),
                                      ),
                              ),
                            ),
                            Positioned(
                              top: 4,
                              right: 4,
                              child: Material(
                                color: Colors.black.withValues(alpha: .55),
                                shape: const CircleBorder(),
                                child: IconButton(
                                  visualDensity: VisualDensity.compact,
                                  tooltip: 'تغيير الغلاف',
                                  onPressed: () => _setCover(context, b),
                                  icon: const Icon(Icons.photo_camera_back_rounded, size: 18),
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ]),
                        ),
                        const SizedBox(height: 10),
                        Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(value: b.progress, minHeight: 5, borderRadius: BorderRadius.circular(3)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]);
}
