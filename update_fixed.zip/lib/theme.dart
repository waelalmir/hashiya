import 'package:flutter/material.dart';
import 'data.dart';

/// ألوان الثيم المختار. HC تبقي أسماء الألوان المستخدمة في بقية الواجهة كما هي.
class HC {
  static Color get green {
    switch (AppData.themeId.value) {
      case 'navy': return const Color(0xFF23395B);
      case 'burgundy': return const Color(0xFF6E263B);
      case 'charcoal': return const Color(0xFF30343B);
      case 'blue': return const Color(0xFF2D5267);
      case 'custom': return Color(AppData.customGreen.value);
      default: return const Color(0xFF064A44);
    }
  }

  static Color get cream {
    switch (AppData.themeId.value) {
      case 'navy': return const Color(0xFFE9DFC7);
      case 'burgundy': return const Color(0xFFF5EBDD);
      case 'charcoal': return const Color(0xFFF3C969);
      case 'blue': return const Color(0xFFE2EDF0);
      case 'custom': return Color(AppData.customCream.value);
      default: return const Color(0xFFEDE5D3);
    }
  }

  static Color get deep {
    switch (AppData.themeId.value) {
      case 'navy': return const Color(0xFF101B2D);
      case 'burgundy': return const Color(0xFF2A1019);
      case 'charcoal': return const Color(0xFF17191D);
      case 'blue': return const Color(0xFF142B37);
      case 'custom': return Color(AppData.customDeep.value);
      default: return const Color(0xFF032B27);
    }
  }

  static Color get mid => Color.lerp(green, deep, .25)!;
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      fontFamily: 'IBMPlexSansArabic',
      scaffoldBackgroundColor: HC.deep,
      colorScheme: ColorScheme.dark(
        primary: HC.cream,
        onPrimary: HC.green,
        secondary: HC.cream,
        surface: HC.green,
        onSurface: HC.cream,
      ),
    );
