const kVersion = '1.6';
const kBuild = String.fromEnvironment('BUILD_ID', defaultValue: 'محلي');
