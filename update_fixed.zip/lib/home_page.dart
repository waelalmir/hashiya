import 'dart:io';
import 'package:flutter/material.dart';
import 'data.dart';
import 'glass.dart';
import 'reader_page.dart';
import 'store.dart';
import 'theme.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.onOpenLibrary});
  final VoidCallback onOpenLibrary;

  Widget _stat(String label, String value, IconData icon) => GlassCard(
        child: Row(children: [
          Icon(icon, size: 28, color: HC.cream.withValues(alpha: .8)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65))),
              const SizedBox(height: 4),
              Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([Store.books, AppData.reading, AppData.sessions, AppData.tasks]),
        builder: (context, _) {
          final compact = isCompact(context);
          final recent = [...Store.books.value]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
          final last = recent.isEmpty ? null : recent.first;
          final today = AppData.dayKey();
          final pending = AppData.tasks.value.where((t) => !t.done).length;

          final cont = GlassCard(
            child: last == null
                ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('ابدأ من هنا', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    const Text('أضف أول ملف PDF إلى مكتبتك'),
                    const SizedBox(height: 14),
                    FilledButton(onPressed: onOpenLibrary, child: const Text('فتح المكتبة')),
                  ])
                : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (last.coverPath != null && File(last.coverPath!).existsSync()) ...[
                      ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(last.coverPath!), width: 78, height: 112, fit: BoxFit.cover)),
                      const SizedBox(width: 12),
                    ],
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('متابعة القراءة', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
                      const SizedBox(height: 6),
                      Text(last.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(value: last.progress, minHeight: 6, borderRadius: BorderRadius.circular(3)),
                      const SizedBox(height: 6),
                      Text('صفحة ${last.lastPage} من ${last.total == 0 ? '—' : last.total}', style: TextStyle(fontSize: 13, color: HC.cream.withValues(alpha: .65))),
                      const SizedBox(height: 14),
                      FilledButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(book: last))), child: const Text('متابعة')),
                    ])),
                  ]),
          );
          final ai = GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('المساعد الذكي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text('بحث وملخصات واختبارات', style: TextStyle(color: HC.cream.withValues(alpha: .65))),
              const SizedBox(height: 10),
              Chip(label: const Text('قريباً'), side: BorderSide(color: HC.cream.withValues(alpha: .3))),
            ]),
          );
          final stats = [
            _stat('قراءة اليوم', AppData.fmtDuration(AppData.secondsOn(today)), Icons.auto_stories_rounded),
            _stat('تركيز اليوم', '${AppData.focusMinutesOn(today)} د', Icons.timer_rounded),
            _stat('مهام متبقية', '$pending', Icons.checklist_rounded),
            _stat('أيام متتالية', '${AppData.streak}', Icons.local_fire_department_rounded),
          ];

          return SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const PageHeader(title: 'الرئيسية'),
              if (compact) ...[cont, const SizedBox(height: 12), ai] else Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 3, child: cont), const SizedBox(width: 16), Expanded(flex: 2, child: ai)]),
              const SizedBox(height: 16),
              compact
                  ? Column(children: [
                      Row(children: [Expanded(child: stats[0]), const SizedBox(width: 12), Expanded(child: stats[1])]),
                      const SizedBox(height: 12),
                      Row(children: [Expanded(child: stats[2]), const SizedBox(width: 12), Expanded(child: stats[3])]),
                    ])
                  : Row(children: [for (var i = 0; i < 4; i++) ...[if (i > 0) const SizedBox(width: 16), Expanded(child: stats[i])]]),
              const SizedBox(height: 16),
              GlassCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.checklist_rounded),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('قائمة المهام', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
                    Text('${AppData.tasks.value.where((t) => !t.done).length} متبقية', style: TextStyle(color: HC.cream.withValues(alpha: .65), fontSize: 12)),
                  ]),
                  const SizedBox(height: 8),
                  if (AppData.tasks.value.where((t) => !t.done).isEmpty)
                    Text('ما عندك مهام معلّقة حالياً', style: TextStyle(color: HC.cream.withValues(alpha: .65)))
                  else
                    for (final task in AppData.tasks.value.where((t) => !t.done).take(3))
                      CheckboxListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        value: task.done,
                        title: Text(task.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                        onChanged: (v) {
                          task.done = v ?? false;
                          AppData.setTasks(List.of(AppData.tasks.value));
                        },
                      ),
                ]),
              ),
            ]),
          );
        },
      );
}
