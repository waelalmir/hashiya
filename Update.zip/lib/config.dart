/// رابط تنزيل نموذج التفريغ الصوتي (whisper.cpp). غيّره لرابطك الخاص إن أردت.
const kModelHost = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main';
const kModelFile = 'ggml-small.bin';
const kModelUrl = '$kModelHost/$kModelFile';
