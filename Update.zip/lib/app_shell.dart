import 'package:flutter/material.dart';
import 'data.dart';
import 'focus_page.dart';
import 'glass.dart';
import 'home_page.dart';
import 'library_page.dart';
import 'settings_page.dart';
import 'stats_page.dart';
import 'tasks_page.dart';
import 'theme.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  static const items = [
    ('الرئيسية', Icons.home_rounded),
    ('المكتبة', Icons.auto_stories_rounded),
    ('الإحصائيات', Icons.bar_chart_rounded),
    ('التركيز', Icons.timer_rounded),
    ('المهام', Icons.checklist_rounded),
    ('الإعدادات', Icons.settings_rounded),
  ];

  late final pages = <Widget>[
    HomePage(onOpenLibrary: () => setState(() => index = 1)),
    const LibraryPage(),
    const StatsPage(),
    const FocusPage(),
    const TasksPage(),
    const SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final compact = isCompact(context);
    final body = IndexedStack(index: index, children: pages);
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(compact ? 12 : 20),
            child: compact
                ? Column(children: [Expanded(child: body), const SizedBox(height: 10), _bottomNav()])
                : Row(children: [SizedBox(width: 190, child: _sidebar()), const SizedBox(width: 20), Expanded(child: body)]),
          ),
        ),
      ),
    );
  }

  /// شريط تنقل سفلي للموبايل
  Widget _bottomNav() => GlassCard(
        radius: 22,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        child: Row(children: [
          for (var i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => index = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  decoration: BoxDecoration(color: i == index ? HC.cream : null, borderRadius: BorderRadius.circular(14)),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i].$2, size: 22, color: i == index ? HC.green : HC.cream.withValues(alpha: .75)),
                    const SizedBox(height: 2),
                    Text(items[i].$1, maxLines: 1, style: TextStyle(fontSize: 10, color: i == index ? HC.green : HC.cream.withValues(alpha: .75))),
                  ]),
                ),
              ),
            ),
        ]),
      );

  Widget _sidebar() => GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 24),
        child: Column(children: [
          CircleAvatar(radius: 32, backgroundColor: HC.cream.withValues(alpha: .3), child: const Icon(Icons.person_rounded, size: 34)),
          const SizedBox(height: 8),
          ValueListenableBuilder<String>(
            valueListenable: AppData.name,
            builder: (context, n, _) => Text(n, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
          ),
          Text('واصل التقدّم', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
          const SizedBox(height: 20),
          for (var i = 0; i < items.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => setState(() => index = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                  decoration: BoxDecoration(color: i == index ? HC.cream : null, borderRadius: BorderRadius.circular(12)),
                  child: Row(children: [
                    Icon(items[i].$2, size: 20, color: i == index ? HC.green : HC.cream.withValues(alpha: .7)),
                    const SizedBox(width: 10),
                    Text(items[i].$1, style: TextStyle(fontSize: 16, fontWeight: i == index ? FontWeight.w600 : FontWeight.w400, color: i == index ? HC.green : HC.cream.withValues(alpha: .7))),
                  ]),
                ),
              ),
            ),
        ]),
      );
}
