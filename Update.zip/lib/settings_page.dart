import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'config.dart';
import 'data.dart';
import 'model_manager.dart';
import 'transcribe/transcriber.dart';
import 'glass.dart';
import 'store.dart';
import 'theme.dart';
import 'version.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final nameC = TextEditingController(text: AppData.name.value);
  static const maxBytes = 2 * 1024 * 1024;
  late final urlC = TextEditingController(text: kModelUrl);
  int? modelSize;
  double? progress;
  bool downloading = false;

  @override
  void initState() {
    super.initState();
    _refreshModel();
  }

  Future<void> _refreshModel() async {
    final s = await ModelManager.size();
    if (mounted) setState(() => modelSize = s);
  }

  Future<void> _downloadModel() async {
    setState(() {
      downloading = true;
      progress = 0;
    });
    try {
      await ModelManager.download(urlC.text.trim(), (p) {
        if (mounted) setState(() => progress = p);
      });
      _snack('تم تنزيل النموذج');
    } catch (e) {
      _snack('فشل التنزيل: $e');
    }
    if (mounted) setState(() => downloading = false);
    await _refreshModel();
  }

  Future<void> _importModel() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null || r.files.single.path == null) return;
    try {
      await ModelManager.importFrom(r.files.single.path!);
      _snack('تم استيراد النموذج');
    } catch (e) {
      _snack('فشل الاستيراد: $e');
    }
    await _refreshModel();
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _pickBg() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.single.path == null) return;
    final src = File(r.files.single.path!);
    final size = await src.length();
    if (size > maxBytes) {
      _snack('حجم الصورة ${(size / 1048576).toStringAsFixed(1)} ميغا، الحد الأقصى 2 ميغا');
      return;
    }
    final ext = r.files.single.name.contains('.') ? r.files.single.name.split('.').last.toLowerCase() : 'jpg';
    final dest = '${Store.dir.path}/bg_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await src.copy(dest);
    final old = AppData.bgPath.value;
    AppData.bgPath.value = dest;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await AppData.save();
  }

  Future<void> _resetBg() async {
    final old = AppData.bgPath.value;
    AppData.bgPath.value = null;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await AppData.save();
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: GlassCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            child,
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const PageHeader(title: 'الإعدادات'),
          _section(
            'الملف الشخصي',
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              // يتقلّص على الموبايل
              child: TextField(
                controller: nameC,
                decoration: const InputDecoration(labelText: 'الاسم'),
                onChanged: (v) {
                  AppData.name.value = v;
                  AppData.save();
                },
              ),
            ),
          ),
          _section(
            'خلفية التطبيق',
            ValueListenableBuilder<String?>(
              valueListenable: AppData.bgPath,
              builder: (context, p, _) => Wrap(spacing: 16, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.start, children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 220,
                    height: 124,
                    child: (p != null && File(p).existsSync()) ? Image.file(File(p), fit: BoxFit.cover) : Image.asset('assets/bg/bg.jpg', fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(width: 16),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FilledButton.icon(onPressed: _pickBg, icon: const Icon(Icons.image_rounded), label: const Text('اختيار صورة')),
                  const SizedBox(height: 8),
                  OutlinedButton(onPressed: p == null ? null : _resetBg, child: const Text('الخلفية الافتراضية')),
                  const SizedBox(height: 8),
                  Text('الحد الأقصى لحجم الصورة: 2 ميغا', style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .6))),
                ]),
              ]),
            ),
          ),
          _section(
            'الأداء',
            ValueListenableBuilder<bool>(
              valueListenable: AppData.reduceBlur,
              builder: (context, v, _) => SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('تقليل الشفافية (أسرع)'),
                subtitle: const Text('يوقف تمويه الزجاج في الواجهة'),
                value: v,
                onChanged: (x) {
                  AppData.reduceBlur.value = x;
                  AppData.save();
                },
              ),
            ),
          ),
          _section(
            'التفريغ الصوتي (تحويل الصوت إلى نص)',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                modelSize == null ? 'النموذج غير موجود' : 'النموذج موجود (${(modelSize! / 1048576).round()} ميغا)',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 4),
              Text(
                Transcriber.available ? 'محرك التفريغ مفعّل في هذه النسخة.' : 'هذه النسخة بدون محرك التفريغ. حمّل النموذج الآن ثم ثبّت نسخة hashiya-full-whisper.',
                style: TextStyle(fontSize: 12, color: HC.cream.withValues(alpha: .65)),
              ),
              const SizedBox(height: 12),
              TextField(controller: urlC, decoration: const InputDecoration(labelText: 'رابط النموذج')),
              const SizedBox(height: 12),
              if (downloading) LinearProgressIndicator(value: progress),
              if (downloading) const SizedBox(height: 12),
              Wrap(spacing: 10, runSpacing: 10, children: [
                FilledButton.icon(onPressed: downloading ? null : _downloadModel, icon: const Icon(Icons.download_rounded), label: const Text('تنزيل من الرابط')),
                OutlinedButton.icon(onPressed: downloading ? null : _importModel, icon: const Icon(Icons.folder_open_rounded), label: const Text('اختيار ملف من الجهاز')),
                if (modelSize != null)
                  TextButton(
                    onPressed: () async {
                      await ModelManager.remove();
                      await _refreshModel();
                    },
                    child: const Text('حذف النموذج'),
                  ),
              ]),
            ]),
          ),
          _section('حول', Text('حاشية · الإصدار $kVersion · بناء $kBuild', style: TextStyle(color: HC.cream.withValues(alpha: .7)))),
        ]),
      );
}
