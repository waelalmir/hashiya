import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'config.dart';

/// إدارة ملف نموذج التفريغ الصوتي: تنزيل من رابط أو استيراد ملف من الجهاز.
class ModelManager {
  static Future<File> file() async => File('${(await getApplicationSupportDirectory()).path}/$kModelFile');

  static Future<int?> size() async {
    final f = await file();
    return await f.exists() ? await f.length() : null;
  }

  static Future<void> download(String url, void Function(double?) onProgress) async {
    final f = await file();
    final tmp = File('${f.path}.part');
    final client = HttpClient();
    try {
      final req = await client.getUrl(Uri.parse(url));
      final resp = await req.close();
      if (resp.statusCode != 200) throw HttpException('رمز الاستجابة ${resp.statusCode}');
      final total = resp.contentLength;
      var got = 0;
      final sink = tmp.openWrite();
      await for (final chunk in resp) {
        got += chunk.length;
        sink.add(chunk);
        onProgress(total > 0 ? got / total : null);
      }
      await sink.close();
      if (await f.exists()) await f.delete();
      await tmp.rename(f.path);
    } finally {
      client.close(force: true);
    }
  }

  static Future<void> importFrom(String path) async {
    final f = await file();
    await File(path).copy(f.path);
  }

  static Future<void> remove() async {
    final f = await file();
    if (await f.exists()) await f.delete();
  }
}
